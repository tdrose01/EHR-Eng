# Lessons Learned from MCP PostgreSQL Testing

## Database Configuration and Setup

- PostgreSQL connection string format: `postgresql://postgres:postgres@localhost:5432/ehr_test`
- Always check if the PostgreSQL server is running before running tests with `pg_isready`
- The MCP tests require specific database tables: `patients`, `records`, and `users`
- Running both the PostgreSQL server and other HTTP services on the same machine can cause port conflicts

## Schema and Data Structure

- The database schema uses a single `name` field rather than separate `firstName`/`lastName` fields
- Database column names don't always match the frontend model property names (e.g., `name` vs `firstName`/`lastName`)
- Always check the actual schema before writing assertions by using `SELECT column_name FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'patients'`
- Add an inspection test to analyze the format of database records before writing detailed assertions

## Test Structure Best Practices

- Use safe assertions when testing database schema (e.g., check if a column exists before asserting it)
- Don't rely on LIMIT/OFFSET working exactly as expected in test environments - results may vary
- Add proper error handling and database cleanup after tests
- Add detailed logging of database query results for debugging purposes
- Separate test setup from test assertions for better maintainability
- Include schema verification steps before running database-dependent tests
- Mock network errors explicitly to test fallback behavior

## Common Issues and Solutions

- Network errors in console output are often informational and don't necessarily indicate test failures
- Path resolution problems can be fixed by using correct import paths relative to project structure
- Authentication token is required for API requests and must be properly set in headers
- Use explicit WHERE clauses in SQL queries (e.g., `table_schema = 'public'`) to avoid ambiguous results
- When tests fail due to missing properties, first check if the property exists in the schema
- Placeholder components can solve import errors in the router configuration
- Differences between unit test mocks and actual database schema cause most test failures
- Tests pass with expected errors when those errors are part of the test design

## Performance Considerations

- PostgreSQL settings to check: max_connections, shared_buffers, effective_cache_size
- Average query time around 2.5ms with cache hit ratio of 0.98 is good performance
- Use smaller batches for data import/export operations
- Dev server instances can accumulate and consume ports (8080-8090+)

## Test Command Structure

- Individual test commands like `npm run test:mcp:patient-search` are more useful for debugging
- Full test suite can be run with `npm run test:mcp`
- Database setup and teardown should be part of the test process
- Test commands should be documented in a README or dedicated testing document

## Vue Application Structure

- When files are referenced in router configuration but don't exist in the project, the app will fail to start
- Check for missing route component files by examining the router configuration (router/index.js)
- Create placeholder components for routes that are defined but don't have corresponding view files
- For external resources (like images), use reliable sources or placeholder services (e.g., https://via.placeholder.com)
- The development server will attempt to use alternative ports if the default ones (5173, 8080) are already in use
- When creating new Vue components, follow the existing project structure and styling conventions
- Use Base64-encoded images when actual image files aren't available or during initial development

## API and Services

- Check for missing services when import statements reference services that don't exist (e.g., `dashboardService` in api.js)
- Implement fallback data or mock responses in service functions to handle API errors gracefully
- Return properly formatted mock data to match the expected structure of API responses
- Always include error handling in service functions to prevent app crashes when APIs are unavailable
- Use environment variables for API endpoints to make the app configurable for different environments
- Keep token naming consistent across the application (e.g., using 'ehrToken' everywhere)
- Provide fallback credentials for testing environments

## Development Environment

- Kill unused development servers to prevent port exhaustion
- Use `lsof -i :8080` (Linux/Mac) or `netstat -ano | findstr :8080` (Windows) to find processes using specific ports
- Document the expected state of external services (PostgreSQL, API servers) needed for testing
- Keep test data consistent between unit tests and integration tests to avoid confusion
- When running both an API server and a dev server, configure CORS or use a proxy in development 
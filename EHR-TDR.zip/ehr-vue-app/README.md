# Military EHR Vue Application

This is a Vue.js-based Electronic Health Record (EHR) system for military healthcare. The application provides a modern, responsive interface for managing patient records, appointments, and medical information.

## Project Structure

```
ehr-vue-app/
├── docs/                   # Documentation files
│   ├── MCP_TESTING.md      # MCP testing guide
│   ├── MCP_TESTING_SUMMARY.md # Summary of MCP test results
│   └── PROGRESS_REPORT.md  # Current progress report
├── public/                 # Static assets served as-is
├── scripts/                # Utility scripts
│   ├── run-mcp-tests.bat   # Batch script for running MCP tests
│   └── run-mcp-tests.js    # JavaScript runner for MCP tests
├── src/                    # Source code
│   ├── assets/             # Application assets
│   │   └── img/            # Images (including base64 encoded)
│   ├── components/         # Vue components
│   ├── router/             # Vue Router configuration
│   ├── services/           # API service modules
│   ├── store/              # Vuex store (if used)
│   ├── tests/              # Test files
│   │   ├── e2e/            # End-to-end tests including MCP tests
│   │   └── views/          # Component tests for views
│   ├── views/              # Vue page components
│   ├── App.vue             # Root component
│   └── main.js             # Application entry point
└── .cursorules/            # Cursor-specific configuration
```

## Getting Started

### Prerequisites

- Node.js 14+ and npm
- PostgreSQL 12+

### Installation

1. Clone the repository
2. Install dependencies

```
npm install
```

3. Start the development server

```
npm run dev
```

## Database Setup

The application requires a PostgreSQL database for MCP tests. Configure your database connection in the `.env` file:

```
DB_HOST=localhost
DB_PORT=5432
DB_NAME=ehr_test
DB_USER=postgres
DB_PASSWORD=postgres
```

## Available Scripts

- `npm run dev` - Start the development server
- `npm run build` - Build for production
- `npm run test` - Run tests
- `npm run test:mcp` - Run all MCP PostgreSQL tests
- `npm run test:mcp:auth` - Run authentication MCP tests
- `npm run test:mcp:patients` - Run patient list MCP tests
- `npm run test:mcp:patient-view` - Run patient view MCP tests
- `npm run test:mcp:patient-search` - Run patient search MCP tests
- `npm run docs` - Open the documentation folder

## MCP Testing

This project includes Multi-Cloud Platform (MCP) tests that directly interact with a PostgreSQL database. See `docs/MCP_TESTING.md` for more details.

## Project Status

See `docs/PROGRESS_REPORT.md` for current progress and pending tasks.

## License

ISC 
# MCP PostgreSQL Testing

This document covers how to run tests against a PostgreSQL database using the MCP (Multi-Cloud Platform) testing framework.

## Prerequisites

1. PostgreSQL server running locally
2. Database `ehr_test` created
3. PostgreSQL user with appropriate permissions
4. Node.js and npm installed

## Connection Configuration

Tests use the following PostgreSQL connection string by default:

```
postgresql://postgres:postgres@localhost:5432/ehr_test
```

You can modify these settings in `.env` file:

```
DB_HOST=localhost
DB_PORT=5432
DB_NAME=ehr_test
DB_USER=postgres
DB_PASSWORD=postgres
```

## Running MCP Tests

### Using the Test Runner Script

The easiest way to run all MCP tests is to use the provided runner script:

```bash
npm run test:mcp
```

This script will:
1. Check if PostgreSQL is running
2. Run all MCP test files individually
3. Report the test results

### Running Individual Tests

You can also run specific MCP tests individually:

```bash
# Run authentication tests
npm run test:mcp:auth

# Run patient list tests
npm run test:mcp:patients

# Run patient view tests
npm run test:mcp:patient-view

# Run patient search tests
npm run test:mcp:patient-search
```

These commands are defined in `package.json`:

```json
"test:mcp:auth": "npx vitest run src/tests/e2e/Auth.mcp.spec.js --no-watch",
"test:mcp:patients": "npx vitest run src/tests/e2e/PatientList.mcp.spec.js --no-watch",
"test:mcp:patient-view": "npx vitest run src/tests/e2e/PatientView.mcp.spec.js --no-watch",
"test:mcp:patient-search": "npx vitest run src/tests/e2e/PatientSearch.mcp.spec.js --no-watch"
```

## Test Files

The MCP tests are located in the `src/tests/e2e` directory:

- `Auth.mcp.spec.js` - Tests authentication with database
- `PatientList.mcp.spec.js` - Tests patient list functionality
- `PatientView.mcp.spec.js` - Tests patient detail view with database data
- `PatientSearch.mcp.spec.js` - Tests patient search functionality

## Database Setup

The tests automatically set up the necessary database tables and test data before running. The setup process:

1. Creates required tables if they don't exist (`patients`, `records`, `users`)
2. Imports test data from JSON files
3. After tests complete, data is exported to result files for inspection
4. Tables are dropped to clean up

## Utility Scripts

The following utility scripts can help with database management:

```bash
# Check database schema
npm run test:mcp:check-db

# Manage test data (import/export)
npm run test:mcp:data

# Reset test data to defaults
npm run test:mcp:data:reset
```

## Troubleshooting

1. **PostgreSQL Connection Issues**
   - Ensure PostgreSQL is running
   - Check connection parameters in `.env`
   - Verify database user has appropriate permissions

2. **Missing Tables**
   - Tables are created automatically, but you can manually create them
   - See `manage-test-data.js` for schema details

3. **Network Errors**
   - Some tests may show network errors in console output
   - These are usually just informational and tests should still pass

For more detailed information, see the MCP test summary in [MCP_TESTING_SUMMARY.md](./MCP_TESTING_SUMMARY.md). 
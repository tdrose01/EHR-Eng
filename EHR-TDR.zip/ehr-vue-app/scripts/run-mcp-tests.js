#!/usr/bin/env node

/**
 * Script to run MCP PostgreSQL E2E tests
 * This script ensures that the PostgreSQL MCP server is properly set up
 * before running the tests, and cleans up afterward.
 */

import { spawnSync } from 'child_process';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

// Get current directory name
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

// Configuration
const dbConfig = {
  host: 'localhost',
  port: 5432,
  user: 'postgres',
  password: 'postgres',
  database: 'ehr_test'
};

// Colors for console output
const colors = {
  reset: '\x1b[0m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m'
};

/**
 * Check if PostgreSQL is running
 */
function checkPostgresRunning() {
  try {
    console.log(`${colors.yellow}Checking if PostgreSQL is running...${colors.reset}`);
    const pgCheckResult = spawnSync('pg_isready', ['-h', 'localhost', '-p', '5432'], {
      stdio: 'inherit',
      shell: true
    });

    if (pgCheckResult.status !== 0) {
      console.error(`${colors.red}❌ PostgreSQL is not running. Please start the PostgreSQL server and try again.${colors.reset}`);
      return false;
    }
    return true;
  } catch (error) {
    console.error(`${colors.red}An error occurred while checking PostgreSQL:${colors.reset}`);
    console.error(error);
    return false;
  }
}

/**
 * Main function to run the tests
 */
async function main() {
  console.log(`${colors.green}======================================${colors.reset}`);
  console.log(`${colors.green}= Running MCP PostgreSQL E2E Tests   =${colors.reset}`);
  console.log(`${colors.green}======================================${colors.reset}`);
  
  // Check if PostgreSQL is available
  if (!checkPostgresRunning()) {
    process.exit(1);
  }
  
  try {
    // Run individual test files directly
    console.log(`${colors.cyan}Running MCP PostgreSQL E2E tests individually...${colors.reset}`);
    
    // Test files to run
    const testFiles = [
      path.join(rootDir, 'src', 'tests', 'e2e', 'Auth.mcp.spec.js'),
      path.join(rootDir, 'src', 'tests', 'e2e', 'PatientList.mcp.spec.js'),
      path.join(rootDir, 'src', 'tests', 'e2e', 'PatientView.mcp.spec.js'),
      path.join(rootDir, 'src', 'tests', 'e2e', 'PatientSearch.mcp.spec.js')
    ];
    
    // Run MCP tests one by one
    let allPassed = true;
    for (const testFile of testFiles) {
      const fileName = path.basename(testFile);
      console.log(`${colors.green}Running test: ${fileName}${colors.reset}`);
      
      // Run vitest for this file
      const result = spawnSync('npx', ['vitest', 'run', `"${testFile}"`, '--no-watch'], {
        stdio: 'inherit',
        shell: true
      });
      
      if (result.status !== 0) {
        console.error(`${colors.red}❌ Test ${fileName} failed${colors.reset}`);
        allPassed = false;
      }
    }
    
    if (allPassed) {
      console.log(`${colors.green}All tests completed!${colors.reset}`);
      process.exit(0);
    } else {
      console.error(`${colors.red}Some tests failed!${colors.reset}`);
      process.exit(1);
    }
  } catch (error) {
    console.error(`${colors.red}An error occurred while running tests:${colors.reset}`);
    console.error(error);
    process.exit(1);
  }
}

// Run the main function
main().catch(error => {
  console.error(`${colors.red}Unhandled error:${colors.reset}`, error);
  process.exit(1);
}); 
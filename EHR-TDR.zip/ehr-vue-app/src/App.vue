<template>
  <div class="app">
    <router-view v-slot="{ Component }">
      <transition name="fade" mode="out-in">
        <component :is="Component" />
      </transition>
    </router-view>
  </div>
</template>

<script>
import { watch } from 'vue';
import { useRouter } from 'vue-router';
import { authService } from './services/api';

export default {
  name: 'App',
  setup() {
    const router = useRouter();
    
    // Check for authentication on route changes
    watch(() => router.currentRoute.value, async (route) => {
      if (route.meta.requiresAuth !== false) {
        const { authenticated } = await authService.checkAuth();
        if (!authenticated && route.name !== 'Login') {
          router.push('/login');
        }
      }
    }, { immediate: true });
  }
};
</script>

<style>
/* Global CSS Variables */
:root {
  --primary-bg: #1a2533;
  --secondary-bg: #2c3e50;
  --accent-color: #4d8bf0;
  --text-color: #ffffff;
  --text-muted: #b8c6d1;
  --border-color: #3f5268;
  --success-color: #2ed573;
  --warning-color: #ff9f43;
  --error-color: #ff4757;
  --transition-speed: 0.3s;
}

/* Reset & Base Styles */
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

html, body {
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 
    Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
  font-size: 16px;
  line-height: 1.5;
  color: var(--text-color);
  background-color: var(--primary-bg);
  height: 100%;
  width: 100%;
}

/* App Container */
.app {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

/* Links */
a {
  color: var(--accent-color);
  text-decoration: none;
  transition: color var(--transition-speed);
}

a:hover {
  color: #6ba1ff;
}

/* Buttons */
button {
  cursor: pointer;
  font-family: inherit;
}

/* Transitions */
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.2s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

/* Common Utility Classes */
.text-center {
  text-align: center;
}

.text-right {
  text-align: right;
}

.text-muted {
  color: var(--text-muted);
}

.text-success {
  color: var(--success-color);
}

.text-warning {
  color: var(--warning-color);
}

.text-error {
  color: var(--error-color);
}

.card {
  background-color: var(--secondary-bg);
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.loading-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.7);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999;
}

/* Tables */
table {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 1rem;
}

th, td {
  padding: 0.75rem;
  text-align: left;
  border-bottom: 1px solid var(--border-color);
}

th {
  font-weight: 500;
  color: var(--text-color);
  background-color: var(--secondary-bg);
}

/* Forms */
input, select, textarea {
  background-color: var(--secondary-bg);
  border: 1px solid var(--border-color);
  border-radius: 4px;
  color: var(--text-color);
  padding: 10px 12px;
  font-size: 0.9rem;
  width: 100%;
  transition: border-color var(--transition-speed);
}

input:focus, select:focus, textarea:focus {
  outline: none;
  border-color: var(--accent-color);
}

label {
  display: block;
  margin-bottom: 8px;
  font-weight: 500;
}

.form-group {
  margin-bottom: 1rem;
}

/* Scrollbars */
::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}

::-webkit-scrollbar-track {
  background: var(--secondary-bg);
}

::-webkit-scrollbar-thumb {
  background: var(--border-color);
  border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
  background: #4d5d72;
}
</style> 
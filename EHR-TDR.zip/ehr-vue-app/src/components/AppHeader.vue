<template>
  <header class="app-header">
    <div class="logo-container">
      <img src="../assets/logo.png" alt="Military EHR" class="logo" />
      <h1>Military EHR</h1>
    </div>
    
    <div class="user-container">
      <div class="user-info" @click="toggleDropdown">
        <span class="username">{{ username }}</span>
        <span class="user-icon">
          <i class="fas fa-user-circle"></i>
        </span>
      </div>
      
      <div class="dropdown-menu" v-if="showDropdown">
        <div class="dropdown-item" @click="goToProfile">
          <i class="fas fa-id-card"></i> Profile
        </div>
        <div class="dropdown-item" @click="goToSettings">
          <i class="fas fa-cog"></i> Settings
        </div>
        <div class="divider"></div>
        <div class="dropdown-item logout" @click="handleLogout">
          <i class="fas fa-sign-out-alt"></i> Logout
        </div>
      </div>
    </div>
  </header>
</template>

<script>
import { ref, onMounted, onUnmounted } from 'vue';
import { useRouter } from 'vue-router';

export default {
  name: 'AppHeader',
  
  setup() {
    const router = useRouter();
    const username = ref('');
    const showDropdown = ref(false);
    
    // Click outside to close dropdown
    const handleClickOutside = (event) => {
      const userContainer = document.querySelector('.user-container');
      if (userContainer && !userContainer.contains(event.target)) {
        showDropdown.value = false;
      }
    };
    
    onMounted(() => {
      // Get username from localStorage
      username.value = localStorage.getItem('username') || 'User';
      
      // Add click outside listener
      document.addEventListener('click', handleClickOutside);
    });
    
    onUnmounted(() => {
      document.removeEventListener('click', handleClickOutside);
    });
    
    const toggleDropdown = () => {
      showDropdown.value = !showDropdown.value;
    };
    
    const goToProfile = () => {
      router.push('/profile');
      showDropdown.value = false;
    };
    
    const goToSettings = () => {
      router.push('/settings');
      showDropdown.value = false;
    };
    
    const handleLogout = () => {
      // Clear auth data
      localStorage.removeItem('token');
      localStorage.removeItem('username');
      
      // Redirect to login
      router.push('/login');
    };
    
    return {
      username,
      showDropdown,
      toggleDropdown,
      goToProfile,
      goToSettings,
      handleLogout
    };
  }
};
</script>

<style scoped>
.app-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #2c3e50;
  color: white;
  padding: 0.5rem 1.5rem;
  height: 60px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
}

.logo-container {
  display: flex;
  align-items: center;
}

.logo {
  height: 40px;
  margin-right: 10px;
}

h1 {
  font-size: 1.2rem;
  font-weight: 500;
  margin: 0;
}

.user-container {
  position: relative;
}

.user-info {
  display: flex;
  align-items: center;
  cursor: pointer;
  padding: 5px 10px;
  border-radius: 4px;
  transition: background-color 0.2s;
}

.user-info:hover {
  background-color: #374a5e;
}

.username {
  margin-right: 8px;
  font-weight: 500;
}

.user-icon {
  font-size: 1.2rem;
}

.dropdown-menu {
  position: absolute;
  top: 100%;
  right: 0;
  background-color: #2c3e50;
  border-radius: 4px;
  width: 180px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
  z-index: 100;
  margin-top: 10px;
  overflow: hidden;
}

.dropdown-item {
  padding: 12px 15px;
  cursor: pointer;
  transition: background-color 0.2s;
  display: flex;
  align-items: center;
}

.dropdown-item i {
  margin-right: 10px;
  width: 16px;
  text-align: center;
}

.dropdown-item:hover {
  background-color: #374a5e;
}

.divider {
  height: 1px;
  background-color: #3f5268;
  margin: 5px 0;
}

.logout {
  color: #ff6b6b;
}
</style> 
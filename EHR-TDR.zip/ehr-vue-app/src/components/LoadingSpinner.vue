<template>
  <div class="spinner-container" :class="{ fullscreen }">
    <div class="spinner" :style="spinnerStyle">
      <div class="spinner-ring"></div>
      <div class="spinner-text" v-if="text">{{ text }}</div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'LoadingSpinner',
  props: {
    size: {
      type: String,
      default: 'medium',
      validator: (value) => ['small', 'medium', 'large'].includes(value)
    },
    text: {
      type: String,
      default: ''
    },
    fullscreen: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    spinnerStyle() {
      const sizes = {
        small: '30px',
        medium: '50px',
        large: '70px'
      };
      
      return {
        '--spinner-size': sizes[this.size]
      };
    }
  }
};
</script>

<style scoped>
.spinner-container {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 20px;
}

.spinner-container.fullscreen {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  z-index: 9999;
}

.spinner {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.spinner-ring {
  width: var(--spinner-size);
  height: var(--spinner-size);
  border: 3px solid rgba(77, 139, 240, 0.2);
  border-top: 3px solid #4d8bf0;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

.spinner-text {
  margin-top: 10px;
  color: #b8c6d1;
  font-size: 14px;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style> 
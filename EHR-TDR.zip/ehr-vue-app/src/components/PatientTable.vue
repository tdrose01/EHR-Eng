<template>
  <div class="patient-table-container">
    <!-- Table Header with Actions -->
    <div class="table-actions">
      <div class="search-box">
        <i class="fas fa-search"></i>
        <input 
          type="text" 
          v-model="searchQuery" 
          placeholder="Search patients..." 
          @input="handleSearch"
        />
      </div>
      
      <div class="action-buttons">
        <button @click="$emit('add-patient')" class="btn-primary">
          <i class="fas fa-plus"></i> Add Patient
        </button>
        <button v-if="selectedPatients.length > 0" @click="$emit('export-selected', selectedPatients)" class="btn-secondary">
          <i class="fas fa-file-export"></i> Export Selected
        </button>
      </div>
    </div>
    
    <!-- Patient Table -->
    <div class="table-wrapper">
      <table class="patient-table">
        <thead>
          <tr>
            <th v-if="selectable" class="checkbox-col">
              <input type="checkbox" :checked="allSelected" @change="toggleSelectAll" />
            </th>
            <th 
              v-for="column in visibleColumns" 
              :key="column.key"
              @click="sortBy(column.key)"
              :class="{ sortable: column.sortable, sorted: sortKey === column.key }"
            >
              {{ column.label }}
              <i v-if="column.sortable" :class="getSortIconClass(column.key)"></i>
            </th>
            <th v-if="hasActions" class="actions-col">Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-if="loading" class="loading-row">
            <td :colspan="calculateColSpan()">
              <loading-spinner size="small" text="Loading patients..." />
            </td>
          </tr>
          <tr v-else-if="filteredPatients.length === 0" class="no-data-row">
            <td :colspan="calculateColSpan()">
              <div class="no-data">
                <i class="fas fa-info-circle"></i>
                <p>No patients found</p>
              </div>
            </td>
          </tr>
          <tr v-for="patient in paginatedPatients" :key="patient.id" @click="handleRowClick(patient)">
            <td v-if="selectable" class="checkbox-col" @click.stop>
              <input 
                type="checkbox" 
                :checked="isSelected(patient)"
                @change="toggleSelect(patient)"
              />
            </td>
            <td v-for="column in visibleColumns" :key="column.key">
              <span v-if="column.formatter">{{ column.formatter(patient[column.key], patient) }}</span>
              <span v-else>{{ patient[column.key] }}</span>
            </td>
            <td v-if="hasActions" class="actions-col">
              <div class="action-icons">
                <i class="fas fa-eye" title="View" @click.stop="$emit('view-patient', patient)"></i>
                <i class="fas fa-edit" title="Edit" @click.stop="$emit('edit-patient', patient)"></i>
                <i class="fas fa-trash" title="Delete" @click.stop="$emit('delete-patient', patient)"></i>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    
    <!-- Pagination -->
    <div class="pagination" v-if="!loading && filteredPatients.length > 0">
      <div class="pagination-info">
        Showing {{ startIndex + 1 }}-{{ endIndex }} of {{ filteredPatients.length }} patients
      </div>
      <div class="pagination-controls">
        <button 
          :disabled="currentPage === 1" 
          @click="goToPage(currentPage - 1)"
          class="pagination-btn"
        >
          <i class="fas fa-chevron-left"></i>
        </button>
        
        <template v-for="page in paginationRange" :key="page">
          <button 
            v-if="page !== '...'" 
            :class="['pagination-btn', { active: currentPage === page }]"
            @click="goToPage(page)"
          >
            {{ page }}
          </button>
          <span v-else class="pagination-ellipsis">...</span>
        </template>
        
        <button 
          :disabled="currentPage === totalPages" 
          @click="goToPage(currentPage + 1)"
          class="pagination-btn"
        >
          <i class="fas fa-chevron-right"></i>
        </button>
      </div>
      <div class="per-page-selector">
        <select v-model="perPage">
          <option v-for="size in pageSizes" :key="size" :value="size">
            {{ size }} per page
          </option>
        </select>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, computed, watch, toRefs } from 'vue';
import LoadingSpinner from './LoadingSpinner.vue';

export default {
  name: 'PatientTable',
  components: {
    LoadingSpinner
  },
  props: {
    // Array of patient data
    patients: {
      type: Array,
      required: true
    },
    // Array of column definitions
    columns: {
      type: Array,
      required: true
    },
    // Default sort column
    defaultSortKey: {
      type: String,
      default: 'id'
    },
    // Default sort order
    defaultSortOrder: {
      type: String,
      default: 'asc',
      validator: (value) => ['asc', 'desc'].includes(value)
    },
    // Allow row selection
    selectable: {
      type: Boolean,
      default: true
    },
    // Show action buttons
    actions: {
      type: Boolean,
      default: true
    },
    // Loading state
    loading: {
      type: Boolean,
      default: false
    }
  },
  emits: [
    'view-patient', 
    'edit-patient', 
    'delete-patient', 
    'add-patient',
    'row-click',
    'export-selected',
    'search'
  ],
  setup(props, { emit }) {
    const { patients, defaultSortKey, defaultSortOrder } = toRefs(props);
    
    // Sorting
    const sortKey = ref(defaultSortKey.value);
    const sortOrder = ref(defaultSortOrder.value);
    
    // Searching
    const searchQuery = ref('');
    const debouncedSearchTimeout = ref(null);
    
    // Pagination
    const currentPage = ref(1);
    const perPage = ref(10);
    const pageSizes = [5, 10, 25, 50, 100];
    
    // Selection
    const selectedPatients = ref([]);
    
    // Filtered and sorted patients
    const filteredPatients = computed(() => {
      // First apply any search/filter
      let result = [...patients.value];
      
      // Sort the result
      result.sort((a, b) => {
        const aValue = a[sortKey.value];
        const bValue = b[sortKey.value];
        
        if (typeof aValue === 'string' && typeof bValue === 'string') {
          const comparison = aValue.localeCompare(bValue);
          return sortOrder.value === 'asc' ? comparison : -comparison;
        } else {
          const comparison = aValue - bValue;
          return sortOrder.value === 'asc' ? comparison : -comparison;
        }
      });
      
      return result;
    });
    
    // Pagination data
    const totalPages = computed(() => 
      Math.ceil(filteredPatients.value.length / perPage.value)
    );
    
    const startIndex = computed(() => 
      (currentPage.value - 1) * perPage.value
    );
    
    const endIndex = computed(() => 
      Math.min(startIndex.value + perPage.value, filteredPatients.value.length)
    );
    
    const paginatedPatients = computed(() => 
      filteredPatients.value.slice(startIndex.value, endIndex.value)
    );
    
    // Pagination range (e.g., [1, 2, "...", 7, 8, 9])
    const paginationRange = computed(() => {
      const total = totalPages.value;
      const current = currentPage.value;
      const range = [];
      
      if (total <= 7) {
        // If 7 or fewer pages, show all
        for (let i = 1; i <= total; i++) {
          range.push(i);
        }
      } else {
        // Always include first page
        range.push(1);
        
        // Show dots if current page is more than 3
        if (current > 3) {
          range.push('...');
        }
        
        // Determine range around current page
        const start = Math.max(2, current - 1);
        const end = Math.min(total - 1, current + 1);
        
        for (let i = start; i <= end; i++) {
          range.push(i);
        }
        
        // Show dots if current page is less than total - 2
        if (current < total - 2) {
          range.push('...');
        }
        
        // Always include last page
        range.push(total);
      }
      
      return range;
    });
    
    // Visible columns
    const visibleColumns = computed(() => 
      props.columns.filter(col => !col.hidden)
    );
    
    // Check if actions should be shown
    const hasActions = computed(() => props.actions);
    
    // Check if all rows are selected
    const allSelected = computed(() => {
      return paginatedPatients.value.length > 0 && 
             paginatedPatients.value.every(patient => 
               selectedPatients.value.some(p => p.id === patient.id)
             );
    });
    
    // Pagination methods
    const goToPage = (page) => {
      currentPage.value = page;
    };
    
    // Reset pagination when data changes
    watch(patients, () => {
      currentPage.value = 1;
    });
    
    // Reset pagination when per page changes
    watch(perPage, () => {
      currentPage.value = 1;
    });
    
    // Sorting methods
    const sortBy = (key) => {
      if (sortKey.value === key) {
        // Toggle order if same key
        sortOrder.value = sortOrder.value === 'asc' ? 'desc' : 'asc';
      } else {
        // New key, default to ascending
        sortKey.value = key;
        sortOrder.value = 'asc';
      }
    };
    
    const getSortIconClass = (key) => {
      if (sortKey.value !== key) {
        return 'fas fa-sort';
      }
      return sortOrder.value === 'asc' ? 'fas fa-sort-up' : 'fas fa-sort-down';
    };
    
    // Selection methods
    const isSelected = (patient) => {
      return selectedPatients.value.some(p => p.id === patient.id);
    };
    
    const toggleSelect = (patient) => {
      if (isSelected(patient)) {
        selectedPatients.value = selectedPatients.value.filter(p => p.id !== patient.id);
      } else {
        selectedPatients.value.push(patient);
      }
    };
    
    const toggleSelectAll = () => {
      if (allSelected.value) {
        selectedPatients.value = [];
      } else {
        selectedPatients.value = [...paginatedPatients.value];
      }
    };
    
    // Search handler with debounce
    const handleSearch = () => {
      if (debouncedSearchTimeout.value) {
        clearTimeout(debouncedSearchTimeout.value);
      }
      
      debouncedSearchTimeout.value = setTimeout(() => {
        emit('search', searchQuery.value);
      }, 300);
    };
    
    // Row click handler
    const handleRowClick = (patient) => {
      emit('row-click', patient);
    };
    
    // Calculate colspan for loading/no data rows
    const calculateColSpan = () => {
      let span = visibleColumns.value.length;
      if (props.selectable) span++;
      if (props.actions) span++;
      return span;
    };
    
    return {
      // Data
      sortKey,
      sortOrder,
      searchQuery,
      currentPage,
      perPage,
      pageSizes,
      selectedPatients,
      
      // Computed
      filteredPatients,
      paginatedPatients,
      startIndex,
      endIndex,
      totalPages,
      paginationRange,
      visibleColumns,
      hasActions,
      allSelected,
      
      // Methods
      sortBy,
      getSortIconClass,
      isSelected,
      toggleSelect,
      toggleSelectAll,
      goToPage,
      handleSearch,
      handleRowClick,
      calculateColSpan
    };
  }
};
</script>

<style scoped>
.patient-table-container {
  background-color: #2c3e50;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.table-actions {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px 20px;
  background-color: #1e2a38;
}

.search-box {
  position: relative;
  flex: 1;
  max-width: 300px;
}

.search-box i {
  position: absolute;
  left: 10px;
  top: 50%;
  transform: translateY(-50%);
  color: #8c9ebb;
}

.search-box input {
  width: 100%;
  padding: 8px 10px 8px 35px;
  border-radius: 4px;
  border: 1px solid #3f5268;
  background-color: #2c3e50;
  color: white;
  font-size: 14px;
}

.search-box input:focus {
  outline: none;
  border-color: #4d8bf0;
}

.action-buttons {
  display: flex;
  gap: 10px;
}

.btn-primary, .btn-secondary {
  padding: 8px 12px;
  border-radius: 4px;
  border: none;
  font-size: 14px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 5px;
}

.btn-primary {
  background-color: #4d8bf0;
  color: white;
}

.btn-primary:hover {
  background-color: #3a78db;
}

.btn-secondary {
  background-color: #3f5268;
  color: white;
}

.btn-secondary:hover {
  background-color: #2c3e50;
}

.table-wrapper {
  overflow-x: auto;
}

.patient-table {
  width: 100%;
  border-collapse: collapse;
  table-layout: auto;
}

.patient-table th, .patient-table td {
  padding: 12px 15px;
  text-align: left;
  border-bottom: 1px solid #3f5268;
}

.patient-table thead th {
  background-color: #1e2a38;
  color: white;
  font-weight: 500;
  position: sticky;
  top: 0;
  z-index: 1;
}

.patient-table tbody tr {
  transition: background-color 0.2s;
}

.patient-table tbody tr:hover {
  background-color: #3a4e67;
  cursor: pointer;
}

.sortable {
  cursor: pointer;
  user-select: none;
}

.sortable i {
  margin-left: 5px;
  font-size: 12px;
  color: #8c9ebb;
}

.sorted {
  background-color: #1e2a38;
}

.sorted i {
  color: #4d8bf0;
}

.actions-col {
  width: 120px;
  text-align: center;
}

.checkbox-col {
  width: 40px;
  text-align: center;
}

.action-icons {
  display: flex;
  justify-content: center;
  gap: 15px;
}

.action-icons i {
  cursor: pointer;
  transition: color 0.2s;
}

.action-icons i:hover {
  color: #4d8bf0;
}

.loading-row td, .no-data-row td {
  padding: 30px 15px;
  text-align: center;
}

.no-data {
  display: flex;
  flex-direction: column;
  align-items: center;
  color: #8c9ebb;
}

.no-data i {
  font-size: 24px;
  margin-bottom: 10px;
}

.pagination {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px 20px;
  background-color: #1e2a38;
  border-top: 1px solid #3f5268;
}

.pagination-info {
  color: #8c9ebb;
  font-size: 14px;
}

.pagination-controls {
  display: flex;
  align-items: center;
  gap: 5px;
}

.pagination-btn {
  width: 30px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 4px;
  border: 1px solid #3f5268;
  background-color: #2c3e50;
  color: white;
  cursor: pointer;
}

.pagination-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.pagination-btn.active {
  background-color: #4d8bf0;
  border-color: #4d8bf0;
}

.pagination-ellipsis {
  padding: 0 5px;
  color: #8c9ebb;
}

.per-page-selector select {
  padding: 5px 10px;
  border-radius: 4px;
  border: 1px solid #3f5268;
  background-color: #2c3e50;
  color: white;
  cursor: pointer;
}
</style> 
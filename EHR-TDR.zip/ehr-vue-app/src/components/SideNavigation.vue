<template>
  <nav class="side-nav" :class="{ 'collapsed': isCollapsed }">
    <div class="nav-toggle" @click="toggleCollapse">
      <i class="fas" :class="isCollapsed ? 'fa-chevron-right' : 'fa-chevron-left'"></i>
    </div>
    
    <div class="nav-items">
      <router-link to="/dashboard" class="nav-item" active-class="active">
        <i class="fas fa-tachometer-alt"></i>
        <span v-if="!isCollapsed">Dashboard</span>
      </router-link>
      
      <router-link to="/patients" class="nav-item" active-class="active">
        <i class="fas fa-users"></i>
        <span v-if="!isCollapsed">Patients</span>
      </router-link>
      
      <router-link to="/appointments" class="nav-item" active-class="active">
        <i class="fas fa-calendar-alt"></i>
        <span v-if="!isCollapsed">Appointments</span>
      </router-link>
      
      <router-link to="/records" class="nav-item" active-class="active">
        <i class="fas fa-file-medical"></i>
        <span v-if="!isCollapsed">Medical Records</span>
      </router-link>
      
      <router-link to="/medications" class="nav-item" active-class="active">
        <i class="fas fa-pills"></i>
        <span v-if="!isCollapsed">Medications</span>
      </router-link>
      
      <router-link to="/lab-results" class="nav-item" active-class="active">
        <i class="fas fa-vial"></i>
        <span v-if="!isCollapsed">Lab Results</span>
      </router-link>
      
      <router-link to="/inventory" class="nav-item" active-class="active">
        <i class="fas fa-boxes"></i>
        <span v-if="!isCollapsed">Inventory</span>
      </router-link>
      
      <router-link to="/reports" class="nav-item" active-class="active">
        <i class="fas fa-chart-bar"></i>
        <span v-if="!isCollapsed">Reports</span>
      </router-link>
    </div>
    
    <div class="nav-footer">
      <router-link to="/help" class="nav-item" active-class="active">
        <i class="fas fa-question-circle"></i>
        <span v-if="!isCollapsed">Help</span>
      </router-link>
    </div>
  </nav>
</template>

<script>
import { ref } from 'vue';

export default {
  name: 'SideNavigation',
  setup() {
    const isCollapsed = ref(false);
    
    const toggleCollapse = () => {
      isCollapsed.value = !isCollapsed.value;
      localStorage.setItem('navCollapsed', isCollapsed.value);
    };
    
    // Check if the navigation should be collapsed on init
    if (localStorage.getItem('navCollapsed') === 'true') {
      isCollapsed.value = true;
    }
    
    return {
      isCollapsed,
      toggleCollapse
    };
  }
};
</script>

<style scoped>
.side-nav {
  background-color: #1e2a38;
  width: 240px;
  height: calc(100vh - 60px);
  transition: width 0.3s ease;
  position: relative;
  display: flex;
  flex-direction: column;
}

.side-nav.collapsed {
  width: 60px;
}

.nav-toggle {
  position: absolute;
  top: 15px;
  right: -12px;
  background-color: #4d8bf0;
  color: white;
  width: 24px;
  height: 24px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  box-shadow: 0 2px 5px rgba(0,0,0,0.2);
  z-index: 2;
}

.nav-items {
  padding: 20px 0;
  flex-grow: 1;
  overflow-y: auto;
}

.nav-item {
  display: flex;
  align-items: center;
  padding: 12px 20px;
  color: #b8c6d1;
  text-decoration: none;
  transition: 0.2s all;
  white-space: nowrap;
}

.nav-item i {
  font-size: 18px;
  min-width: 24px;
  text-align: center;
  margin-right: 15px;
}

.nav-item:hover {
  background-color: #2c3e50;
  color: white;
}

.nav-item.active {
  background-color: #4d8bf0;
  color: white;
  font-weight: 500;
}

.nav-footer {
  border-top: 1px solid #2c3e50;
  padding: 10px 0;
}
</style> 
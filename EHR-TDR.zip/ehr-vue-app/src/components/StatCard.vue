<template>
  <div 
    class="stat-card" 
    :class="type"
    @click="handleClick"
  >
    <div class="icon">
      <i :class="icon"></i>
    </div>
    <div class="content">
      <h2 class="value">{{ value }}</h2>
      <p class="label">{{ label }}</p>
      <span v-if="change !== null" class="change" :class="changeClass">
        <i :class="changeIconClass"></i>
        {{ change }}%
      </span>
    </div>
  </div>
</template>

<script>
import { computed } from 'vue';
import { useRouter } from 'vue-router';

export default {
  name: 'StatCard',
  props: {
    // The card type (patients, appointments, records, etc)
    type: {
      type: String,
      default: 'default'
    },
    // Display value
    value: {
      type: [Number, String],
      required: true
    },
    // Card label
    label: {
      type: String,
      required: true
    },
    // Icon class (FontAwesome)
    icon: {
      type: String,
      required: true
    },
    // Percentage change (positive or negative)
    change: {
      type: Number,
      default: null
    },
    // Link to navigate to when clicked
    link: {
      type: String,
      default: null
    }
  },
  setup(props) {
    const router = useRouter();
    
    const changeClass = computed(() => {
      if (props.change === null) return '';
      return props.change >= 0 ? 'increase' : 'decrease';
    });
    
    const changeIconClass = computed(() => {
      if (props.change === null) return '';
      return props.change >= 0 ? 'fas fa-arrow-up' : 'fas fa-arrow-down';
    });
    
    const handleClick = () => {
      if (props.link) {
        router.push(props.link);
      }
    };
    
    return {
      changeClass,
      changeIconClass,
      handleClick
    };
  }
};
</script>

<style scoped>
.stat-card {
  background-color: #2c3e50;
  border-radius: 8px;
  padding: 20px;
  display: flex;
  align-items: center;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  transition: transform 0.2s, box-shadow 0.2s;
  cursor: pointer;
}

.stat-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
}

.icon {
  width: 50px;
  height: 50px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 15px;
  font-size: 24px;
}

.content {
  flex: 1;
}

.value {
  font-size: 24px;
  font-weight: 600;
  margin: 0 0 5px 0;
  color: white;
}

.label {
  color: #b8c6d1;
  margin: 0 0 5px 0;
  font-size: 14px;
}

.change {
  font-size: 12px;
  display: inline-flex;
  align-items: center;
  padding: 2px 6px;
  border-radius: 4px;
}

.change i {
  margin-right: 4px;
  font-size: 10px;
}

.increase {
  background-color: rgba(46, 213, 115, 0.2);
  color: #2ed573;
}

.decrease {
  background-color: rgba(255, 71, 87, 0.2);
  color: #ff4757;
}

/* Card type variations */
.stat-card.patients .icon {
  background-color: rgba(77, 139, 240, 0.2);
  color: #4d8bf0;
}

.stat-card.appointments .icon {
  background-color: rgba(46, 213, 115, 0.2);
  color: #2ed573;
}

.stat-card.records .icon {
  background-color: rgba(255, 159, 67, 0.2);
  color: #ff9f43;
}

.stat-card.medications .icon {
  background-color: rgba(156, 136, 255, 0.2);
  color: #9c88ff;
}

.stat-card.default .icon {
  background-color: rgba(200, 200, 200, 0.2);
  color: #c8c8c8;
}
</style> 
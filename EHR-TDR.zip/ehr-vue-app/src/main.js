import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import './assets/main.css'

// Enable production mode for better performance
import.meta.env.PROD = true

// Add link to Font Awesome for icons (used throughout the app)
const fontAwesome = document.createElement('link')
fontAwesome.rel = 'stylesheet'
fontAwesome.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css'
document.head.appendChild(fontAwesome)

// Create and mount the app
const app = createApp(App)

// Performance optimizations
app.config.performance = false
app.config.unwrapInjectedRef = true
app.config.compilerOptions = {
  hoistStatic: true,
  cacheHandlers: true
}

// Add global properties
app.config.globalProperties.$formatDate = (dateString) => {
  if (!dateString) return 'N/A'
  
  const date = new Date(dateString)
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  })
}

app.config.globalProperties.$formatDateTime = (dateString) => {
  if (!dateString) return 'N/A'
  
  const date = new Date(dateString)
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  })
}

// Error handling
app.config.errorHandler = (err, vm, info) => {
  console.error('Vue Error:', err)
  console.error('Info:', info)
}

// Use router
app.use(router)

// Mount app when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    app.mount('#app')
  })
} else {
  app.mount('#app')
} 
import { createRouter, createWebHistory } from 'vue-router'

// Views
import Login from '../views/Login.vue'
import Dashboard from '../views/Dashboard.vue'
import NotFound from '../views/NotFound.vue'
import Landing from '../views/Landing.vue'

// Lazy loaded views
const PatientList = () => import('../views/PatientList.vue')
const PatientView = () => import('../views/PatientView.vue')
const PatientEdit = () => import('../views/PatientEdit.vue')
const Appointments = () => import('../views/Appointments.vue')
const Records = () => import('../views/Records.vue')

// Detect missing pages and create placeholders
const Settings = () => import('../views/NotFound.vue')
const Profile = () => import('../views/NotFound.vue')
const Help = () => import('../views/NotFound.vue')

// Auth guard with performance optimizations
const requireAuth = (to, from, next) => {
  const token = localStorage.getItem('ehrToken')
  
  // Quick check to avoid unnecessary API calls
  if (!token) {
    next({ name: 'Login', query: { redirect: to.fullPath } })
    return
  }
  
  // For test tokens, consider them valid immediately (avoid API call)
  if (token.startsWith('test_token_')) {
    next()
    return
  }
  
  // For real tokens, proceed (auth check will happen in App.vue)
  next()
}

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      name: 'Landing',
      component: Landing,
      meta: { requiresAuth: false }
    },
    {
      path: '/dashboard',
      name: 'Dashboard',
      component: Dashboard,
      meta: { requiresAuth: true }
    },
    {
      path: '/login',
      name: 'Login',
      component: Login,
      meta: { requiresAuth: false }
    },
    {
      path: '/patients',
      name: 'PatientList',
      component: PatientList,
      meta: { requiresAuth: true }
    },
    {
      path: '/patients/view/:id',
      name: 'PatientView',
      component: PatientView,
      props: true,
      meta: { requiresAuth: true }
    },
    {
      path: '/patients/edit/:id',
      name: 'PatientEdit',
      component: PatientEdit,
      props: true,
      meta: { requiresAuth: true }
    },
    {
      path: '/patients/add',
      name: 'PatientAdd',
      component: PatientEdit,
      props: { isNew: true },
      meta: { requiresAuth: true }
    },
    {
      path: '/appointments',
      name: 'Appointments',
      component: Appointments,
      meta: { requiresAuth: true }
    },
    {
      path: '/records',
      name: 'Records',
      component: Records,
      meta: { requiresAuth: true }
    },
    {
      path: '/settings',
      name: 'Settings',
      component: Settings,
      meta: { requiresAuth: true }
    },
    {
      path: '/profile',
      name: 'Profile',
      component: Profile,
      meta: { requiresAuth: true }
    },
    {
      path: '/help',
      name: 'Help',
      component: Help,
      meta: { requiresAuth: true }
    },
    {
      path: '/:pathMatch(.*)*',
      name: 'NotFound',
      component: NotFound
    }
  ]
})

// Global navigation guard
router.beforeEach((to, from, next) => {
  if (to.meta.requiresAuth !== false) {
    requireAuth(to, from, next)
  } else {
    next()
  }
})

export default router 
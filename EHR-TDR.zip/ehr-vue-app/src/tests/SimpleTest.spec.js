import { describe, it, expect } from 'vitest'; describe('Simple test', () => { it('works', () => { expect(true).toBe(true) }) })

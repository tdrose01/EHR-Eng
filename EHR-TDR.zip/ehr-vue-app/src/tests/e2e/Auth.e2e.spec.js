import { describe, test, expect, beforeAll } from 'vitest';
import { apiClient } from './setup';

describe('Authentication E2E Tests', () => {
  // Test credentials - these should exist in your test environment
  const validCredentials = {
    username: 'testuser',
    password: 'password'
  };
  
  const invalidCredentials = {
    username: 'invaliduser',
    password: 'wrongpassword'
  };
  
  test('Login succeeds with valid credentials', async () => {
    try {
      const response = await apiClient.post('/api/login', validCredentials);
      
      // Verify response structure
      expect(response.status).toBe(200);
      expect(response.data).toHaveProperty('token');
      expect(response.data.token).toBeTruthy();
      
      // Optional: Verify token is valid by making an authenticated request
      apiClient.defaults.headers.common['Authorization'] = `Bearer ${response.data.token}`;
      const verifyResponse = await apiClient.get('/api/verify-token');
      expect(verifyResponse.status).toBe(200);
    } catch (error) {
      console.error('Login test failed:', error);
      throw error;
    }
  });
  
  test('Login fails with invalid credentials', async () => {
    try {
      await apiClient.post('/api/login', invalidCredentials);
      // Should not reach here
      expect(true).toBe(false); // Force test to fail if we reach this point
    } catch (error) {
      // Verify we got the expected error
      expect(error.response).toBeTruthy();
      expect(error.response.status).toBe(401);
    }
  });
  
  test('Protected routes require authentication', async () => {
    // Clear any existing auth token
    delete apiClient.defaults.headers.common['Authorization'];
    
    try {
      await apiClient.get('/api/patients');
      // Should not reach here
      expect(true).toBe(false); // Force test to fail if we reach this point
    } catch (error) {
      // Verify we got the expected error
      expect(error.response).toBeTruthy();
      expect(error.response.status).toBe(401);
    }
    
    // Now login and verify we can access the protected route
    const loginResponse = await apiClient.post('/api/login', validCredentials);
    apiClient.defaults.headers.common['Authorization'] = `Bearer ${loginResponse.data.token}`;
    
    const protectedResponse = await apiClient.get('/api/patients');
    expect(protectedResponse.status).toBe(200);
    expect(protectedResponse.data).toHaveProperty('patients');
  });
  
  test('Token verification works correctly', async () => {
    // Login to get a valid token
    const loginResponse = await apiClient.post('/api/login', validCredentials);
    const validToken = loginResponse.data.token;
    
    // Test with valid token
    apiClient.defaults.headers.common['Authorization'] = `Bearer ${validToken}`;
    const validResponse = await apiClient.get('/api/verify-token');
    expect(validResponse.status).toBe(200);
    
    // Test with invalid token
    apiClient.defaults.headers.common['Authorization'] = 'Bearer invalidtoken12345';
    try {
      await apiClient.get('/api/verify-token');
      // Should not reach here
      expect(true).toBe(false); // Force test to fail if we reach this point
    } catch (error) {
      // Verify we got the expected error
      expect(error.response).toBeTruthy();
      expect(error.response.status).toBe(401);
    }
  });
}); 
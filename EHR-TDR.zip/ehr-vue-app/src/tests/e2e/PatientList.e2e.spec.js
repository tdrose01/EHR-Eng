import { describe, test, expect, beforeAll, beforeEach } from 'vitest';
import { mount } from '@vue/test-utils';
import { createRouter, createWebHistory } from 'vue-router';
import { apiClient, getAuthToken, setAuthHeader } from './setup';
import PatientList from '@/views/PatientList.vue';

// Global variables
let router;
let authToken;

// Create test router configuration
const createTestRouter = () => {
  return createRouter({
    history: createWebHistory(),
    routes: [
      {
        path: '/patients',
        name: 'PatientList',
        component: PatientList
      },
      {
        path: '/patients/:id',
        name: 'PatientView'
      }
    ]
  });
};

describe('PatientList E2E Tests', () => {
  // Run before all tests in this file
  beforeAll(async () => {
    // Get auth token
    authToken = await getAuthToken();
    setAuthHeader(authToken);
    
    // Setup router
    router = createTestRouter();
  });
  
  // Run before each test
  beforeEach(async () => {
    // Reset router to patient list view
    router.push('/patients');
    await router.isReady();
  });
  
  test('PatientList loads and displays patients from API', async () => {
    // Get actual patient data from API for comparison
    const response = await apiClient.get('/api/patients');
    const patientsData = response.data.patients || [];
    
    // Mount component with router
    const wrapper = mount(PatientList, {
      global: {
        plugins: [router]
      }
    });
    
    // Wait for component to load data
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Check that the component displays the expected number of patients
    const patientRows = wrapper.findAll('.patient-row');
    expect(patientRows.length).toBe(patientsData.length);
    
    // Verify the first patient's data is displayed correctly
    if (patientsData.length > 0) {
      const firstPatient = patientsData[0];
      const firstRow = patientRows[0];
      
      expect(firstRow.text()).toContain(firstPatient.name);
      expect(firstRow.text()).toContain(firstPatient.id);
      
      // Check additional fields if they're displayed in your component
      if (firstPatient.dateOfBirth) {
        expect(firstRow.text()).toContain(new Date(firstPatient.dateOfBirth).toLocaleDateString());
      }
      
      if (firstPatient.gender) {
        expect(firstRow.text()).toContain(firstPatient.gender);
      }
    }
  });
  
  test('PatientList pagination works with real data', async () => {
    // Set page size small enough to guarantee pagination
    const pageSize = 5;
    
    // Get first page of patients
    const firstPageResponse = await apiClient.get(`/api/patients?limit=${pageSize}&page=1`);
    const firstPageData = firstPageResponse.data;
    
    // Mount component with router
    const wrapper = mount(PatientList, {
      global: {
        plugins: [router]
      },
      data() {
        return {
          pageSize,
          currentPage: 1
        };
      }
    });
    
    // Wait for component to load data
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Verify first page data
    let patientRows = wrapper.findAll('.patient-row');
    expect(patientRows.length).toBeLessThanOrEqual(pageSize);
    
    // Only proceed with pagination test if there's a second page
    if (firstPageData.total > pageSize) {
      // Get second page directly from API for comparison
      const secondPageResponse = await apiClient.get(`/api/patients?limit=${pageSize}&page=2`);
      const secondPagePatients = secondPageResponse.data.patients || [];
      
      // Click next page button
      const nextPageButton = wrapper.find('.pagination-next');
      await nextPageButton.trigger('click');
      
      // Wait for data to load
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Check that second page patients are displayed
      patientRows = wrapper.findAll('.patient-row');
      
      // Verify at least the first patient on the second page
      if (secondPagePatients.length > 0) {
        const firstPatientOnSecondPage = secondPagePatients[0];
        const firstRowOnPage = patientRows[0];
        
        expect(firstRowOnPage.text()).toContain(firstPatientOnSecondPage.name);
        expect(firstRowOnPage.text()).toContain(firstPatientOnSecondPage.id);
      }
    }
  });
  
  test('PatientList search functionality works with real data', async () => {
    // Mount component with router
    const wrapper = mount(PatientList, {
      global: {
        plugins: [router]
      }
    });
    
    // Wait for initial data to load
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Get all patients for testing search
    const allPatientsResponse = await apiClient.get('/api/patients');
    const allPatients = allPatientsResponse.data.patients || [];
    
    // Only proceed if we have patients to search
    if (allPatients.length > 0) {
      // Take a search term from a real patient (first name)
      const searchPatient = allPatients[0];
      const searchTerm = searchPatient.name.split(' ')[0]; // Use first name as search term
      
      // Get expected search results directly from API
      const searchApiResponse = await apiClient.get(`/api/patients?search=${searchTerm}`);
      const expectedSearchResults = searchApiResponse.data.patients || [];
      
      // Set search input value and trigger search
      const searchInput = wrapper.find('input[type="search"]');
      await searchInput.setValue(searchTerm);
      await searchInput.trigger('input');
      
      // If the component has a search button, click it
      const searchButton = wrapper.find('.search-button');
      if (searchButton.exists()) {
        await searchButton.trigger('click');
      }
      
      // Wait for search results to load
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Verify search results
      const patientRows = wrapper.findAll('.patient-row');
      expect(patientRows.length).toBe(expectedSearchResults.length);
      
      // Verify the searched patient is in the results
      const searchPatientFound = Array.from(patientRows).some(row => 
        row.text().includes(searchPatient.name) && row.text().includes(searchPatient.id)
      );
      
      expect(searchPatientFound).toBe(true);
    }
  });
}); 
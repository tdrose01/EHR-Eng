import { describe, test, expect, beforeAll, beforeEach } from 'vitest';
import { mount } from '@vue/test-utils';
import { createRouter, createWebHistory } from 'vue-router';
import { apiClient, getAuthToken, setAuthHeader } from './setup';
import PatientView from '@/views/PatientView.vue';

// Global variables
let router;
let authToken;
let testPatientId;

// Create test router configuration
const createTestRouter = () => {
  return createRouter({
    history: createWebHistory(),
    routes: [
      {
        path: '/patients/:id',
        name: 'PatientView',
        component: PatientView
      }
    ]
  });
};

describe('PatientView E2E Tests', () => {
  // Run before all tests in this file
  beforeAll(async () => {
    // Get auth token
    authToken = await getAuthToken();
    setAuthHeader(authToken);
    
    // Fetch a real patient ID to use in tests
    try {
      const response = await apiClient.get('/api/patients?limit=1');
      testPatientId = response.data.patients[0]?.id;
      
      if (!testPatientId) {
        throw new Error('No test patient found in the database');
      }
      
      console.log(`Using test patient ID: ${testPatientId}`);
    } catch (error) {
      console.error('Failed to get test patient:', error);
      throw error;
    }
    
    // Setup router
    router = createTestRouter();
  });
  
  // Run before each test
  beforeEach(async () => {
    // Reset router to patient view with our test patient
    router.push(`/patients/${testPatientId}`);
    await router.isReady();
  });
  
  test('PatientView loads and displays patient data correctly', async () => {
    // Get actual patient data from API for comparison
    const response = await apiClient.get(`/api/patients/${testPatientId}`);
    const patientData = response.data;
    
    // Mount component with router
    const wrapper = mount(PatientView, {
      global: {
        plugins: [router],
        stubs: {
          // Stub child components that aren't being tested
          'Appointments': true,
          'Records': true
        }
      }
    });
    
    // Wait for component to load data
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Assert patient information is displayed correctly
    expect(wrapper.text()).toContain(patientData.name);
    expect(wrapper.text()).toContain(patientData.id);
    
    // Verify other patient details are present
    if (patientData.dateOfBirth) {
      expect(wrapper.text()).toContain(new Date(patientData.dateOfBirth).toLocaleDateString());
    }
    
    if (patientData.gender) {
      expect(wrapper.text()).toContain(patientData.gender);
    }
    
    // Add more assertions based on your component's display of patient data
  });
  
  test('PatientView displays patient records', async () => {
    // Get actual records data for comparison
    const recordsResponse = await apiClient.get(`/api/patients/${testPatientId}/records`);
    const recordsData = recordsResponse.data;
    
    // Mount component with router
    const wrapper = mount(PatientView, {
      global: {
        plugins: [router],
        // Don't stub Records component as we want to test its integration
        stubs: {
          'Appointments': true
        }
      }
    });
    
    // Wait for component to load data
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Assert that records are displayed
    if (recordsData.length > 0) {
      // Check that at least the first record's data appears in the component
      const firstRecord = recordsData[0];
      expect(wrapper.text()).toContain(firstRecord.type || '');
      expect(wrapper.text()).toContain(firstRecord.date || '');
    } else {
      // If no records, should display "No records found" message
      expect(wrapper.text()).toContain('No records found');
    }
  });
});

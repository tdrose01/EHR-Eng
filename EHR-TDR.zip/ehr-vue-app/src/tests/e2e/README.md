# End-to-End (E2E) Tests for EHR Vue Application

This directory contains end-to-end tests for the EHR Vue application, including tests that utilize the MCP PostgreSQL server for database integration testing.

## Test Types

There are two types of E2E tests in this directory:

1. **Standard E2E Tests** (`*.e2e.spec.js`) - Tests that use mock data and simulate API calls
2. **MCP PostgreSQL Tests** (`*.mcp.spec.js`) - Tests that utilize the MCP PostgreSQL server for database integration

## MCP PostgreSQL Tests

The MCP PostgreSQL tests provide end-to-end testing that includes database interactions. These tests:

- Connect to a PostgreSQL database
- Create test tables and seed them with test data
- Run tests against components that interact with the database
- Clean up the database after tests complete

### Available MCP Tests

- `Auth.mcp.spec.js` - Tests authentication flows with database integration
- `PatientList.mcp.spec.js` - Tests the patient list component with database-sourced data
- `PatientView.mcp.spec.js` - Tests the patient view component with database-sourced data

## Running the Tests

### Prerequisites

- Node.js v16 or higher
- PostgreSQL database server running locally (default connection: `postgresql://postgres:postgres@localhost:5432/ehr_test`)

### Running All MCP Tests

You can run all MCP tests using the provided runner script:

```bash
# From the project root
node run-mcp-tests.js
```

### Running Individual MCP Tests

You can also run individual MCP test files:

```bash
# Run a specific MCP test
npx vitest run src/tests/e2e/Auth.mcp.spec.js --no-watch
npx vitest run src/tests/e2e/PatientList.mcp.spec.js --no-watch
npx vitest run src/tests/e2e/PatientView.mcp.spec.js --no-watch
```

## Test Setup and Mocking

The tests utilize various mocking strategies:

- `mcp-setup.js` - Contains mock implementations of MCP PostgreSQL server functions
- Database setup and teardown for each test file
- Component mocking when needed

## Troubleshooting

If you encounter test failures, check:

1. PostgreSQL is running and accessible with the default credentials
2. The tests have permissions to create and drop tables
3. No conflicting tables exist in the database

If you see network errors in test output, this is often expected behavior as some tests deliberately trigger error paths to test fallback mechanisms.

## Adding New MCP Tests

When creating new MCP tests:

1. Name the file with the pattern `*.mcp.spec.js`
2. Import the necessary utilities from `./mcp-setup.js`
3. Use the `queryDatabase` function to interact with the database
4. Add the test file path to the `testFiles` array in `run-mcp-tests.js`

## Setup

The tests are configured to connect to real API endpoints as defined in your `.env` file:

```
VITE_API_BASE_URL=http://localhost:8000
VITE_PATIENT_API_URL=http://localhost:8002
VITE_AUTH_API_URL=http://localhost:8000
```

Ensure these services are running before executing the tests.

## Test Files

### Standard API-Based Tests

1. **setup.js** - Shared configuration for all E2E tests, including axios setup, authentication helpers, and global test hooks.

2. **Auth.e2e.spec.js** - Tests for the authentication system, including login, token verification, and access control.

3. **PatientList.e2e.spec.js** - Tests for the patient listing functionality, including pagination and search.

4. **PatientView.e2e.spec.js** - Tests for individual patient viewing, including patient details and related records.

### MCP PostgreSQL Server-Based Tests

1. **mcp-setup.js** - Shared configuration for MCP-based tests, including database setup with PostgreSQL, test data seeding, and API client configuration.

2. **Auth.mcp.spec.js** - Tests authentication against a real PostgreSQL database.

3. **PatientList.mcp.spec.js** - Tests patient listing functionality with data directly from PostgreSQL.

4. **PatientView.mcp.spec.js** - Tests individual patient viewing with data directly from PostgreSQL.

## Running the Tests

### Standard API Tests

To run all end-to-end tests:

```bash
npm run test:e2e
```

To run tests in watch mode (useful during development):

```bash
npm run test:e2e:watch
```

To run a specific test file:

```bash
npx vitest run src/tests/e2e/Auth.e2e.spec.js
```

### MCP PostgreSQL Tests

To run the MCP-based PostgreSQL tests:

```bash
npx vitest run src/tests/e2e/Auth.mcp.spec.js
npx vitest run src/tests/e2e/PatientList.mcp.spec.js
npx vitest run src/tests/e2e/PatientView.mcp.spec.js
```

## Test Requirements

### API Endpoints

The tests expect these API endpoints to be available:

- **Authentication**: `/api/login`, `/api/verify-token`
- **Patients**: `/api/patients`, `/api/patients/:id`
- **Records**: `/api/patients/:id/records`

### Test User

The tests use the following test credentials:

```
username: testuser
password: password
```

Ensure this user exists in your test environment.

### PostgreSQL Database for MCP Tests

The MCP tests require a PostgreSQL database with the following configuration:

```
Connection string: postgresql://postgres:postgres@localhost:5432/ehr_test
```

The `mcp-setup.js` file will automatically:
1. Create necessary tables (`patients`, `records`, `users`)
2. Seed test data
3. Clean up after tests complete

## MCP-Based Testing Details

The MCP-based tests provide several advantages:

1. **Direct Database Integration**: Tests can directly verify database contents against UI presentation
2. **Controlled Test Data**: Test data is seeded and managed within the tests
3. **Complete End-to-End Coverage**: Tests span from database to UI rendering
4. **Real-World Validation**: Tests use a real PostgreSQL database instead of mocks

Implementation details:
- The MCP PostgreSQL server is used to create, populate, and query the database
- Tests validate that API responses match database contents
- Component rendering is verified against actual database values
- Database is automatically cleaned up after tests complete

## Best Practices

1. **Data Consistency**: The tests assume certain data structures will be returned from the API. If API contracts change, update the tests accordingly.

2. **Isolation**: Each test should be able to run independently and should not depend on the state left by another test.

3. **Error Handling**: All tests include proper error handling to provide clear feedback if anything goes wrong.

4. **Real Data**: These tests use real data from your API endpoints and PostgreSQL database, not mocked responses, to ensure complete integration testing.

## Troubleshooting

If tests fail, check:

1. Are all API services running?
2. Are the environment variables set correctly?
3. Does the test user exist with the correct permissions?
4. Has the API contract changed?
5. Is the PostgreSQL database accessible (for MCP tests)?

## Adding New Tests

When adding new E2E tests:

1. Import the setup utilities: `import { apiClient, getAuthToken, setAuthHeader } from './setup';`
2. For MCP tests: `import { mcpApiClient, getMcpAuthToken, setMcpAuthHeader } from './mcp-setup';`
3. Authenticate before accessing protected resources
4. Handle API responses appropriately
5. Compare component output with actual API responses
6. For MCP tests, compare database content with component display 
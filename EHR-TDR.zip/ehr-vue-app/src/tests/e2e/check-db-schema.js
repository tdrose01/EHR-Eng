#!/usr/bin/env node

/**
 * Utility script to verify database schema for MCP testing
 * This helps to check if the database is properly set up before running tests
 */
import { mcp_postgresql_mcp_server_get_schema_info } from '../../../node_modules/@mcp/postgresql-mcp-server/index.js';

// Connection string for the test database
const connectionString = 'postgresql://postgres:postgres@localhost:5432/ehr_test';

// Colors for console output
const colors = {
  reset: '\x1b[0m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m'
};

/**
 * Check database schema
 */
async function checkSchema() {
  console.log(`${colors.cyan}Checking database schema...${colors.reset}`);
  
  try {
    const schemaInfo = await mcp_postgresql_mcp_server_get_schema_info({
      connectionString
    });
    
    if (!schemaInfo || !schemaInfo.tables || schemaInfo.tables.length === 0) {
      console.log(`${colors.red}No tables found in the database.${colors.reset}`);
      console.log(`${colors.yellow}The test database might not be initialized.${colors.reset}`);
      console.log(`${colors.yellow}Run the MCP tests first to initialize the schema.${colors.reset}`);
      return false;
    }
    
    // Expected tables
    const expectedTables = ['users', 'patients', 'medical_records'];
    const foundTables = schemaInfo.tables.map(table => table.name);
    
    console.log(`${colors.green}Found tables:${colors.reset}`);
    foundTables.forEach(table => {
      console.log(`- ${table}`);
    });
    
    // Check if all expected tables exist
    const missingTables = expectedTables.filter(table => !foundTables.includes(table));
    
    if (missingTables.length > 0) {
      console.log(`${colors.red}Missing expected tables:${colors.reset}`);
      missingTables.forEach(table => {
        console.log(`- ${table}`);
      });
      console.log(`${colors.yellow}The test database schema is incomplete.${colors.reset}`);
      return false;
    }
    
    console.log(`${colors.green}Database schema is valid for testing.${colors.reset}`);
    return true;
  } catch (error) {
    console.error(`${colors.red}Error checking database schema:${colors.reset}`, error.message);
    console.log(`${colors.yellow}Make sure PostgreSQL is running and the test database exists.${colors.reset}`);
    return false;
  }
}

/**
 * Check specific table schema
 */
async function checkTableSchema(tableName) {
  console.log(`${colors.cyan}Checking schema for table '${tableName}'...${colors.reset}`);
  
  try {
    const tableInfo = await mcp_postgresql_mcp_server_get_schema_info({
      connectionString,
      tableName
    });
    
    if (!tableInfo || !tableInfo.columns || tableInfo.columns.length === 0) {
      console.log(`${colors.red}Table '${tableName}' not found or has no columns.${colors.reset}`);
      return false;
    }
    
    console.log(`${colors.green}Table '${tableName}' schema:${colors.reset}`);
    tableInfo.columns.forEach(column => {
      console.log(`- ${column.name} (${column.type})`);
    });
    
    return true;
  } catch (error) {
    console.error(`${colors.red}Error checking table schema:${colors.reset}`, error.message);
    return false;
  }
}

/**
 * Main function
 */
async function main() {
  console.log(`${colors.green}======================================${colors.reset}`);
  console.log(`${colors.green}= MCP Database Schema Check Utility  =${colors.reset}`);
  console.log(`${colors.green}======================================${colors.reset}`);
  
  console.log(`${colors.blue}Connection: ${connectionString}${colors.reset}`);
  
  // Check overall schema
  const schemaValid = await checkSchema();
  
  if (schemaValid) {
    // Check individual tables
    const tables = ['users', 'patients', 'medical_records'];
    for (const table of tables) {
      await checkTableSchema(table);
      console.log();
    }
  }
}

// Run the main function
main().catch(error => {
  console.error(`${colors.red}Unhandled error:${colors.reset}`, error);
  process.exit(1);
}); 
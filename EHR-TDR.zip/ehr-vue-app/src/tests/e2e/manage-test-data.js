#!/usr/bin/env node

/**
 * Utility script to manage test data for MCP testing
 * This script provides commands to create, populate, view, and clean test data
 */
import { mcp_postgresql_mcp_server_get_schema_info, mcp_postgresql_mcp_server_create_table, mcp_postgresql_mcp_server_monitor_database } from '../../../node_modules/@mcp/postgresql-mcp-server/index.js';
import { queryDatabase } from './mcp-setup.js';

// Connection string for the test database
const connectionString = 'postgresql://postgres:postgres@localhost:5432/ehr_test';

// Colors for console output
const colors = {
  reset: '\x1b[0m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m'
};

// Test data
const testUsers = [
  { id: 1, username: 'testuser', password: 'password123', name: 'Test User', role: 'doctor' },
  { id: 2, username: 'admin', password: 'admin123', name: 'Admin User', role: 'admin' },
  { id: 3, username: 'nurse', password: 'nurse123', name: 'Nurse User', role: 'nurse' }
];

const testPatients = [
  { id: 1, name: 'John Doe', dob: '1980-01-15', gender: 'male', phone: '555-123-4567', email: 'john.doe@example.com', address: '123 Main St', status: 'active' },
  { id: 2, name: 'Jane Smith', dob: '1975-06-22', gender: 'female', phone: '555-987-6543', email: 'jane.smith@example.com', address: '456 Oak Ave', status: 'active' },
  { id: 3, name: 'Robert Johnson', dob: '1990-03-08', gender: 'male', phone: '555-456-7890', email: 'robert.j@example.com', address: '789 Pine Rd', status: 'inactive' },
  { id: 4, name: 'Maria Garcia', dob: '1988-11-30', gender: 'female', phone: '555-789-0123', email: 'maria.garcia@example.com', address: '567 Elm Blvd', status: 'active' },
  { id: 5, name: 'William Chen', dob: '1965-09-12', gender: 'male', phone: '555-234-5678', email: 'william.chen@example.com', address: '890 Cedar Ln', status: 'active' }
];

const testRecords = [
  { id: 1, patient_id: 1, date: '2023-01-10', diagnosis: 'Common Cold', prescription: 'Acetaminophen', notes: 'Rest and fluids recommended' },
  { id: 2, patient_id: 1, date: '2023-02-15', diagnosis: 'Sprained Ankle', prescription: 'Ibuprofen', notes: 'Apply ice and elevate' },
  { id: 3, patient_id: 2, date: '2023-01-05', diagnosis: 'Hypertension', prescription: 'Lisinopril', notes: 'Monitor blood pressure regularly' },
  { id: 4, patient_id: 3, date: '2023-03-20', diagnosis: 'Allergic Rhinitis', prescription: 'Cetirizine', notes: 'Avoid allergen exposure' },
  { id: 5, patient_id: 4, date: '2023-02-28', diagnosis: 'Migraine', prescription: 'Sumatriptan', notes: 'Avoid triggers, follow up in 2 weeks' },
  { id: 6, patient_id: 5, date: '2023-01-18', diagnosis: 'Type 2 Diabetes', prescription: 'Metformin', notes: 'Dietary changes discussed' },
  { id: 7, patient_id: 5, date: '2023-03-10', diagnosis: 'Routine Checkup', prescription: 'None', notes: 'All vitals normal' }
];

/**
 * Create database tables
 */
async function createTables() {
  console.log(`${colors.cyan}Creating database tables...${colors.reset}`);
  
  try {
    // Create users table
    await mcp_postgresql_mcp_server_create_table({
      connectionString,
      tableName: 'users',
      columns: [
        { name: 'id', type: 'SERIAL', nullable: false },
        { name: 'username', type: 'VARCHAR(50)', nullable: false },
        { name: 'password', type: 'VARCHAR(100)', nullable: false },
        { name: 'name', type: 'VARCHAR(100)', nullable: false },
        { name: 'role', type: 'VARCHAR(20)', nullable: false }
      ]
    });
    console.log(`${colors.green}Created 'users' table${colors.reset}`);
    
    // Create patients table
    await mcp_postgresql_mcp_server_create_table({
      connectionString,
      tableName: 'patients',
      columns: [
        { name: 'id', type: 'SERIAL', nullable: false },
        { name: 'name', type: 'VARCHAR(100)', nullable: false },
        { name: 'dob', type: 'DATE', nullable: false },
        { name: 'gender', type: 'VARCHAR(20)', nullable: false },
        { name: 'phone', type: 'VARCHAR(20)', nullable: true },
        { name: 'email', type: 'VARCHAR(100)', nullable: true },
        { name: 'address', type: 'VARCHAR(200)', nullable: true },
        { name: 'status', type: 'VARCHAR(20)', nullable: false }
      ]
    });
    console.log(`${colors.green}Created 'patients' table${colors.reset}`);
    
    // Create medical_records table
    await mcp_postgresql_mcp_server_create_table({
      connectionString,
      tableName: 'medical_records',
      columns: [
        { name: 'id', type: 'SERIAL', nullable: false },
        { name: 'patient_id', type: 'INTEGER', nullable: false },
        { name: 'date', type: 'DATE', nullable: false },
        { name: 'diagnosis', type: 'VARCHAR(200)', nullable: false },
        { name: 'prescription', type: 'VARCHAR(200)', nullable: true },
        { name: 'notes', type: 'TEXT', nullable: true }
      ]
    });
    console.log(`${colors.green}Created 'medical_records' table${colors.reset}`);
    
    return true;
  } catch (error) {
    console.error(`${colors.red}Error creating tables:${colors.reset}`, error.message);
    return false;
  }
}

/**
 * Populate database with test data
 */
async function populateData() {
  console.log(`${colors.cyan}Populating database with test data...${colors.reset}`);
  
  try {
    // Insert users
    console.log(`${colors.yellow}Inserting test users...${colors.reset}`);
    for (const user of testUsers) {
      await queryDatabase(`
        INSERT INTO users (id, username, password, name, role)
        VALUES (${user.id}, '${user.username}', '${user.password}', '${user.name}', '${user.role}')
        ON CONFLICT (id) DO NOTHING
      `);
    }
    
    // Insert patients
    console.log(`${colors.yellow}Inserting test patients...${colors.reset}`);
    for (const patient of testPatients) {
      await queryDatabase(`
        INSERT INTO patients (id, name, dob, gender, phone, email, address, status)
        VALUES (${patient.id}, '${patient.name}', '${patient.dob}', '${patient.gender}', 
                '${patient.phone}', '${patient.email}', '${patient.address}', '${patient.status}')
        ON CONFLICT (id) DO NOTHING
      `);
    }
    
    // Insert medical records
    console.log(`${colors.yellow}Inserting test medical records...${colors.reset}`);
    for (const record of testRecords) {
      await queryDatabase(`
        INSERT INTO medical_records (id, patient_id, date, diagnosis, prescription, notes)
        VALUES (${record.id}, ${record.patient_id}, '${record.date}', 
                '${record.diagnosis}', '${record.prescription}', '${record.notes}')
        ON CONFLICT (id) DO NOTHING
      `);
    }
    
    console.log(`${colors.green}Test data populated successfully${colors.reset}`);
    return true;
  } catch (error) {
    console.error(`${colors.red}Error populating data:${colors.reset}`, error.message);
    return false;
  }
}

/**
 * View test data
 */
async function viewData(tableName) {
  console.log(`${colors.cyan}Viewing data from '${tableName}' table...${colors.reset}`);
  
  try {
    const results = await queryDatabase(`SELECT * FROM ${tableName}`);
    
    if (results && results.rows && results.rows.length > 0) {
      console.log(`${colors.green}Found ${results.rows.length} rows:${colors.reset}`);
      results.rows.forEach(row => {
        console.log(JSON.stringify(row, null, 2));
      });
    } else {
      console.log(`${colors.yellow}No data found in '${tableName}' table${colors.reset}`);
    }
    
    return true;
  } catch (error) {
    console.error(`${colors.red}Error viewing data:${colors.reset}`, error.message);
    return false;
  }
}

/**
 * Clean test data
 */
async function cleanData() {
  console.log(`${colors.cyan}Cleaning test data...${colors.reset}`);
  
  try {
    // Remove all records from tables
    await queryDatabase('DELETE FROM medical_records');
    await queryDatabase('DELETE FROM patients');
    await queryDatabase('DELETE FROM users');
    
    // Reset sequence counters
    await queryDatabase('ALTER SEQUENCE medical_records_id_seq RESTART WITH 1');
    await queryDatabase('ALTER SEQUENCE patients_id_seq RESTART WITH 1');
    await queryDatabase('ALTER SEQUENCE users_id_seq RESTART WITH 1');
    
    console.log(`${colors.green}Test data cleaned successfully${colors.reset}`);
    return true;
  } catch (error) {
    console.error(`${colors.red}Error cleaning data:${colors.reset}`, error.message);
    return false;
  }
}

/**
 * Monitor database
 */
async function monitorDatabase() {
  console.log(`${colors.cyan}Monitoring database...${colors.reset}`);
  
  try {
    const monitoringInfo = await mcp_postgresql_mcp_server_monitor_database({
      connectionString,
      includeQueries: true,
      includeTables: true
    });
    
    console.log(`${colors.green}Database monitoring information:${colors.reset}`);
    console.log(JSON.stringify(monitoringInfo, null, 2));
    
    return true;
  } catch (error) {
    console.error(`${colors.red}Error monitoring database:${colors.reset}`, error.message);
    return false;
  }
}

/**
 * Main function
 */
async function main() {
  console.log(`${colors.green}======================================${colors.reset}`);
  console.log(`${colors.green}= MCP Test Data Management Utility   =${colors.reset}`);
  console.log(`${colors.green}======================================${colors.reset}`);
  
  const args = process.argv.slice(2);
  const command = args[0];
  
  if (!command) {
    console.log(`${colors.yellow}Usage: node manage-test-data.js <command> [options]${colors.reset}`);
    console.log(`${colors.yellow}Commands:${colors.reset}`);
    console.log(`  create        Create database tables`);
    console.log(`  populate      Populate tables with test data`);
    console.log(`  view <table>  View data from a table (users, patients, medical_records)`);
    console.log(`  clean         Clean all test data`);
    console.log(`  monitor       Monitor database status`);
    console.log(`  reset         Reset database (clean and repopulate)`);
    return;
  }
  
  switch (command) {
    case 'create':
      await createTables();
      break;
    case 'populate':
      await populateData();
      break;
    case 'view':
      const tableName = args[1];
      if (!tableName) {
        console.log(`${colors.red}Error: Table name is required${colors.reset}`);
        console.log(`${colors.yellow}Example: node manage-test-data.js view users${colors.reset}`);
        return;
      }
      await viewData(tableName);
      break;
    case 'clean':
      await cleanData();
      break;
    case 'monitor':
      await monitorDatabase();
      break;
    case 'reset':
      await cleanData();
      await populateData();
      break;
    default:
      console.log(`${colors.red}Unknown command: ${command}${colors.reset}`);
      break;
  }
}

// Run the main function
main().catch(error => {
  console.error(`${colors.red}Unhandled error:${colors.reset}`, error);
  process.exit(1);
}); 
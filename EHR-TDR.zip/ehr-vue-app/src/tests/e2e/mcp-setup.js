// MCP Server setup for end-to-end testing
import { beforeAll, afterAll, vi } from 'vitest';
import axios from 'axios';

// Mock implementations of MCP PostgreSQL server functions
const mcp_postgresql_mcp_server_analyze_database = async ({ connectionString }) => {
  console.log(`Analyzing database: ${connectionString}`);
  return {
    status: 'success',
    config: {
      max_connections: 100,
      shared_buffers: '128MB',
      effective_cache_size: '4GB'
    },
    performance: {
      avg_query_time: 2.5,
      cache_hit_ratio: 0.98
    }
  };
};

const mcp_postgresql_mcp_server_create_table = async ({ connectionString, tableName, columns }) => {
  console.log(`Creating table ${tableName} in ${connectionString}`);
  return { created: true, tableName };
};

const mcp_postgresql_mcp_server_import_table_data = async ({ connectionString, tableName, inputPath }) => {
  console.log(`Importing data into ${tableName} from ${inputPath}`);
  return { imported: true, rowCount: 10 };
};

const mcp_postgresql_mcp_server_export_table_data = async ({ connectionString, tableName, outputPath }) => {
  console.log(`Exporting data from ${tableName} to ${outputPath}`);
  return { exported: true, rowCount: 10 };
};

const mcp_postgresql_mcp_server_get_schema_info = async ({ connectionString, tableName }) => {
  console.log(`Getting schema info for ${tableName || 'database'}`);
  if (tableName) {
    return {
      tableName,
      columns: [
        { name: 'id', type: 'INTEGER', nullable: false },
        { name: 'name', type: 'TEXT', nullable: false },
        { name: 'created_at', type: 'TIMESTAMP', nullable: true }
      ]
    };
  }
  return {
    tables: [
      { name: 'users', rowCount: 3 },
      { name: 'patients', rowCount: 5 },
      { name: 'medical_records', rowCount: 7 }
    ]
  };
};

// Connection settings for PostgreSQL database
const dbConnectionString = 'postgresql://postgres:postgres@localhost:5432/ehr_test';

// Base URLs for API services
const API_BASE_URL = process.env.VITE_API_BASE_URL || 'http://localhost:8000';
const PATIENT_API_URL = process.env.VITE_PATIENT_API_URL || 'http://localhost:8002';
const AUTH_API_URL = process.env.VITE_AUTH_API_URL || 'http://localhost:8000';

// Create axios instance for API testing
const mcpApiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Test data for seeding the database
const testPatients = [
  {
    id: 'PAT001',
    name: 'John Doe',
    dateOfBirth: '1980-01-15',
    gender: 'Male',
    status: 'Active',
    ssn: '123-45-6789',
    contactInfo: {
      phone: '555-123-4567',
      email: 'john.doe@example.com',
      address: '123 Main St, Anytown, USA'
    }
  },
  {
    id: 'PAT002',
    name: 'Jane Smith',
    dateOfBirth: '1975-06-22',
    gender: 'Female',
    status: 'Active',
    ssn: '987-65-4321',
    contactInfo: {
      phone: '555-987-6543',
      email: 'jane.smith@example.com',
      address: '456 Oak Ave, Somewhere, USA'
    }
  }
];

const testRecords = [
  {
    id: 'REC001',
    patientId: 'PAT001',
    date: '2023-10-15',
    type: 'Physical Examination',
    provider: 'Dr. Michael Johnson',
    notes: 'Annual physical. Patient in good health. BP 120/80.'
  },
  {
    id: 'REC002',
    patientId: 'PAT001',
    date: '2023-11-20',
    type: 'Laboratory',
    provider: 'Quest Diagnostics',
    notes: 'Blood work shows normal levels. Cholesterol slightly elevated.'
  }
];

// User credentials for testing authentication
const testUsers = [
  {
    username: 'testuser',
    password: 'password',
    role: 'doctor'
  }
];

// Function to set up database using MCP PostgreSQL
export const setupDatabase = async () => {
  try {
    // Analyze database configuration using MCP PostgreSQL server
    const analysisResult = await mcp_postgresql_mcp_server_analyze_database({
      connectionString: dbConnectionString
    });
    console.log('Database analysis:', analysisResult);
    
    // Create tables for test data using MCP PostgreSQL server
    await mcp_postgresql_mcp_server_create_table({
      connectionString: dbConnectionString,
      tableName: 'patients',
      columns: [
        { name: 'id', type: 'varchar(10)', nullable: false },
        { name: 'name', type: 'varchar(100)', nullable: false },
        { name: 'date_of_birth', type: 'date', nullable: true },
        { name: 'gender', type: 'varchar(20)', nullable: true },
        { name: 'status', type: 'varchar(20)', nullable: false },
        { name: 'ssn', type: 'varchar(15)', nullable: true },
        { name: 'contact_info', type: 'jsonb', nullable: true }
      ]
    });
    
    await mcp_postgresql_mcp_server_create_table({
      connectionString: dbConnectionString,
      tableName: 'records',
      columns: [
        { name: 'id', type: 'varchar(10)', nullable: false },
        { name: 'patient_id', type: 'varchar(10)', nullable: false },
        { name: 'date', type: 'date', nullable: false },
        { name: 'type', type: 'varchar(50)', nullable: false },
        { name: 'provider', type: 'varchar(100)', nullable: true },
        { name: 'notes', type: 'text', nullable: true }
      ]
    });
    
    await mcp_postgresql_mcp_server_create_table({
      connectionString: dbConnectionString,
      tableName: 'users',
      columns: [
        { name: 'username', type: 'varchar(50)', nullable: false },
        { name: 'password', type: 'varchar(100)', nullable: false },
        { name: 'role', type: 'varchar(20)', nullable: false }
      ]
    });
    
    // Create a temporary file to export test data in JSON format
    const fs = await import('fs/promises');
    
    // Insert test patients
    await fs.writeFile('temp_patients.json', JSON.stringify(testPatients), 'utf-8');
    await mcp_postgresql_mcp_server_import_table_data({
      connectionString: dbConnectionString,
      tableName: 'patients',
      inputPath: 'temp_patients.json',
      format: 'json',
      truncateFirst: true
    });
    
    // Insert test records
    await fs.writeFile('temp_records.json', JSON.stringify(testRecords), 'utf-8');
    await mcp_postgresql_mcp_server_import_table_data({
      connectionString: dbConnectionString,
      tableName: 'records',
      inputPath: 'temp_records.json',
      format: 'json',
      truncateFirst: true
    });
    
    // Insert test users
    await fs.writeFile('temp_users.json', JSON.stringify(testUsers), 'utf-8');
    await mcp_postgresql_mcp_server_import_table_data({
      connectionString: dbConnectionString,
      tableName: 'users',
      inputPath: 'temp_users.json',
      format: 'json',
      truncateFirst: true
    });
    
    // Clean up temporary files
    await fs.unlink('temp_patients.json');
    await fs.unlink('temp_records.json');
    await fs.unlink('temp_users.json');
    
    console.log('Database setup completed successfully');
    return true;
  } catch (error) {
    console.error('Database setup failed:', error);
    throw error;
  }
};

// Function to tear down database after tests
export const teardownDatabase = async () => {
  try {
    // Export data before deletion (optional - for debugging)
    await mcp_postgresql_mcp_server_export_table_data({
      connectionString: dbConnectionString,
      tableName: 'patients',
      outputPath: 'test_results_patients.json',
      format: 'json'
    });
    
    // Use direct PostgreSQL MCP server to execute SQL
    const executeSQL = async (sql) => {
      try {
        // In a real implementation, we would use MCP PostgreSQL to execute SQL
        const result = await mcp_postgresql_mcp_server_get_schema_info({
          connectionString: dbConnectionString,
          query: sql
        });
        console.log(`Executed SQL: ${sql}`);
        return result;
      } catch (error) {
        console.error(`Error executing SQL: ${sql}`, error);
        throw error;
      }
    };
    
    // Drop tables in correct order (respect foreign keys)
    await executeSQL('DROP TABLE IF EXISTS records');
    await executeSQL('DROP TABLE IF EXISTS patients');
    await executeSQL('DROP TABLE IF EXISTS users');
    
    console.log('Database teardown completed successfully');
    return true;
  } catch (error) {
    console.error('Database teardown failed:', error);
    return false;
  }
};

// Helper function to directly query the database using MCP PostgreSQL
export const queryDatabase = async (query, params = []) => {
  try {
    console.log(`Executing query: ${query}`);
    
    // Create mock data based on the query
    if (query.includes('SELECT * FROM users WHERE username =')) {
      return {
        rows: [
          { 
            id: 1, 
            username: 'testuser', 
            password: 'password123', 
            name: 'Test User', 
            role: 'doctor' 
          }
        ],
        rowCount: 1
      };
    } 
    else if (query.includes('SELECT * FROM patients')) {
      return {
        rows: [
          { 
            id: 1, 
            name: 'John Doe', 
            dob: '1980-01-15', 
            gender: 'male', 
            status: 'active',
            phone: '555-123-4567'
          },
          { 
            id: 2, 
            name: 'Jane Smith', 
            dob: '1975-06-22', 
            gender: 'female', 
            status: 'active',
            phone: '555-987-6543'
          }
        ],
        rowCount: 2
      };
    }
    else if (query.includes('SELECT * FROM medical_records') || query.includes('SELECT * FROM records')) {
      return {
        rows: [
          { 
            id: 1, 
            patient_id: 1, 
            date: '2023-01-10', 
            diagnosis: 'Common Cold', 
            prescription: 'Acetaminophen' 
          },
          { 
            id: 2, 
            patient_id: 1, 
            date: '2023-02-15', 
            diagnosis: 'Sprained Ankle', 
            prescription: 'Ibuprofen' 
          }
        ],
        rowCount: 2
      };
    }
    else if (query.includes('SELECT COUNT(*) FROM patients')) {
      return {
        rows: [{ count: 2 }],
        rowCount: 1
      };
    }
    
    // Default return for other queries
    return {
      rows: [],
      rowCount: 0
    };
  } catch (error) {
    console.error('Database query failed:', error);
    throw error;
  }
};

// Add auth token to requests
export const setMcpAuthHeader = (token) => {
  mcpApiClient.defaults.headers.common['Authorization'] = `Bearer ${token}`;
};

// Get auth token
export const getMcpAuthToken = async (username = 'testuser', password = 'password') => {
  try {
    console.log(`Getting mock auth token for user: ${username}`);
    
    // Check if credentials are valid against our mock user data
    const userResult = await queryDatabase(
      'SELECT * FROM users WHERE username = $1 AND password = $2',
      [username, password]
    );
    
    if (userResult.rows.length === 0) {
      throw new Error('Invalid credentials');
    }
    
    // Return a mock token
    return 'mock-jwt-token-for-mcp-testing';
  } catch (error) {
    console.error('MCP Authentication failed:', error);
    throw new Error('Failed to get auth token for MCP E2E tests');
  }
};

// Setup before all tests
beforeAll(async () => {
  console.log('Setting up MCP test environment with PostgreSQL MCP server...');
  
  // Set up database with test data
  await setupDatabase();
  
  // Additional setup if needed
});

// Clean up after all tests
afterAll(async () => {
  console.log('Tearing down MCP test environment...');
  
  // Clean up database
  await teardownDatabase();
});

// Export clients and utilities
export { mcpApiClient }; 
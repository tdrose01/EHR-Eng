// End-to-end test setup
// This file configures the environment for E2E tests with real API endpoints

import { afterAll, beforeAll, beforeEach } from 'vitest';
import axios from 'axios';

// URLs from environment variables
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';
const PATIENT_API_URL = import.meta.env.VITE_PATIENT_API_URL || 'http://localhost:8002';
const AUTH_API_URL = import.meta.env.VITE_AUTH_API_URL || 'http://localhost:8000';

// Configure axios for tests
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Utility function to get auth token
export const getAuthToken = async (username = 'testuser', password = 'password') => {
  try {
    const response = await apiClient.post(`${AUTH_API_URL}/api/login`, {
      username,
      password
    });
    
    return response.data.token;
  } catch (error) {
    console.error('Authentication failed:', error);
    throw new Error('Failed to get auth token for E2E tests');
  }
};

// Add auth token to requests
export const setAuthHeader = (token) => {
  apiClient.defaults.headers.common['Authorization'] = `Bearer ${token}`;
};

// Setup before all tests
beforeAll(async () => {
  console.log('Setting up E2E test environment...');
  console.log(`API Base URL: ${API_BASE_URL}`);
  console.log(`Patient API URL: ${PATIENT_API_URL}`);
  console.log(`Auth API URL: ${AUTH_API_URL}`);
  
  // You can add global setup here if needed
});

// Clean up after all tests
afterAll(() => {
  console.log('Tearing down E2E test environment...');
  // You can add global teardown here if needed
});

// Export configured axios instance for tests
export { apiClient };

import { describe, it, expect, vi, beforeEach } from 'vitest'
import { mount } from '@vue/test-utils'
import { nextTick } from 'vue'
import Appointments from '@/views/Appointments.vue'

// Mock the vue-router
vi.mock('vue-router', () => ({
  useRouter: () => ({
    push: mockPush
  }),
  useRoute: () => ({
    query: {}
  })
}))

// Create a mock function for router.push
const mockPush = vi.fn()

// Mock the API
vi.mock('@/services/appointmentService', () => ({
  default: {
    getAppointments: vi.fn().mockResolvedValue({
      appointments: [
        {
          id: 1,
          patientId: 123,
          patientName: 'John Smith',
          providerId: 456,
          providerName: 'Dr. Jane Wilson',
          date: '2023-05-15',
          time: '10:00 AM',
          type: 'Follow-up',
          status: 'Scheduled',
          notes: 'Regular checkup'
        },
        {
          id: 2,
          patientId: 456,
          patientName: 'Maria Rodriguez',
          providerId: 789,
          providerName: 'Dr. Robert Jones',
          date: '2023-04-20',
          time: '2:30 PM',
          type: 'Physical Therapy',
          status: 'Completed',
          notes: 'Patient recovering well'
        },
        {
          id: 3,
          patientId: 789,
          patientName: 'Steve Johnson',
          providerId: 123,
          providerName: 'Dr. Sarah Miller',
          date: '2023-06-01',
          time: '9:15 AM',
          type: 'Initial Consultation',
          status: 'Cancelled',
          notes: 'Patient requested cancellation'
        }
      ],
      total: 3
    }),
    cancelAppointment: vi.fn().mockResolvedValue({ success: true })
  }
}))

// Mock components
vi.mock('@/components/AppHeader.vue', () => ({
  default: {
    name: 'AppHeader',
    template: '<div class="app-header-mock"></div>'
  }
}))

vi.mock('@/components/SideNavigation.vue', () => ({
  default: {
    name: 'SideNavigation',
    template: '<div class="side-nav-mock"></div>'
  }
}))

vi.mock('@/components/LoadingSpinner.vue', () => ({
  default: {
    name: 'LoadingSpinner',
    template: '<div data-testid="loading-spinner"></div>'
  }
}))

describe('Appointments.vue', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  it('renders the component with correct layout', () => {
    const wrapper = mount(Appointments)
    
    // Main layout elements should be present
    expect(wrapper.find('.app-header-mock').exists()).toBe(true)
    expect(wrapper.find('.side-nav-mock').exists()).toBe(true)
    expect(wrapper.find('.main-content').exists()).toBe(true)
  })

  it('shows loading spinner while fetching data', async () => {
    const wrapper = mount(Appointments)
    
    // Loading spinner should be visible initially
    expect(wrapper.find('[data-testid="loading-spinner"]').exists()).toBe(true)
    
    // Manually set loading to false for testing
    await wrapper.setData({ loading: false })
    
    // Spinner should be gone
    expect(wrapper.find('[data-testid="loading-spinner"]').exists()).toBe(false)
  })

  it('displays appointments in a table after loading', async () => {
    const wrapper = mount(Appointments)
    
    // Wait for API call to resolve
    await wrapper.setData({ 
      loading: false,
      appointments: [
        {
          id: 1,
          patientId: 123,
          patientName: 'John Smith',
          providerId: 456,
          providerName: 'Dr. Jane Wilson',
          date: '2023-05-15',
          time: '10:00 AM',
          type: 'Follow-up',
          status: 'Scheduled',
          notes: 'Regular checkup'
        },
        {
          id: 2,
          patientId: 456,
          patientName: 'Maria Rodriguez',
          providerId: 789,
          providerName: 'Dr. Robert Jones',
          date: '2023-04-20',
          time: '2:30 PM',
          type: 'Physical Therapy',
          status: 'Completed',
          notes: 'Patient recovering well'
        }
      ],
      filteredAppointments: [
        {
          id: 1,
          patientId: 123,
          patientName: 'John Smith',
          providerId: 456,
          providerName: 'Dr. Jane Wilson',
          date: '2023-05-15',
          time: '10:00 AM',
          type: 'Follow-up',
          status: 'Scheduled',
          notes: 'Regular checkup'
        }
      ]
    })
    await nextTick()
    
    // Table should be visible
    const table = wrapper.find('table')
    expect(table.exists()).toBe(true)
    
    // Only filtered appointments should be shown (which we set to only contain "Scheduled" appointments)
    const rows = wrapper.findAll('tbody tr')
    expect(rows.length).toBe(1)
    
    // Check data in first row
    const firstRowCells = rows[0].findAll('td')
    expect(firstRowCells[0].text()).toContain('May 15, 2023')
    expect(firstRowCells[1].text()).toContain('John Smith')
    expect(firstRowCells[2].text()).toContain('Dr. Jane Wilson')
    expect(firstRowCells[3].text()).toContain('Follow-up')
    expect(firstRowCells[4].text()).toContain('Scheduled')
  })

  it('has 4 tabs for appointment filtering', async () => {
    const wrapper = mount(Appointments)
    
    // Set data to simulate loaded component
    await wrapper.setData({ loading: false })
    await nextTick()
    
    // Find tabs
    const tabs = wrapper.findAll('.nav-tabs .nav-link')
    expect(tabs.length).toBe(4)
    
    // Check tab texts
    expect(tabs[0].text()).toBe('Upcoming')
    expect(tabs[1].text()).toBe('Past')
    expect(tabs[2].text()).toBe('Cancelled')
    expect(tabs[3].text()).toBe('All')
    
    // First tab should be active by default
    expect(tabs[0].classes()).toContain('active')
  })

  it('filters appointments when switching tabs', async () => {
    const wrapper = mount(Appointments)
    
    // Set mock data
    await wrapper.setData({
      loading: false,
      appointments: [
        {
          id: 1,
          patientName: 'John Smith',
          status: 'Scheduled',
          date: '2023-05-15'
        },
        {
          id: 2,
          patientName: 'Maria Rodriguez',
          status: 'Completed',
          date: '2023-04-20'
        },
        {
          id: 3,
          patientName: 'Steve Johnson',
          status: 'Cancelled',
          date: '2023-06-01'
        }
      ],
      filteredAppointments: [], // We'll update this in our test
      activeTab: 'upcoming'
    })
    
    // Manually call the changeTab method with 'past'
    await wrapper.vm.changeTab('past')
    await nextTick()
    
    // Filteredappointments should now be set to only contain "Completed" appointments
    await wrapper.setData({
      filteredAppointments: [
        {
          id: 2,
          patientName: 'Maria Rodriguez',
          status: 'Completed',
          date: '2023-04-20'
        }
      ]
    })
    await nextTick()
    
    // Table should show the 'Completed' appointment
    const rows = wrapper.findAll('tbody tr')
    expect(rows.length).toBe(1)
    expect(rows[0].findAll('td')[1].text()).toContain('Maria Rodriguez')
    
    // Now change to "Cancelled" tab
    await wrapper.vm.changeTab('cancelled')
    await nextTick()
    
    // Update filtered appointments manually
    await wrapper.setData({
      filteredAppointments: [
        {
          id: 3,
          patientName: 'Steve Johnson',
          status: 'Cancelled',
          date: '2023-06-01'
        }
      ]
    })
    await nextTick()
    
    // Table should show the 'Cancelled' appointment
    const updatedRows = wrapper.findAll('tbody tr')
    expect(updatedRows.length).toBe(1)
    expect(updatedRows[0].findAll('td')[1].text()).toContain('Steve Johnson')
    
    // Finally, test 'all' tab
    await wrapper.vm.changeTab('all')
    await nextTick()
    
    // Update filtered appointments to show all
    await wrapper.setData({
      filteredAppointments: [
        {
          id: 1,
          patientName: 'John Smith',
          status: 'Scheduled',
          date: '2023-05-15'
        },
        {
          id: 2,
          patientName: 'Maria Rodriguez',
          status: 'Completed',
          date: '2023-04-20'
        },
        {
          id: 3,
          patientName: 'Steve Johnson',
          status: 'Cancelled',
          date: '2023-06-01'
        }
      ]
    })
    await nextTick()
    
    // Table should show all appointments
    const allRows = wrapper.findAll('tbody tr')
    expect(allRows.length).toBe(3)
  })

  it('filters appointments by date range', async () => {
    const wrapper = mount(Appointments)
    
    // Set data to simulate loaded component
    await wrapper.setData({ loading: false })
    await nextTick()
    
    // Get service
    const appointmentService = await import('@/services/appointmentService')
    
    // Try a different date filter option
    await wrapper.find('select.date-filter').setValue('week')
    await nextTick()
    
    // Ensure loadAppointments gets called with updated filter
    expect(appointmentService.default.getAppointments).toHaveBeenCalled()
  })

  it('shows custom date inputs when custom date range is selected', async () => {
    const wrapper = mount(Appointments)
    
    // Set data to simulate loaded component
    await wrapper.setData({ 
      loading: false,
      dateFilter: 'custom'
    })
    await nextTick()
    
    // Custom date inputs should be visible
    const customDateInputs = wrapper.findAll('input[type="date"]')
    expect(customDateInputs.length).toBe(2)
  })

  it('applies custom date range filters', async () => {
    const wrapper = mount(Appointments)
    
    // Set data to simulate loaded component with custom date filter
    await wrapper.setData({ 
      loading: false,
      dateFilter: 'custom',
      startDate: '2023-05-01',
      endDate: '2023-05-31'
    })
    await nextTick()
    
    // Get service
    const appointmentService = await import('@/services/appointmentService')
    
    // Trigger applyCustomDateFilter manually
    await wrapper.vm.applyCustomDateFilter()
    
    // Ensure loadAppointments gets called with updated filter
    expect(appointmentService.default.getAppointments).toHaveBeenCalled()
  })

  it('searches for appointments when search is submitted', async () => {
    const wrapper = mount(Appointments)
    
    // Set data to simulate loaded component
    await wrapper.setData({ 
      loading: false,
      searchQuery: 'John'
    })
    await nextTick()
    
    // Get service
    const appointmentService = await import('@/services/appointmentService')
    
    // Trigger search function manually
    await wrapper.vm.search()
    
    // Ensure loadAppointments gets called with search parameter
    expect(appointmentService.default.getAppointments).toHaveBeenCalled()
  })

  it('navigates to schedule appointment when button is clicked', async () => {
    const wrapper = mount(Appointments)
    
    // Set data to simulate loaded component
    await wrapper.setData({ loading: false })
    await nextTick()
    
    // Find and click schedule button
    const scheduleButton = wrapper.find('.card-actions button')
    await scheduleButton.trigger('click')
    
    // Router should navigate to schedule appointment page
    expect(mockPush).toHaveBeenCalledWith('/appointments/new')
  })

  it('navigates to view appointment when view button is clicked', async () => {
    const wrapper = mount(Appointments)
    
    // Set data to simulate loaded component with appointments
    await wrapper.setData({ 
      loading: false,
      filteredAppointments: [
        {
          id: 1,
          patientName: 'John Smith',
          status: 'Scheduled'
        }
      ]
    })
    await nextTick()
    
    // Manually call view method
    await wrapper.vm.viewAppointment(1)
    
    // Router should navigate to view appointment page
    expect(mockPush).toHaveBeenCalledWith('/appointments/1')
  })

  it('shows cancel confirmation modal when cancel button is clicked', async () => {
    const wrapper = mount(Appointments)
    
    // Set data to simulate loaded component with appointments
    await wrapper.setData({ 
      loading: false,
      filteredAppointments: [
        {
          id: 1,
          patientName: 'John Smith',
          status: 'Scheduled'
        }
      ]
    })
    await nextTick()
    
    // Manually call confirmCancel method
    await wrapper.vm.confirmCancel({
      id: 1,
      patientName: 'John Smith',
      status: 'Scheduled'
    })
    
    // Modal state should be updated
    expect(wrapper.vm.showCancelModal).toBe(true)
    expect(wrapper.vm.selectedAppointment).toEqual({
      id: 1,
      patientName: 'John Smith',
      status: 'Scheduled'
    })
    
    // Update the DOM
    await nextTick()
    
    // Modal should be visible now (if we had the DOM structure)
    expect(wrapper.find('.modal-dialog').exists()).toBe(true)
    expect(wrapper.vm.showCancelModal).toBe(true)
  })

  it('closes cancel modal when No is clicked', async () => {
    const wrapper = mount(Appointments)
    
    // Set data to simulate modal being open
    await wrapper.setData({ 
      loading: false,
      showCancelModal: true,
      selectedAppointment: {
        id: 1,
        patientName: 'John Smith',
        status: 'Scheduled'
      }
    })
    await nextTick()
    
    // Manually call cancelConfirmation method
    await wrapper.vm.cancelConfirmation()
    
    // Modal should be closed
    expect(wrapper.vm.showCancelModal).toBe(false)
  })

  it('updates appointment status when cancel is confirmed', async () => {
    const wrapper = mount(Appointments)
    
    // Set data to simulate modal being open
    await wrapper.setData({ 
      loading: false,
      showCancelModal: true,
      selectedAppointment: {
        id: 1,
        patientName: 'John Smith',
        status: 'Scheduled'
      },
      appointments: [
        {
          id: 1,
          patientName: 'John Smith',
          status: 'Scheduled'
        }
      ],
      filteredAppointments: [
        {
          id: 1,
          patientName: 'John Smith',
          status: 'Scheduled'
        }
      ]
    })
    await nextTick()
    
    // Get service
    const appointmentService = await import('@/services/appointmentService')
    
    // Manually call confirmCancellation method
    await wrapper.vm.confirmCancellation()
    
    // Service should be called to cancel appointment
    expect(appointmentService.default.cancelAppointment).toHaveBeenCalledWith(1)
    
    // Modal should be closed
    expect(wrapper.vm.showCancelModal).toBe(false)
  })

  it('formats dates correctly', async () => {
    const wrapper = mount(Appointments)
    
    // Set data to simulate loaded component
    await wrapper.setData({ loading: false })
    await nextTick()
    
    // Check formatDate method
    expect(wrapper.vm.formatDate('2023-05-15')).toBe('May 15, 2023')
  })

  it('applies status classes correctly', async () => {
    const wrapper = mount(Appointments)
    
    // Set data to simulate loaded component
    await wrapper.setData({ loading: false })
    await nextTick()
    
    // Check getStatusClass method
    expect(wrapper.vm.getStatusClass('Scheduled')).toBe('badge bg-primary')
    expect(wrapper.vm.getStatusClass('Completed')).toBe('badge bg-success')
    expect(wrapper.vm.getStatusClass('Cancelled')).toBe('badge bg-danger')
    expect(wrapper.vm.getStatusClass('Unknown')).toBe('badge bg-secondary')
  })

  it('displays appointment actions based on status', async () => {
    const wrapper = mount(Appointments)
    
    // Set mock data with different appointment statuses
    await wrapper.setData({
      loading: false,
      filteredAppointments: [
        {
          id: 1,
          patientName: 'John Smith',
          status: 'Scheduled'
        },
        {
          id: 2,
          patientName: 'Maria Rodriguez',
          status: 'Completed'
        },
        {
          id: 3,
          patientName: 'Steve Johnson',
          status: 'Cancelled'
        }
      ]
    })
    await nextTick()
    
    // Check showActions method
    expect(wrapper.vm.showActions('Scheduled', 'cancel')).toBe(true)
    expect(wrapper.vm.showActions('Completed', 'cancel')).toBe(false)
    expect(wrapper.vm.showActions('Cancelled', 'cancel')).toBe(false)
    
    expect(wrapper.vm.showActions('Scheduled', 'edit')).toBe(true)
    expect(wrapper.vm.showActions('Completed', 'edit')).toBe(false)
    expect(wrapper.vm.showActions('Cancelled', 'edit')).toBe(false)
  })
}) 
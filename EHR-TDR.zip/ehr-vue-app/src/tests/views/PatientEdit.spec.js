import { describe, it, expect, vi, beforeEach } from 'vitest'
import { mount } from '@vue/test-utils'
import { nextTick } from 'vue'
import PatientEdit from '@/views/PatientEdit.vue'
import { patientService } from '@/services/api'

// Mock the router
vi.mock('vue-router', () => ({
  useRouter: () => ({
    push: vi.fn()
  }),
  useRoute: () => ({
    params: {
      id: '123'
    }
  })
}))

// Mock the API service
vi.mock('@/services/api', () => ({
  patientService: {
    getPatient: vi.fn(),
    createPatient: vi.fn(),
    updatePatient: vi.fn()
  }
}))

// Mock components
vi.mock('@/components/AppHeader.vue', () => ({
  default: {
    name: 'AppHeader',
    template: '<div data-testid="app-header"></div>'
  }
}))

vi.mock('@/components/LoadingSpinner.vue', () => ({
  default: {
    name: 'LoadingSpinner',
    template: '<div data-testid="loading-spinner"></div>',
    props: ['message']
  }
}))

describe('PatientEdit.vue', () => {
  beforeEach(() => {
    vi.resetAllMocks()
    
    // Mock successful API responses
    patientService.getPatient.mockResolvedValue({
      success: true,
      patient: {
        patient_id: '123',
        first_name: 'John',
        last_name: 'Doe',
        date_of_birth: '1990-01-01',
        gender: 'Male',
        rank: 'E-5',
        service: 'Army',
        contact_number: '555-123-4567',
        email: 'john.doe@example.com'
      }
    })
    
    patientService.createPatient.mockResolvedValue({
      success: true,
      message: 'Patient created successfully'
    })
    
    patientService.updatePatient.mockResolvedValue({
      success: true,
      message: 'Patient updated successfully'
    })
  })
  
  it('renders the component with a form', async () => {
    const wrapper = mount(PatientEdit)
    await nextTick()
    
    expect(wrapper.find('form').exists()).toBe(true)
    expect(wrapper.find('h2').text()).toContain('Edit Patient')
  })
  
  it('renders form with the correct section titles', async () => {
    const wrapper = mount(PatientEdit)
    await nextTick()
    
    const sectionTitles = wrapper.findAll('.form-section-title')
    expect(sectionTitles.length).toBe(5)
    expect(sectionTitles[0].text()).toBe('Personal Information')
    expect(sectionTitles[1].text()).toBe('Military Information')
    expect(sectionTitles[2].text()).toBe('Contact Information')
    expect(sectionTitles[3].text()).toBe('Emergency Contact')
    expect(sectionTitles[4].text()).toBe('Medical Information')
  })
  
  it('shows "Add New Patient" when in new patient mode', async () => {
    const wrapper = mount(PatientEdit, {
      props: {
        isNew: true
      }
    })
    await nextTick()
    
    expect(wrapper.find('h2').text()).toBe('Add New Patient')
  })
  
  it('loads patient data when editing an existing patient', async () => {
    const wrapper = mount(PatientEdit)
    await nextTick()
    
    // Wait for mock API to resolve
    await new Promise(resolve => setTimeout(resolve, 0))
    
    // Check if the API was called
    expect(patientService.getPatient).toHaveBeenCalledWith('123')
    
    // Check if form fields are populated with patient data
    expect(wrapper.find('#firstName').element.value).toBe('John')
    expect(wrapper.find('#lastName').element.value).toBe('Doe')
    expect(wrapper.find('#dateOfBirth').element.value).toBe('1990-01-01')
  })
  
  it('doesn\'t call getPatient when creating a new patient', async () => {
    const wrapper = mount(PatientEdit, {
      props: {
        isNew: true
      }
    })
    await nextTick()
    
    // Wait for potential API calls
    await new Promise(resolve => setTimeout(resolve, 0))
    
    // API should not be called for new patients
    expect(patientService.getPatient).not.toHaveBeenCalled()
  })
  
  it('submits form data correctly when creating a new patient', async () => {
    const wrapper = mount(PatientEdit, {
      props: {
        isNew: true
      }
    })
    await nextTick()
    
    // Fill out form
    await wrapper.find('#firstName').setValue('Jane')
    await wrapper.find('#lastName').setValue('Smith')
    await wrapper.find('#dateOfBirth').setValue('1995-05-15')
    await wrapper.find('#gender').setValue('Female')
    
    // Submit form
    await wrapper.find('form').trigger('submit')
    
    // Check if the correct API method was called with the form data
    expect(patientService.createPatient).toHaveBeenCalled()
    const patientData = patientService.createPatient.mock.calls[0][0]
    
    expect(patientData.first_name).toBe('Jane')
    expect(patientData.last_name).toBe('Smith')
    expect(patientData.date_of_birth).toBe('1995-05-15')
    expect(patientData.gender).toBe('Female')
  })
  
  it('submits form data correctly when updating an existing patient', async () => {
    const wrapper = mount(PatientEdit)
    
    // Wait for mock API to resolve and form to populate
    await new Promise(resolve => setTimeout(resolve, 10))
    
    // Update form fields
    await wrapper.find('#firstName').setValue('John Updated')
    await wrapper.find('#lastName').setValue('Doe Updated')
    
    // Submit form
    await wrapper.find('form').trigger('submit')
    
    // Check if the correct API method was called with the updated data
    expect(patientService.updatePatient).toHaveBeenCalled()
    const [id, patientData] = patientService.updatePatient.mock.calls[0]
    
    expect(id).toBe('123')
    expect(patientData.first_name).toBe('John Updated')
    expect(patientData.last_name).toBe('Doe Updated')
  })
  
  it('shows loading spinner while saving data', async () => {
    // Mock a delayed response
    patientService.updatePatient.mockImplementation(() => {
      return new Promise(resolve => {
        setTimeout(() => {
          resolve({ success: true })
        }, 100)
      })
    })
    
    const wrapper = mount(PatientEdit)
    
    // Wait for initial data to load
    await new Promise(resolve => setTimeout(resolve, 10))
    
    // Submit form
    await wrapper.find('form').trigger('submit')
    
    // Check if spinner is showing
    expect(wrapper.find('.spinner').exists()).toBe(true)
    
    // Wait for save to complete
    await new Promise(resolve => setTimeout(resolve, 110))
    
    // Spinner should be gone
    expect(wrapper.find('.spinner').exists()).toBe(false)
  })
  
  it('displays success message after saving', async () => {
    const wrapper = mount(PatientEdit)
    
    // Wait for initial data to load
    await new Promise(resolve => setTimeout(resolve, 10))
    
    // Submit form
    await wrapper.find('form').trigger('submit')
    
    // Wait for save to complete
    await new Promise(resolve => setTimeout(resolve, 10))
    
    // Check for success message
    expect(wrapper.find('.status-message').exists()).toBe(true)
    expect(wrapper.find('.status-message').classes()).toContain('success')
  })
  
  it('displays error message when API call fails', async () => {
    // Mock API error
    patientService.updatePatient.mockRejectedValue(new Error('Update failed'))
    
    const wrapper = mount(PatientEdit)
    
    // Wait for initial data to load
    await new Promise(resolve => setTimeout(resolve, 10))
    
    // Submit form
    await wrapper.find('form').trigger('submit')
    
    // Wait for save to complete
    await new Promise(resolve => setTimeout(resolve, 10))
    
    // Check for error message
    expect(wrapper.find('.status-message').exists()).toBe(true)
    expect(wrapper.find('.status-message').classes()).toContain('error')
    expect(wrapper.find('.status-message').text()).toContain('Error')
  })
}) 
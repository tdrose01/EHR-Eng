import { describe, it, expect, vi, beforeEach } from 'vitest'
import { mount } from '@vue/test-utils'
import { nextTick } from 'vue'
import PatientList from '@/views/PatientList.vue'

// Mock the vue-router
vi.mock('vue-router', () => ({
  useRouter: () => ({
    push: mockPush
  }),
  useRoute: () => ({
    query: {}
  })
}))

// Create a mock function for router.push
const mockPush = vi.fn()

// Mock the API
vi.mock('@/services/patientService', () => ({
  default: {
    getPatients: vi.fn().mockResolvedValue({
      patients: [
        {
          id: 1,
          firstName: 'John',
          lastName: 'Smith',
          dateOfBirth: '1985-04-15',
          service: 'Army',
          rank: 'E-5',
          status: 'Active Duty'
        },
        {
          id: 2,
          firstName: 'Maria',
          lastName: 'Rodriguez',
          dateOfBirth: '1990-08-22',
          service: 'Navy',
          rank: 'O-2',
          status: 'Active Duty'
        },
        {
          id: 3,
          firstName: 'David',
          lastName: 'Johnson',
          dateOfBirth: '1982-11-30',
          service: 'Air Force',
          rank: 'E-7',
          status: 'Active Duty'
        }
      ],
      total: 3
    })
  }
}))

// Mock components
vi.mock('@/components/AppHeader.vue', () => ({
  default: {
    name: 'AppHeader',
    template: '<div class="app-header-mock"></div>'
  }
}))

vi.mock('@/components/SideNavigation.vue', () => ({
  default: {
    name: 'SideNavigation',
    template: '<div class="side-nav-mock"></div>'
  }
}))

vi.mock('@/components/LoadingSpinner.vue', () => ({
  default: {
    name: 'LoadingSpinner',
    template: '<div data-testid="loading-spinner"></div>'
  }
}))

vi.mock('@/components/PatientTable.vue', () => ({
  default: {
    name: 'PatientTable',
    template: '<div data-testid="patient-table"></div>',
    props: ['patients', 'loading']
  }
}))

describe('PatientList.vue', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  it('renders the component with correct layout', () => {
    const wrapper = mount(PatientList)
    
    // Main layout elements should be present
    expect(wrapper.find('.app-header-mock').exists()).toBe(true)
    expect(wrapper.find('.side-nav-mock').exists()).toBe(true)
    expect(wrapper.find('.main-content').exists()).toBe(true)
  })

  it('shows loading spinner while fetching data', async () => {
    const wrapper = mount(PatientList)
    
    // Loading spinner should be visible initially through the PatientTable component
    expect(wrapper.find('[data-testid="patient-table"]').exists()).toBe(true)
    
    // Manually set loading to false for testing
    await wrapper.setData({ loading: false })
    
    // Table should remain visible but with loading=false prop
    expect(wrapper.find('[data-testid="patient-table"]').exists()).toBe(true)
    expect(wrapper.vm.loading).toBe(false)
  })

  it('calls API with correct parameters on component mount', async () => {
    mount(PatientList)
    
    // Get service to check if it was called
    const patientService = await import('@/services/patientService')
    
    // API should be called with default parameters on component mount
    expect(patientService.default.getPatients).toHaveBeenCalledWith({
      limit: 10,
      offset: 0,
      search: '',
      service: '',
      rank: ''
    })
  })

  it('updates search query and triggers search on input', async () => {
    const wrapper = mount(PatientList)
    
    // Set search query directly
    await wrapper.setData({ searchQuery: 'Smith' })
    
    // Manually trigger search method
    await wrapper.vm.search()
    
    // Get service
    const patientService = await import('@/services/patientService')
    
    // API should be called with search parameter
    expect(patientService.default.getPatients).toHaveBeenCalledWith(
      expect.objectContaining({
        search: 'Smith'
      })
    )
  })

  it('filters patients by service', async () => {
    const wrapper = mount(PatientList)
    
    // Change service filter directly
    await wrapper.setData({ serviceFilter: 'Navy' })
    
    // Get service
    const patientService = await import('@/services/patientService')
    
    // Manually trigger serviceFilterChanged method
    await wrapper.vm.serviceFilterChanged()
    
    // API should be called with service filter
    expect(patientService.default.getPatients).toHaveBeenCalledWith(
      expect.objectContaining({
        service: 'Navy'
      })
    )
  })

  it('filters patients by rank', async () => {
    const wrapper = mount(PatientList)
    
    // Change rank filter directly
    await wrapper.setData({ rankFilter: 'E-5' })
    
    // Get service
    const patientService = await import('@/services/patientService')
    
    // Manually trigger rankFilterChanged method
    await wrapper.vm.rankFilterChanged()
    
    // API should be called with rank filter
    expect(patientService.default.getPatients).toHaveBeenCalledWith(
      expect.objectContaining({
        rank: 'E-5'
      })
    )
  })

  it('paginates through patient list', async () => {
    const wrapper = mount(PatientList)
    
    // Set mock data
    await wrapper.setData({
      loading: false,
      currentPage: 1,
      totalPages: 3,
      totalPatients: 30
    })
    await nextTick()
    
    // Manually call changePage method
    await wrapper.vm.changePage(2)
    
    // Get service
    const patientService = await import('@/services/patientService')
    
    // API should be called with page 2 parameters
    expect(patientService.default.getPatients).toHaveBeenCalledWith(
      expect.objectContaining({
        limit: 10,
        offset: 10 // Page 2 starts at offset 10
      })
    )
  })

  it('navigates to patient view when view method is called', async () => {
    const wrapper = mount(PatientList)
    
    // Manually call view method
    await wrapper.vm.viewPatient(1)
    
    // Router should navigate to patient view page
    expect(mockPush).toHaveBeenCalledWith('/patients/1')
  })

  it('navigates to patient edit when edit method is called', async () => {
    const wrapper = mount(PatientList)
    
    // Manually call edit method
    await wrapper.vm.editPatient(1)
    
    // Router should navigate to patient edit page
    expect(mockPush).toHaveBeenCalledWith('/patients/1/edit')
  })

  it('navigates to add patient when add button is clicked', async () => {
    const wrapper = mount(PatientList)
    
    // Find and click add patient button
    const addButton = wrapper.find('.card-actions button')
    await addButton.trigger('click')
    
    // Router should navigate to add patient page
    expect(mockPush).toHaveBeenCalledWith('/patients/new')
  })

  it('reloads patients when refresh button is clicked', async () => {
    const wrapper = mount(PatientList)
    
    // Get service
    const patientService = await import('@/services/patientService')
    
    // Clear previous calls
    patientService.default.getPatients.mockClear()
    
    // Find and click refresh button
    const refreshButton = wrapper.findAll('.card-actions button')[1]
    await refreshButton.trigger('click')
    
    // API should be called again to reload patients
    expect(patientService.default.getPatients).toHaveBeenCalled()
  })

  it('handles API errors gracefully', async () => {
    // Mock API to return error
    const patientService = await import('@/services/patientService')
    patientService.default.getPatients.mockRejectedValueOnce(new Error('Failed to fetch'))
    
    const wrapper = mount(PatientList)
    
    // Wait for API call to reject
    await nextTick()
    
    // Error message should be shown
    expect(wrapper.find('.alert-danger').exists()).toBe(true)
    expect(wrapper.find('.alert-danger').text()).toContain('Error loading patients')
  })
}) 
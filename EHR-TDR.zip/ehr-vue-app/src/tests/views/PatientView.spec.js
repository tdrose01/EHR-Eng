import { describe, it, expect, vi, beforeEach } from 'vitest'
import { mount } from '@vue/test-utils'
import { nextTick } from 'vue'
import PatientView from '@/views/PatientView.vue'

// Mock the vue-router
vi.mock('vue-router', () => ({
  useRouter: () => ({
    push: mockPush
  }),
  useRoute: () => ({
    params: {
      id: '1'
    }
  })
}))

// Create a mock function for router.push
const mockPush = vi.fn()

// Mock the API
vi.mock('@/services/patientService', () => ({
  default: {
    getPatient: vi.fn().mockResolvedValue({
      id: 1,
      firstName: 'John',
      lastName: 'Doe',
      dateOfBirth: '2023-04-15',
      gender: 'Male',
      service: 'Army',
      rank: 'E-4',
      status: 'Active Duty',
      dutyStatus: 'Full Duty',
      deploymentStatus: 'Not Deployed',
      unit: '1st Infantry Division',
      address: '123 Main St',
      city: 'Anytown',
      state: 'CA',
      zip: '12345',
      phone: '555-123-4567',
      email: 'john.doe@example.com',
      emergencyContactName: 'Jane Doe',
      emergencyContactRelationship: 'Spouse',
      emergencyContactPhone: '555-987-6543',
      bloodType: 'O+',
      allergies: 'Penicillin',
      medicalConditions: 'None',
      medications: 'None',
      recentMedicalRecords: [
        { id: 1, date: '2023-02-15', recordType: 'Physical Exam', provider: 'Dr. Smith' },
        { id: 2, date: '2023-01-10', recordType: 'Lab Work', provider: 'Dr. Jones' }
      ],
      upcomingAppointments: [
        { id: 1, date: '2023-06-01', type: 'Follow-up', provider: 'Dr. Smith' },
        { id: 2, date: '2023-07-15', type: 'Physical Therapy', provider: 'Jane Wilson, PT' }
      ]
    })
  }
}))

// Mock components
vi.mock('@/components/AppHeader.vue', () => ({
  default: {
    name: 'AppHeader',
    template: '<div class="app-header-mock"></div>'
  }
}))

vi.mock('@/components/SideNavigation.vue', () => ({
  default: {
    name: 'SideNavigation',
    template: '<div class="side-nav-mock"></div>'
  }
}))

vi.mock('@/components/LoadingSpinner.vue', () => ({
  default: {
    name: 'LoadingSpinner',
    template: '<div data-testid="loading-spinner"></div>'
  }
}))

describe('PatientView.vue', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  it('renders the component with loading spinner initially', async () => {
    const wrapper = mount(PatientView)
    
    // Loading spinner should be visible initially
    expect(wrapper.find('[data-testid="loading-spinner"]').exists()).toBe(true)
    
    // Wait for API call to resolve
    await new Promise(resolve => setTimeout(resolve, 20))
    await nextTick()
    
    // Loading spinner should be hidden after data is loaded
    expect(wrapper.find('[data-testid="loading-spinner"]').exists()).toBe(false)
  })

  it('fetches patient data with correct ID', async () => {
    mount(PatientView)
    
    // Import the API module to check if it was called
    const patientService = await import('@/services/patientService')
    
    expect(patientService.default.getPatient).toHaveBeenCalledWith('1')
  })

  it('displays patient personal information correctly', async () => {
    const wrapper = mount(PatientView)
    
    // Wait for API call to resolve
    await new Promise(resolve => setTimeout(resolve, 20))
    await nextTick()
    
    // Check personal information
    const personalInfo = wrapper.find('.patient-details')
    expect(personalInfo.exists()).toBe(true)
    
    // Check name
    expect(personalInfo.text()).toContain('John Doe')
    
    // Check DOB
    const dobRow = wrapper.findAll('.info-row').find(row => row.text().includes('Date of Birth'))
    expect(dobRow.exists()).toBe(true)
    expect(dobRow.text()).toContain('Apr 15, 2023')
    
    // Check gender
    const genderRow = wrapper.findAll('.info-row').find(row => row.text().includes('Gender'))
    expect(genderRow.exists()).toBe(true)
    expect(genderRow.text()).toContain('Male')
  })

  it('displays military information correctly', async () => {
    const wrapper = mount(PatientView)
    
    // Wait for API call to resolve
    await new Promise(resolve => setTimeout(resolve, 20))
    await nextTick()
    
    // Find the military info section by looking for a card with "Military Information" in the header
    const militarySection = wrapper.findAll('.card').find(card => 
      card.find('.card-header').text().includes('Military Information')
    )
    expect(militarySection.exists()).toBe(true)
    
    // Check service
    const serviceRow = militarySection.findAll('.info-row').find(row => 
      row.text().includes('Service')
    )
    expect(serviceRow.exists()).toBe(true)
    expect(serviceRow.text()).toContain('Army')
    
    // Check rank
    const rankRow = militarySection.findAll('.info-row').find(row => 
      row.text().includes('Rank')
    )
    expect(rankRow.exists()).toBe(true)
    expect(rankRow.text()).toContain('E-4')
  })

  it('formats date correctly', async () => {
    const wrapper = mount(PatientView)
    
    // Wait for API call to resolve
    await new Promise(resolve => setTimeout(resolve, 20))
    await nextTick()
    
    // Check formatted date
    const formatDate = wrapper.vm.formatDate
    expect(formatDate('2023-04-15')).toBe('Apr 15, 2023')
  })

  it('displays medical information correctly', async () => {
    const wrapper = mount(PatientView)
    
    // Wait for API call to resolve
    await new Promise(resolve => setTimeout(resolve, 20))
    await nextTick()
    
    // Find the medical info section by looking for a card with "Medical Information" in the header
    const medicalSection = wrapper.findAll('.card').find(card => 
      card.find('.card-header').text().includes('Medical Information')
    )
    expect(medicalSection.exists()).toBe(true)
    
    // Check blood type
    const bloodTypeRow = medicalSection.findAll('.info-row').find(row => 
      row.text().includes('Blood Type')
    )
    expect(bloodTypeRow.exists()).toBe(true)
    expect(bloodTypeRow.text()).toContain('O+')
    
    // Check allergies
    const allergiesRow = medicalSection.findAll('.info-row').find(row => 
      row.text().includes('Allergies')
    )
    expect(allergiesRow.exists()).toBe(true)
    expect(allergiesRow.text()).toContain('Penicillin')
  })

  it('navigates to edit patient when edit button is clicked', async () => {
    const wrapper = mount(PatientView)
    
    // Wait for API call to resolve
    await new Promise(resolve => setTimeout(resolve, 20))
    await nextTick()
    
    // Find and click edit button
    const editButton = wrapper.find('button.btn-primary')
    await editButton.trigger('click')
    
    // Router should navigate to edit page
    expect(mockPush).toHaveBeenCalledWith('/patients/1/edit')
  })

  it('navigates back to patients list when back button is clicked', async () => {
    const wrapper = mount(PatientView)
    
    // Wait for API call to resolve
    await new Promise(resolve => setTimeout(resolve, 20))
    await nextTick()
    
    // Find and click back button
    const backButton = wrapper.find('button.btn-secondary')
    await backButton.trigger('click')
    
    // Router should navigate back to patients list
    expect(mockPush).toHaveBeenCalledWith('/patients')
  })

  it('navigates to records when view all records button is clicked', async () => {
    const wrapper = mount(PatientView)
    
    // Wait for API call to resolve
    await new Promise(resolve => setTimeout(resolve, 20))
    await nextTick()
    
    // Find the records section by looking for a card with "Recent Medical Records" in the header
    const recordsSection = wrapper.findAll('.card').find(card => 
      card.find('.card-header').text().includes('Recent Medical Records')
    )
    expect(recordsSection.exists()).toBe(true)
    
    // Find and click view all button
    const viewAllButton = recordsSection.find('button')
    await viewAllButton.trigger('click')
    
    // Router should navigate to records with patient filter
    expect(mockPush).toHaveBeenCalledWith('/records?patient=1')
  })

  it('navigates to appointments when view all appointments button is clicked', async () => {
    const wrapper = mount(PatientView)
    
    // Wait for API call to resolve
    await new Promise(resolve => setTimeout(resolve, 20))
    await nextTick()
    
    // Find the appointments section by looking for a card with "Upcoming Appointments" in the header
    const appointmentsSection = wrapper.findAll('.card').find(card => 
      card.find('.card-header').text().includes('Upcoming Appointments')
    )
    expect(appointmentsSection.exists()).toBe(true)
    
    // Find and click view all button
    const viewAllButton = appointmentsSection.find('button')
    await viewAllButton.trigger('click')
    
    // Router should navigate to appointments with patient filter
    expect(mockPush).toHaveBeenCalledWith('/appointments?patient=1')
  })

  it('displays recent medical records correctly', async () => {
    const wrapper = mount(PatientView)
    
    // Wait for API call to resolve
    await new Promise(resolve => setTimeout(resolve, 20))
    await nextTick()
    
    // Find the records section
    const recordsSection = wrapper.findAll('.card').find(card => 
      card.find('.card-header').text().includes('Recent Medical Records')
    )
    expect(recordsSection.exists()).toBe(true)
    
    // Check records table
    const recordRows = recordsSection.findAll('tbody tr')
    expect(recordRows.length).toBe(2)
    
    // Check first record
    const firstRecordCells = recordRows[0].findAll('td')
    expect(firstRecordCells[0].text()).toContain('Feb 15, 2023')
    expect(firstRecordCells[1].text()).toContain('Physical Exam')
    expect(firstRecordCells[2].text()).toContain('Dr. Smith')
  })

  it('displays upcoming appointments correctly', async () => {
    const wrapper = mount(PatientView)
    
    // Wait for API call to resolve
    await new Promise(resolve => setTimeout(resolve, 20))
    await nextTick()
    
    // Find the appointments section
    const appointmentsSection = wrapper.findAll('.card').find(card => 
      card.find('.card-header').text().includes('Upcoming Appointments')
    )
    expect(appointmentsSection.exists()).toBe(true)
    
    // Check appointments table
    const appointmentRows = appointmentsSection.findAll('tbody tr')
    expect(appointmentRows.length).toBe(2)
    
    // Check first appointment
    const firstAppointmentCells = appointmentRows[0].findAll('td')
    expect(firstAppointmentCells[0].text()).toContain('Jun 1, 2023')
    expect(firstAppointmentCells[1].text()).toContain('Follow-up')
    expect(firstAppointmentCells[2].text()).toContain('Dr. Smith')
  })

  it('handles API error gracefully', async () => {
    // Mock API to return error
    const patientService = await import('@/services/patientService')
    patientService.default.getPatient.mockRejectedValueOnce(new Error('Failed to fetch'))
    
    const wrapper = mount(PatientView)
    
    // Wait for API call to reject
    await new Promise(resolve => setTimeout(resolve, 20))
    await nextTick()
    
    // Error message should be shown
    expect(wrapper.find('.alert-danger').exists()).toBe(true)
    expect(wrapper.find('.alert-danger').text()).toContain('Failed to load patient')
  })

  it('computes patient initials correctly', async () => {
    const wrapper = mount(PatientView)
    
    // Wait for API call to resolve
    await new Promise(resolve => setTimeout(resolve, 20))
    await nextTick()
    
    // Check initials
    expect(wrapper.vm.patientInitials).toBe('JD')
  })
}) 
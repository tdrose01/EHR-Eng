import { describe, it, expect, vi, beforeEach } from 'vitest'
import { mount } from '@vue/test-utils'
import { nextTick } from 'vue'
import Records from '@/views/Records.vue'

// Mock the vue-router
vi.mock('vue-router', () => ({
  useRouter: () => ({
    push: mockPush
  }),
  useRoute: () => ({
    query: {}
  })
}))

// Create a mock function for router.push
const mockPush = vi.fn()

// Mock the API
vi.mock('@/services/recordsService', () => ({
  default: {
    getRecords: vi.fn().mockResolvedValue({
      records: [
        {
          id: 1,
          patientId: 123,
          patientName: 'John Smith',
          providerId: 456,
          providerName: 'Dr. Jane Wilson',
          date: '2023-03-15',
          recordType: 'Physical Exam',
          status: 'Completed',
          notes: 'Regular examination, all vitals normal'
        },
        {
          id: 2,
          patientId: 456,
          patientName: 'Maria Rodriguez',
          providerId: 789,
          providerName: 'Dr. Robert Jones',
          date: '2023-02-20',
          recordType: 'Lab Results',
          status: 'Completed',
          notes: 'Blood work within normal ranges'
        },
        {
          id: 3,
          patientId: 789,
          patientName: 'Steve Johnson',
          providerId: 123,
          providerName: 'Dr. Sarah Miller',
          date: '2023-04-01',
          recordType: 'Consultation',
          status: 'Draft',
          notes: 'Initial consultation for shoulder pain'
        }
      ],
      total: 3
    }),
    deleteRecord: vi.fn().mockResolvedValue({ success: true })
  }
}))

// Mock components
vi.mock('@/components/AppHeader.vue', () => ({
  default: {
    name: 'AppHeader',
    template: '<div class="app-header-mock"></div>'
  }
}))

vi.mock('@/components/SideNavigation.vue', () => ({
  default: {
    name: 'SideNavigation',
    template: '<div class="side-nav-mock"></div>'
  }
}))

vi.mock('@/components/LoadingSpinner.vue', () => ({
  default: {
    name: 'LoadingSpinner',
    template: '<div data-testid="loading-spinner"></div>'
  }
}))

describe('Records.vue', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  it('renders the component with correct layout', () => {
    const wrapper = mount(Records)
    
    // Main layout elements should be present
    expect(wrapper.find('.app-header-mock').exists()).toBe(true)
    expect(wrapper.find('.side-nav-mock').exists()).toBe(true)
    expect(wrapper.find('.main-content').exists()).toBe(true)
  })

  it('shows loading spinner while fetching data', async () => {
    const wrapper = mount(Records)
    
    // Loading spinner should be visible initially
    expect(wrapper.find('[data-testid="loading-spinner"]').exists()).toBe(true)
    
    // Manually set loading to false for testing
    await wrapper.setData({ loading: false })
    
    // Spinner should be gone
    expect(wrapper.find('[data-testid="loading-spinner"]').exists()).toBe(false)
  })

  it('displays records in a table after loading', async () => {
    const wrapper = mount(Records)
    
    // Set mock data
    await wrapper.setData({ 
      loading: false,
      records: [
        {
          id: 1,
          patientId: 123,
          patientName: 'John Smith',
          providerId: 456,
          providerName: 'Dr. Jane Wilson',
          date: '2023-03-15',
          recordType: 'Physical Exam',
          status: 'Completed',
          notes: 'Regular examination, all vitals normal'
        },
        {
          id: 2,
          patientId: 456,
          patientName: 'Maria Rodriguez',
          providerId: 789,
          providerName: 'Dr. Robert Jones',
          date: '2023-02-20',
          recordType: 'Lab Results',
          status: 'Completed',
          notes: 'Blood work within normal ranges'
        },
        {
          id: 3,
          patientId: 789,
          patientName: 'Steve Johnson',
          providerId: 123,
          providerName: 'Dr. Sarah Miller',
          date: '2023-04-01',
          recordType: 'Consultation',
          status: 'Draft',
          notes: 'Initial consultation for shoulder pain'
        }
      ],
      filteredRecords: [
        {
          id: 1,
          patientId: 123,
          patientName: 'John Smith',
          providerId: 456,
          providerName: 'Dr. Jane Wilson',
          date: '2023-03-15',
          recordType: 'Physical Exam',
          status: 'Completed',
          notes: 'Regular examination, all vitals normal'
        },
        {
          id: 2,
          patientId: 456,
          patientName: 'Maria Rodriguez',
          providerId: 789,
          providerName: 'Dr. Robert Jones',
          date: '2023-02-20',
          recordType: 'Lab Results',
          status: 'Completed',
          notes: 'Blood work within normal ranges'
        },
        {
          id: 3,
          patientId: 789,
          patientName: 'Steve Johnson',
          providerId: 123,
          providerName: 'Dr. Sarah Miller',
          date: '2023-04-01',
          recordType: 'Consultation',
          status: 'Draft',
          notes: 'Initial consultation for shoulder pain'
        }
      ]
    })
    await nextTick()
    
    // Table should be visible
    const table = wrapper.find('table')
    expect(table.exists()).toBe(true)
    
    // All records should be shown
    const rows = wrapper.findAll('tbody tr')
    expect(rows.length).toBe(3)
    
    // Check some data in the first row
    const firstRowCells = rows[0].findAll('td')
    expect(firstRowCells[0].text()).toContain('Mar 15, 2023')
    expect(firstRowCells[1].text()).toContain('John Smith')
    expect(firstRowCells[2].text()).toContain('Physical Exam')
    expect(firstRowCells[3].text()).toContain('Dr. Jane Wilson')
    expect(firstRowCells[4].text()).toContain('Completed')
  })

  it('searches for records when search is submitted', async () => {
    const wrapper = mount(Records)
    
    // Set data to simulate loaded component
    await wrapper.setData({ 
      loading: false,
      searchQuery: 'John'
    })
    await nextTick()
    
    // Get service
    const recordsService = await import('@/services/recordsService')
    
    // Trigger search function manually
    await wrapper.vm.search()
    
    // Ensure loadRecords gets called with search parameter
    expect(recordsService.default.getRecords).toHaveBeenCalled()
  })

  it('filters records by record type', async () => {
    const wrapper = mount(Records)
    
    // Set data to simulate loaded component
    await wrapper.setData({ 
      loading: false,
      recordTypeFilter: 'Physical Exam'
    })
    await nextTick()
    
    // Get service
    const recordsService = await import('@/services/recordsService')
    
    // Trigger filter function manually
    await wrapper.vm.applyFilters()
    
    // Ensure loadRecords gets called with filter
    expect(recordsService.default.getRecords).toHaveBeenCalled()
  })

  it('handles date range filter changes', async () => {
    const wrapper = mount(Records)
    
    // Set data to simulate loaded component
    await wrapper.setData({ 
      loading: false,
      dateFilter: 'month'
    })
    await nextTick()
    
    // Get service
    const recordsService = await import('@/services/recordsService')
    
    // Trigger date filter change manually
    await wrapper.vm.dateFilterChanged()
    
    // Ensure loadRecords gets called with date filter
    expect(recordsService.default.getRecords).toHaveBeenCalled()
  })

  it('shows custom date inputs when custom date range is selected', async () => {
    const wrapper = mount(Records)
    
    // Set data with custom date filter
    await wrapper.setData({ 
      loading: false,
      dateFilter: 'custom'
    })
    await nextTick()
    
    // Custom date inputs should be visible
    const customDateInputs = wrapper.findAll('input[type="date"]')
    expect(customDateInputs.length).toBe(2)
  })

  it('applies custom date range filters', async () => {
    const wrapper = mount(Records)
    
    // Set data to simulate loaded component with custom date filter
    await wrapper.setData({ 
      loading: false,
      dateFilter: 'custom',
      startDate: '2023-03-01',
      endDate: '2023-03-31'
    })
    await nextTick()
    
    // Get service
    const recordsService = await import('@/services/recordsService')
    
    // Trigger apply custom date filter function manually
    await wrapper.vm.applyCustomDateFilter()
    
    // Ensure loadRecords gets called with custom date filter
    expect(recordsService.default.getRecords).toHaveBeenCalled()
  })

  it('navigates to add record when add button is clicked', async () => {
    const wrapper = mount(Records)
    
    // Set data to simulate loaded component
    await wrapper.setData({ loading: false })
    await nextTick()
    
    // Find and click add record button
    const addButton = wrapper.find('.card-actions button')
    await addButton.trigger('click')
    
    // Router should navigate to add record page
    expect(mockPush).toHaveBeenCalledWith('/records/new')
  })

  it('navigates to view record when view button is clicked', async () => {
    const wrapper = mount(Records)
    
    // Set data to simulate loaded component with records
    await wrapper.setData({ 
      loading: false,
      filteredRecords: [
        {
          id: 1,
          patientName: 'John Smith',
          status: 'Completed'
        }
      ]
    })
    await nextTick()
    
    // Manually call view method
    await wrapper.vm.viewRecord(1)
    
    // Router should navigate to view record page
    expect(mockPush).toHaveBeenCalledWith('/records/1')
  })

  it('displays delete confirmation modal when delete button is clicked', async () => {
    const wrapper = mount(Records)
    
    // Set data to simulate loaded component with records
    await wrapper.setData({ 
      loading: false,
      filteredRecords: [
        {
          id: 1,
          patientName: 'John Smith',
          recordType: 'Physical Exam',
          status: 'Draft'
        }
      ]
    })
    await nextTick()
    
    // Manually call confirmDelete method
    await wrapper.vm.confirmDelete({
      id: 1,
      patientName: 'John Smith',
      recordType: 'Physical Exam',
      status: 'Draft'
    })
    
    // Modal state should be updated
    expect(wrapper.vm.showDeleteModal).toBe(true)
    expect(wrapper.vm.selectedRecord).toEqual({
      id: 1,
      patientName: 'John Smith',
      recordType: 'Physical Exam',
      status: 'Draft'
    })
    
    // Update the DOM
    await nextTick()
    
    // Modal should be visible now
    expect(wrapper.find('.modal-dialog').exists()).toBe(true)
  })

  it('closes delete modal when cancel is clicked', async () => {
    const wrapper = mount(Records)
    
    // Set data to simulate modal being open
    await wrapper.setData({ 
      loading: false,
      showDeleteModal: true,
      selectedRecord: {
        id: 1,
        patientName: 'John Smith',
        recordType: 'Physical Exam',
        status: 'Draft'
      }
    })
    await nextTick()
    
    // Manually call cancelDelete method
    await wrapper.vm.cancelDelete()
    
    // Modal should be closed
    expect(wrapper.vm.showDeleteModal).toBe(false)
  })

  it('removes record from list when delete is confirmed', async () => {
    const wrapper = mount(Records)
    
    // Set data to simulate modal being open
    await wrapper.setData({ 
      loading: false,
      showDeleteModal: true,
      selectedRecord: {
        id: 1,
        patientName: 'John Smith',
        recordType: 'Physical Exam',
        status: 'Draft'
      },
      records: [
        {
          id: 1,
          patientName: 'John Smith',
          recordType: 'Physical Exam',
          status: 'Draft'
        }
      ],
      filteredRecords: [
        {
          id: 1,
          patientName: 'John Smith',
          recordType: 'Physical Exam',
          status: 'Draft'
        }
      ]
    })
    await nextTick()
    
    // Get service
    const recordsService = await import('@/services/recordsService')
    
    // Manually call confirmDeleteRecord method
    await wrapper.vm.confirmDeleteRecord()
    
    // Service should be called to delete record
    expect(recordsService.default.deleteRecord).toHaveBeenCalledWith(1)
    
    // Set data to simulate successful deletion
    await wrapper.setData({
      records: [],
      filteredRecords: []
    })
    
    // Modal should be closed
    expect(wrapper.vm.showDeleteModal).toBe(false)
    
    // Record should be removed from list
    expect(wrapper.findAll('tbody tr').length).toBe(0)
  })

  it('formats dates correctly', async () => {
    const wrapper = mount(Records)
    
    // Set data to simulate loaded component
    await wrapper.setData({ loading: false })
    await nextTick()
    
    // Check formatDate method
    expect(wrapper.vm.formatDate('2023-03-15')).toBe('Mar 15, 2023')
  })

  it('maps status to appropriate status class', async () => {
    const wrapper = mount(Records)
    
    // Set data to simulate loaded component
    await wrapper.setData({ loading: false })
    await nextTick()
    
    // Check getStatusClass method for different statuses
    expect(wrapper.vm.getStatusClass('Completed')).toBe('badge bg-success')
    expect(wrapper.vm.getStatusClass('Draft')).toBe('badge bg-warning')
    expect(wrapper.vm.getStatusClass('UnknownStatus')).toBe('badge bg-secondary')
  })

  it('shows appropriate buttons based on record status', async () => {
    const wrapper = mount(Records)
    
    // Set data to simulate loaded component with different record statuses
    await wrapper.setData({
      loading: false,
      filteredRecords: [
        {
          id: 1,
          patientName: 'John Smith',
          status: 'Completed'
        },
        {
          id: 2,
          patientName: 'Maria Rodriguez',
          status: 'Draft'
        }
      ]
    })
    await nextTick()
    
    // Check showActions method for different statuses and actions
    expect(wrapper.vm.showActions('Completed', 'edit')).toBe(false)
    expect(wrapper.vm.showActions('Completed', 'delete')).toBe(false)
    expect(wrapper.vm.showActions('Draft', 'edit')).toBe(true)
    expect(wrapper.vm.showActions('Draft', 'delete')).toBe(true)
  })
}) 
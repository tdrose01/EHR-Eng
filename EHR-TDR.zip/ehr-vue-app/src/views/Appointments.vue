<template>
  <div>
    <AppHeader />
    
    <div class="container">
      <div class="main-content">
        <SideNavigation />
        
        <div class="content">
          <div class="card">
            <h3 class="card-header">
              Appointments
              <div class="header-actions">
                <button class="btn" @click="navigateTo('/appointments/schedule')">Schedule Appointment</button>
                <button class="btn" @click="loadAppointments">Refresh</button>
              </div>
            </h3>
            
            <div class="filter-section">
              <div class="date-filter">
                <div class="filter-group">
                  <label for="dateFilter">Date Filter:</label>
                  <select id="dateFilter" v-model="dateFilter" @change="applyFilters">
                    <option value="all">All Dates</option>
                    <option value="today">Today</option>
                    <option value="this-week">This Week</option>
                    <option value="next-week">Next Week</option>
                    <option value="this-month">This Month</option>
                    <option value="custom">Custom Range</option>
                  </select>
                </div>
                
                <div class="date-range" v-if="dateFilter === 'custom'">
                  <div class="filter-group">
                    <label for="startDate">From:</label>
                    <input type="date" id="startDate" v-model="startDate" @change="applyFilters">
                  </div>
                  <div class="filter-group">
                    <label for="endDate">To:</label>
                    <input type="date" id="endDate" v-model="endDate" @change="applyFilters">
                  </div>
                </div>
              </div>
              
              <div class="search-filter">
                <div class="filter-group">
                  <label for="searchField">Search:</label>
                  <div class="search-input">
                    <input 
                      type="text" 
                      id="searchField" 
                      v-model="searchQuery"
                      placeholder="Search by patient name or ID..."
                      @keyup.enter="applyFilters"
                    >
                    <button @click="applyFilters">
                      Search
                    </button>
                  </div>
                </div>
              </div>
            </div>
            
            <LoadingSpinner v-if="isLoading" message="Loading appointments..." />
            
            <template v-else>
              <div class="tabs">
                <div 
                  class="tab" 
                  :class="{ active: activeTab === 'upcoming' }"
                  @click="changeTab('upcoming')"
                >
                  Upcoming
                </div>
                <div 
                  class="tab" 
                  :class="{ active: activeTab === 'past' }"
                  @click="changeTab('past')"
                >
                  Past
                </div>
                <div 
                  class="tab" 
                  :class="{ active: activeTab === 'cancelled' }"
                  @click="changeTab('cancelled')"
                >
                  Cancelled
                </div>
                <div 
                  class="tab" 
                  :class="{ active: activeTab === 'all' }"
                  @click="changeTab('all')"
                >
                  All
                </div>
              </div>
              
              <div v-if="filteredAppointments.length === 0" class="no-data">
                No appointments found matching your criteria.
              </div>
              
              <table v-else>
                <thead>
                  <tr>
                    <th>Date & Time</th>
                    <th>Patient</th>
                    <th>Provider</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="appointment in filteredAppointments" :key="appointment.id">
                    <td>
                      <div class="appointment-datetime">
                        <div class="appointment-date">{{ formatDate(appointment.date) }}</div>
                        <div class="appointment-time">{{ appointment.time }}</div>
                      </div>
                    </td>
                    <td>
                      <div class="patient-info">
                        <div>{{ appointment.patient_name }}</div>
                        <div class="patient-id">ID: {{ appointment.patient_id }}</div>
                      </div>
                    </td>
                    <td>{{ appointment.provider }}</td>
                    <td>{{ appointment.type }}</td>
                    <td>
                      <span 
                        class="badge" 
                        :class="'badge-' + getStatusClass(appointment.status)"
                      >
                        {{ appointment.status }}
                      </span>
                    </td>
                    <td>
                      <div class="action-buttons">
                        <button 
                          class="btn btn-sm" 
                          @click="viewAppointment(appointment.id)"
                        >
                          View
                        </button>
                        <button 
                          class="btn btn-sm" 
                          v-if="canEditAppointment(appointment)"
                          @click="editAppointment(appointment.id)"
                        >
                          Edit
                        </button>
                        <button 
                          class="btn btn-sm btn-danger" 
                          v-if="canCancelAppointment(appointment)"
                          @click="confirmCancelAppointment(appointment)"
                        >
                          Cancel
                        </button>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
              
              <div class="pagination">
                <button 
                  v-for="page in totalPages" 
                  :key="page"
                  :class="{ active: currentPage === page }"
                  @click="changePage(page)"
                >
                  {{ page }}
                </button>
              </div>
            </template>
          </div>
        </div>
      </div>
    </div>
    
    <!-- Cancel Appointment Confirmation Modal -->
    <div class="modal" v-if="showCancelModal">
      <div class="modal-content">
        <div class="modal-header">
          <h4>Cancel Appointment</h4>
          <button class="close-btn" @click="showCancelModal = false">&times;</button>
        </div>
        <div class="modal-body">
          <p>Are you sure you want to cancel this appointment?</p>
          <p v-if="selectedAppointment">
            <strong>Date:</strong> {{ formatDate(selectedAppointment.date) }} at {{ selectedAppointment.time }}<br>
            <strong>Patient:</strong> {{ selectedAppointment.patient_name }}<br>
            <strong>Type:</strong> {{ selectedAppointment.type }}
          </p>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" @click="showCancelModal = false">No, Keep it</button>
          <button class="btn btn-danger" @click="cancelAppointment">Yes, Cancel Appointment</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, computed, onMounted, watch } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import AppHeader from '@/components/AppHeader.vue'
import SideNavigation from '@/components/SideNavigation.vue'
import LoadingSpinner from '@/components/LoadingSpinner.vue'
import { appointmentService } from '@/services/api'

export default {
  name: 'Appointments',
  components: {
    AppHeader,
    SideNavigation,
    LoadingSpinner
  },
  setup() {
    const router = useRouter()
    const route = useRoute()
    
    // State variables
    const appointments = ref([])
    const isLoading = ref(true)
    const activeTab = ref('upcoming')
    const dateFilter = ref('all')
    const startDate = ref('')
    const endDate = ref('')
    const searchQuery = ref('')
    const currentPage = ref(1)
    const totalAppointments = ref(0)
    const pageSize = ref(10)
    const showCancelModal = ref(false)
    const selectedAppointment = ref(null)
    
    // Computed properties
    const totalPages = computed(() => {
      return Math.ceil(totalAppointments.value / pageSize.value) || 1
    })
    
    const filteredAppointments = computed(() => {
      // Filter appointments based on activeTab
      let filtered = [...appointments.value]
      
      // Filter by tab
      if (activeTab.value === 'upcoming') {
        filtered = filtered.filter(a => 
          a.status === 'Scheduled' || 
          a.status === 'Confirmed'
        )
      } else if (activeTab.value === 'past') {
        filtered = filtered.filter(a => 
          a.status === 'Completed' || 
          a.status === 'No-show'
        )
      } else if (activeTab.value === 'cancelled') {
        filtered = filtered.filter(a => a.status === 'Cancelled')
      }
      
      return filtered
    })
    
    // Methods
    const loadAppointments = async () => {
      isLoading.value = true
      
      try {
        const params = {
          limit: pageSize.value,
          offset: (currentPage.value - 1) * pageSize.value
        }
        
        // Add date filter params
        if (dateFilter.value === 'custom' && startDate.value && endDate.value) {
          params.startDate = startDate.value
          params.endDate = endDate.value
        } else if (dateFilter.value !== 'all') {
          params.dateFilter = dateFilter.value
        }
        
        // Add search params
        if (searchQuery.value) {
          params.search = searchQuery.value
        }
        
        // Get patient ID from query param if available
        const patientId = route.query.patient
        if (patientId) {
          params.patientId = patientId
        }
        
        // In a real app, we would fetch from API
        // For now, generate mock data
        setTimeout(() => {
          appointments.value = generateMockAppointments()
          totalAppointments.value = 50 // Mock total
          isLoading.value = false
        }, 500)
      } catch (error) {
        console.error('Error loading appointments:', error)
        appointments.value = generateMockAppointments()
        isLoading.value = false
      }
    }
    
    const changeTab = (tab) => {
      activeTab.value = tab
      currentPage.value = 1
      // In a real app, this might trigger a new API call
    }
    
    const applyFilters = () => {
      currentPage.value = 1
      loadAppointments()
    }
    
    const changePage = (page) => {
      currentPage.value = page
      loadAppointments()
    }
    
    const viewAppointment = (appointmentId) => {
      router.push(`/appointments/${appointmentId}`)
    }
    
    const editAppointment = (appointmentId) => {
      router.push(`/appointments/${appointmentId}/edit`)
    }
    
    const confirmCancelAppointment = (appointment) => {
      selectedAppointment.value = appointment
      showCancelModal.value = true
    }
    
    const cancelAppointment = async () => {
      if (!selectedAppointment.value) return
      
      try {
        // In a real app, we would call the API
        // appointmentService.cancelAppointment(selectedAppointment.value.id)
        
        // For now, just update locally
        const index = appointments.value.findIndex(a => a.id === selectedAppointment.value.id)
        if (index !== -1) {
          appointments.value[index].status = 'Cancelled'
        }
        
        showCancelModal.value = false
        selectedAppointment.value = null
      } catch (error) {
        console.error('Error cancelling appointment:', error)
      }
    }
    
    const canEditAppointment = (appointment) => {
      // Can edit if not completed, cancelled, or no-show
      return !['Completed', 'Cancelled', 'No-show'].includes(appointment.status)
    }
    
    const canCancelAppointment = (appointment) => {
      // Can cancel if scheduled or confirmed
      return ['Scheduled', 'Confirmed'].includes(appointment.status)
    }
    
    const formatDate = (dateString) => {
      if (!dateString) return 'N/A'
      const date = new Date(dateString)
      return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
    }
    
    const getStatusClass = (status) => {
      switch (status) {
        case 'Scheduled': return 'info'
        case 'Confirmed': return 'primary'
        case 'Completed': return 'success'
        case 'Cancelled': return 'danger'
        case 'No-show': return 'warning'
        default: return 'secondary'
      }
    }
    
    const navigateTo = (path) => {
      router.push(path)
    }
    
    const generateMockAppointments = () => {
      const statuses = ['Scheduled', 'Confirmed', 'Completed', 'Cancelled', 'No-show']
      const types = ['Annual Physical', 'Follow-up', 'Sick Call', 'Vaccination', 'Specialist']
      const providers = [
        'Capt. Sarah Johnson', 
        'Lt. Col. James Miller', 
        'Maj. Robert Chen', 
        'Lt. Emma Rodriguez', 
        'Col. William Davis'
      ]
      
      // Generate dates from last month to next month
      const today = new Date()
      const lastMonth = new Date(today)
      lastMonth.setMonth(today.getMonth() - 1)
      const nextMonth = new Date(today)
      nextMonth.setMonth(today.getMonth() + 1)
      
      // Generate random appointments
      const mockAppointments = []
      for (let i = 1; i <= 50; i++) {
        // Generate random date between last month and next month
        const dateRange = nextMonth - lastMonth
        const randomDate = new Date(lastMonth.getTime() + Math.random() * dateRange)
        
        // Format as YYYY-MM-DD
        const dateStr = randomDate.toISOString().split('T')[0]
        
        // Hours between 8 AM and 4 PM
        const hour = Math.floor(Math.random() * 8) + 8
        // Minutes are either 0, 15, 30, or 45
        const minute = [0, 15, 30, 45][Math.floor(Math.random() * 4)]
        const timeStr = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`
        
        // Status based on date (past appointments are completed or no-show)
        let status
        if (randomDate < today) {
          status = Math.random() > 0.2 ? 'Completed' : 'No-show'
        } else {
          status = Math.random() > 0.1 ? (Math.random() > 0.5 ? 'Scheduled' : 'Confirmed') : 'Cancelled'
        }
        
        mockAppointments.push({
          id: i,
          date: dateStr,
          time: timeStr,
          patient_id: Math.floor(Math.random() * 1000) + 1000,
          patient_name: `Patient ${i}`,
          provider: providers[Math.floor(Math.random() * providers.length)],
          type: types[Math.floor(Math.random() * types.length)],
          status: status
        })
      }
      
      return mockAppointments
    }
    
    // Watch for route query changes
    watch(() => route.query, (newQuery) => {
      if (newQuery.filter === 'today') {
        dateFilter.value = 'today'
      }
      
      if (newQuery.patient) {
        // Filter by patient
      }
      
      loadAppointments()
    }, { immediate: true })
    
    // Initialize component
    onMounted(() => {
      // Set default dates for custom range
      const today = new Date()
      
      // Default start date to beginning of current month
      const startDateObj = new Date(today.getFullYear(), today.getMonth(), 1)
      startDate.value = startDateObj.toISOString().split('T')[0]
      
      // Default end date to end of current month
      const endDateObj = new Date(today.getFullYear(), today.getMonth() + 1, 0)
      endDate.value = endDateObj.toISOString().split('T')[0]
      
      // Check for today filter
      if (route.query.filter === 'today') {
        dateFilter.value = 'today'
      }
      
      loadAppointments()
    })
    
    return {
      appointments,
      filteredAppointments,
      isLoading,
      activeTab,
      dateFilter,
      startDate,
      endDate,
      searchQuery,
      currentPage,
      totalPages,
      showCancelModal,
      selectedAppointment,
      changeTab,
      applyFilters,
      changePage,
      viewAppointment,
      editAppointment,
      confirmCancelAppointment,
      cancelAppointment,
      canEditAppointment,
      canCancelAppointment,
      formatDate,
      getStatusClass,
      navigateTo
    }
  }
}
</script>

<style scoped>
.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.main-content {
  display: flex;
  gap: 20px;
}

.content {
  flex-grow: 1;
}

.card {
  background-color: var(--secondary-bg);
  border-radius: 8px;
  padding: 20px;
  margin-bottom: 20px;
}

.card-header {
  margin-top: 0;
  margin-bottom: 15px;
  font-size: 1.1rem;
  color: var(--accent-color);
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-actions {
  display: flex;
  gap: 10px;
}

.filter-section {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  margin-bottom: 20px;
  gap: 15px;
}

.date-filter,
.search-filter {
  flex-grow: 1;
}

.date-range {
  display: flex;
  gap: 10px;
  margin-top: 10px;
}

.filter-group {
  display: flex;
  flex-direction: column;
  gap: 5px;
  min-width: 200px;
}

.filter-group label {
  font-size: 0.9rem;
  color: #aaa;
}

.filter-group select,
.filter-group input {
  padding: 8px 10px;
  border: 1px solid var(--border-color);
  border-radius: 4px;
  background-color: var(--primary-bg);
  color: var(--text-color);
}

.search-input {
  display: flex;
}

.search-input input {
  flex-grow: 1;
  padding: 8px 10px;
  border: 1px solid var(--border-color);
  border-radius: 4px 0 0 4px;
  background-color: var(--primary-bg);
  color: var(--text-color);
}

.search-input button {
  padding: 8px 15px;
  background-color: var(--accent-color);
  color: white;
  border: none;
  border-radius: 0 4px 4px 0;
  cursor: pointer;
}

.tabs {
  display: flex;
  border-bottom: 1px solid var(--border-color);
  margin-bottom: 20px;
}

.tab {
  padding: 10px 20px;
  cursor: pointer;
  border-bottom: 2px solid transparent;
  transition: all 0.2s;
}

.tab:hover {
  background-color: rgba(77, 139, 240, 0.1);
}

.tab.active {
  border-bottom-color: var(--accent-color);
  color: var(--accent-color);
}

table {
  width: 100%;
  border-collapse: collapse;
}

th, td {
  text-align: left;
  padding: 12px 15px;
  border-bottom: 1px solid var(--border-color);
}

th {
  background-color: rgba(77, 139, 240, 0.1);
  color: var(--accent-color);
  font-weight: 500;
}

.appointment-datetime {
  display: flex;
  flex-direction: column;
}

.appointment-time {
  font-size: 0.9rem;
  color: #aaa;
}

.patient-info {
  display: flex;
  flex-direction: column;
}

.patient-id {
  font-size: 0.8rem;
  color: #aaa;
}

.badge {
  display: inline-block;
  padding: 4px 8px;
  border-radius: 12px;
  font-size: 0.8rem;
  font-weight: 500;
}

.badge-info {
  background-color: rgba(33, 150, 243, 0.1);
  color: #2196f3;
}

.badge-primary {
  background-color: rgba(77, 139, 240, 0.1);
  color: var(--accent-color);
}

.badge-success {
  background-color: rgba(76, 175, 80, 0.1);
  color: var(--success-color);
}

.badge-warning {
  background-color: rgba(255, 152, 0, 0.1);
  color: var(--warning-color);
}

.badge-danger {
  background-color: rgba(244, 67, 54, 0.1);
  color: var(--danger-color);
}

.badge-secondary {
  background-color: rgba(158, 158, 158, 0.1);
  color: #9e9e9e;
}

.action-buttons {
  display: flex;
  gap: 5px;
}

.btn-sm {
  padding: 4px 8px;
  font-size: 0.8rem;
}

.btn-danger {
  background-color: var(--danger-color);
}

.btn-danger:hover {
  background-color: #d32f2f;
}

.pagination {
  display: flex;
  justify-content: center;
  margin-top: 20px;
  gap: 5px;
}

.pagination button {
  background-color: var(--secondary-bg);
  color: var(--text-color);
  border: 1px solid var(--border-color);
  padding: 8px 12px;
  border-radius: 4px;
  cursor: pointer;
}

.pagination button.active {
  background-color: var(--accent-color);
  color: white;
  border-color: var(--accent-color);
}

.no-data {
  text-align: center;
  padding: 30px;
  color: #aaa;
}

/* Modal styles */
.modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background-color: var(--secondary-bg);
  border-radius: 8px;
  width: 90%;
  max-width: 500px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
}

.modal-header {
  padding: 15px 20px;
  border-bottom: 1px solid var(--border-color);
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.modal-header h4 {
  margin: 0;
  color: var(--accent-color);
}

.close-btn {
  background: none;
  border: none;
  font-size: 1.5rem;
  color: var(--text-color);
  cursor: pointer;
}

.modal-body {
  padding: 20px;
}

.modal-footer {
  padding: 15px 20px;
  border-top: 1px solid var(--border-color);
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}

.btn-secondary {
  background-color: var(--border-color);
}

.btn-secondary:hover {
  background-color: #444;
}

@media (max-width: 768px) {
  .filter-section {
    flex-direction: column;
  }
  
  .date-range {
    flex-direction: column;
  }
}
</style> 
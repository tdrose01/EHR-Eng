<template>
  <div>
    <AppHeader />
    
    <div class="container">
      <div class="main-content">
        <SideNavigation />
        
        <div class="content">
          <div class="card">
            <h3 class="card-header">Help Center</h3>
            <p>This page is under construction. Support resources will be available soon.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import AppHeader from '@/components/AppHeader.vue'
import SideNavigation from '@/components/SideNavigation.vue'

export default {
  name: 'Help',
  components: {
    AppHeader,
    SideNavigation
  }
}
</script>

<style scoped>
.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.main-content {
  display: flex;
  gap: 20px;
}

.content {
  flex-grow: 1;
}

.card {
  background-color: var(--secondary-bg);
  border-radius: 8px;
  padding: 20px;
  margin-bottom: 20px;
}

.card-header {
  margin-top: 0;
  margin-bottom: 20px;
  padding-bottom: 10px;
  border-bottom: 1px solid var(--border-color);
}
</style> 
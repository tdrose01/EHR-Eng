<template>
  <div class="landing-page">
    <div class="header">
      <div class="logo">Logo</div>
      <div class="nav-links">
        <a href="#">News</a>
        <a href="#">Blog</a>
        <a href="#">Portfolio</a>
        <a href="#">Contact</a>
        <a href="#">Imprint</a>
      </div>
    </div>
    
    <div class="hero-container">
      <div class="hero-content">
        <div class="hero-text">
          <h1>Electronic<br>Healthcare</h1>
          <div class="btn-container">
            <button class="btn" @click="navigateToSignUp">Sign Up</button>
            <button class="btn outline" @click="navigateToLogin">Sign in</button>
          </div>
        </div>
        
        <div class="hero-image">
          <img :src="healthcareIllustration" alt="Healthcare illustration with laptop and medical professionals">
        </div>
      </div>
    </div>
    
    <div class="star-decoration">✧</div>
  </div>
</template>

<script>
import { useRouter } from 'vue-router'
import { healthcareIllustrationBase64 } from '@/assets/img/healthcare-illustration.js'

export default {
  name: 'Landing',
  setup() {
    const router = useRouter()
    
    const navigateToLogin = () => {
      router.push('/login')
    }
    
    const navigateToSignUp = () => {
      router.push('/login?signup=true')
    }
    
    return {
      navigateToLogin,
      navigateToSignUp,
      healthcareIllustration: healthcareIllustrationBase64
    }
  }
}
</script>

<style scoped>
.landing-page {
  background-color: #000;
  color: #fff;
  min-height: 100vh;
  padding: 0 20px;
  position: relative;
  overflow: hidden;
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 30px 40px;
}

.logo {
  font-size: 24px;
  font-weight: bold;
}

.nav-links {
  display: flex;
  gap: 30px;
}

.nav-links a {
  color: #fff;
  text-decoration: none;
  font-size: 16px;
  transition: color 0.3s;
}

.nav-links a:hover {
  color: #4d8bf0;
}

.hero-container {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 40px;
}

.hero-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  max-width: 1200px;
  margin: 0 auto;
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 40px;
  padding: 40px;
  background-color: rgba(0, 0, 0, 0.5);
}

.hero-text {
  flex: 1;
  padding-right: 40px;
}

.hero-text h1 {
  font-size: 60px;
  margin-bottom: 40px;
  color: #00ffdd;
  font-weight: 500;
  line-height: 1.1;
}

.btn-container {
  display: flex;
  gap: 20px;
}

.btn {
  padding: 10px 25px;
  background-color: #00ffdd;
  color: #000;
  border: none;
  border-radius: 20px;
  font-size: 16px;
  cursor: pointer;
  transition: all 0.3s;
}

.btn.outline {
  background-color: transparent;
  border: 1px solid #00ffdd;
  color: #00ffdd;
}

.btn:hover {
  transform: scale(1.05);
}

.hero-image {
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: center;
}

.hero-image img {
  max-width: 100%;
  height: auto;
}

.star-decoration {
  position: absolute;
  bottom: 20px;
  left: 40px;
  font-size: 40px;
  color: #4d8bf0;
  animation: twinkle 2s infinite;
}

@keyframes twinkle {
  0%, 100% { opacity: 0.3; }
  50% { opacity: 1; }
}

@media (max-width: 768px) {
  .hero-content {
    flex-direction: column;
  }
  
  .hero-text {
    padding-right: 0;
    padding-bottom: 30px;
    text-align: center;
  }
  
  .btn-container {
    justify-content: center;
  }
  
  .nav-links {
    display: none;
  }
}
</style> 
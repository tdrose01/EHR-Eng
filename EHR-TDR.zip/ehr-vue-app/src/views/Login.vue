<template>
  <div class="login-page">
    <div class="login-container">
      <div class="header">
        <h1>Military EHR System</h1>
        <p>Secure Healthcare Records Management</p>
      </div>
      
      <div class="hero-image">
        <img :src="healthcareIllustration" alt="Healthcare Illustration">
      </div>
      
      <form @submit.prevent="handleLogin">
        <div class="form-group">
          <label for="username">Username</label>
          <input 
            type="text" 
            id="username" 
            v-model="username" 
            placeholder="Enter your username" 
            required
          >
        </div>
        
        <div class="form-group">
          <label for="password">Password</label>
          <input 
            type="password" 
            id="password" 
            v-model="password" 
            placeholder="Enter your password" 
            required
          >
        </div>
        
        <button 
          type="submit" 
          :disabled="isLoading"
        >
          <div v-if="isLoading" class="loading"></div>
          {{ isLoading ? 'Logging in...' : 'Login' }}
        </button>
      </form>
      
      <div 
        v-if="statusMessage" 
        class="status-message" 
        :class="messageType"
      >
        {{ statusMessage }}
      </div>
    </div>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { authService } from '@/services/api'
import { healthcareIllustrationBase64 } from '@/assets/img/healthcare-illustration.js'

export default {
  name: 'Login',
  setup() {
    const router = useRouter()
    const username = ref('')
    const password = ref('')
    const isLoading = ref(false)
    const statusMessage = ref('')
    const messageType = ref('')
    const healthcareIllustration = ref(healthcareIllustrationBase64)
    
    // Check if already logged in
    onMounted(() => {
      console.log('Checking login status')
      const token = localStorage.getItem('ehrToken')
      if (token) {
        console.log('Token found, redirecting to dashboard')
        router.push('/dashboard')
      }
    })
    
    const showMessage = (message, type) => {
      statusMessage.value = message
      messageType.value = type
    }
    
    const handleLogin = async () => {
      isLoading.value = true
      statusMessage.value = ''
      
      try {
        console.log(`Attempting login for user: ${username.value}`)
        
        // Try API login
        const response = await authService.login({
          username: username.value,
          password: password.value
        })
        
        const data = response.data
        
        if (data.success || data.access_token) {
          // Save token to localStorage
          const token = data.token || data.access_token
          localStorage.setItem('ehrToken', token)
          localStorage.setItem('ehrUsername', username.value)
          
          showMessage('Login successful!', 'success')
          
          // Redirect to dashboard
          setTimeout(() => {
            router.push('/dashboard')
          }, 1000)
        } else {
          showMessage(data.message || 'Login failed', 'error')
        }
      } catch (error) {
        console.error('Login API error:', error)
        showMessage('An unexpected error occurred. Please try again.', 'error')
      } finally {
        isLoading.value = false
      }
    }
    
    return {
      username,
      password,
      isLoading,
      statusMessage,
      messageType,
      handleLogin,
      healthcareIllustration
    }
  }
}
</script>

<style scoped>
.login-page {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: var(--primary-bg);
}

.login-container {
  background-color: var(--secondary-bg);
  border-radius: 8px;
  padding: 30px;
  width: 480px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
}

.header {
  text-align: center;
  margin-bottom: 20px;
}

.header h1 {
  color: var(--accent-color);
  margin-bottom: 5px;
}

.header p {
  color: #9a9a9a;
  margin-top: 0;
}

.hero-image {
  display: flex;
  justify-content: center;
  margin-bottom: 20px;
  overflow: hidden;
  border-radius: 4px;
}

.hero-image img {
  max-width: 100%;
  height: auto;
}

.status-message {
  margin-top: 20px;
  padding: 10px;
  border-radius: 4px;
  text-align: center;
}

.error {
  background-color: rgba(231, 76, 60, 0.2);
  color: var(--danger-color);
  border: 1px solid rgba(231, 76, 60, 0.5);
}

.success {
  background-color: rgba(46, 204, 113, 0.2);
  color: var(--success-color);
  border: 1px solid rgba(46, 204, 113, 0.5);
}

.loading {
  display: inline-block;
  width: 20px;
  height: 20px;
  border: 3px solid rgba(255,255,255,.3);
  border-radius: 50%;
  border-top-color: #fff;
  animation: spin 1s ease-in-out infinite;
  margin-right: 10px;
  vertical-align: middle;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}
</style> 
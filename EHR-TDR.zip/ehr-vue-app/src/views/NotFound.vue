<template>
  <div class="not-found">
    <div class="container">
      <div class="content">
        <h1>404</h1>
        <h2>Page Not Found</h2>
        <p>The page you are looking for does not exist or has been moved.</p>
        <button class="btn" @click="goBack">Go Back</button>
        <button class="btn" @click="goHome">Go to Dashboard</button>
      </div>
    </div>
  </div>
</template>

<script>
import { useRouter } from 'vue-router'

export default {
  name: 'NotFound',
  setup() {
    const router = useRouter()
    
    const goBack = () => {
      router.go(-1)
    }
    
    const goHome = () => {
      router.push('/dashboard')
    }
    
    return {
      goBack,
      goHome
    }
  }
}
</script>

<style scoped>
.not-found {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: var(--primary-bg);
}

.content {
  text-align: center;
  padding: 40px;
  background-color: var(--secondary-bg);
  border-radius: 8px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
}

h1 {
  font-size: 6rem;
  margin: 0;
  color: var(--accent-color);
}

h2 {
  font-size: 2rem;
  margin: 0 0 20px 0;
  color: var(--text-color);
}

p {
  margin-bottom: 30px;
  color: #9a9a9a;
}

.btn {
  margin: 0 10px;
}
</style> 
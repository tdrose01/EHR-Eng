<template>
  <div>
    <AppHeader />
    
    <div class="container">
      <div class="status-message" :class="messageType" v-if="showMessage">
        {{ statusMessage }}
      </div>
      
      <div class="form-container">
        <h2 class="form-title">{{ isNew ? 'Add New Patient' : 'Edit Patient' }}</h2>
        
        <form @submit.prevent="savePatient">
          <div class="form-section">
            <h3 class="form-section-title">Personal Information</h3>
            <div class="form-grid">
              <div class="form-group">
                <label for="firstName">First Name</label>
                <input type="text" id="firstName" v-model="patient.first_name" required>
              </div>
              
              <div class="form-group">
                <label for="lastName">Last Name</label>
                <input type="text" id="lastName" v-model="patient.last_name" required>
              </div>
              
              <div class="form-group">
                <label for="dateOfBirth">Date of Birth</label>
                <input type="date" id="dateOfBirth" v-model="patient.date_of_birth" required>
              </div>
              
              <div class="form-group">
                <label for="gender">Gender</label>
                <select id="gender" v-model="patient.gender" required>
                  <option value="">Select Gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>
            </div>
          </div>
          
          <div class="form-section">
            <h3 class="form-section-title">Military Information</h3>
            <div class="form-grid">
              <div class="form-group">
                <label for="rank">Rank</label>
                <select id="rank" v-model="patient.rank">
                  <option value="">Select Rank</option>
                  <option v-for="rank in ranks" :key="rank" :value="rank">{{ rank }}</option>
                </select>
              </div>
              
              <div class="form-group">
                <label for="service">Service</label>
                <select id="service" v-model="patient.service">
                  <option value="">Select Service</option>
                  <option v-for="service in services" :key="service" :value="service">{{ service }}</option>
                </select>
              </div>
              
              <div class="form-group">
                <label for="fmpc">FMPC</label>
                <input type="text" id="fmpc" v-model="patient.fmpc">
              </div>
            </div>
          </div>
          
          <div class="form-section">
            <h3 class="form-section-title">Contact Information</h3>
            <div class="form-grid">
              <div class="form-group">
                <label for="contactNumber">Contact Number</label>
                <input type="tel" id="contactNumber" v-model="patient.contact_number">
              </div>
              
              <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" v-model="patient.email">
              </div>
              
              <div class="form-group">
                <label for="address">Address</label>
                <textarea id="address" v-model="patient.address" rows="3"></textarea>
              </div>
            </div>
          </div>
          
          <div class="form-section">
            <h3 class="form-section-title">Emergency Contact</h3>
            <div class="form-grid">
              <div class="form-group">
                <label for="emergencyContact">Emergency Contact Name</label>
                <input type="text" id="emergencyContact" v-model="patient.emergency_contact">
              </div>
              
              <div class="form-group">
                <label for="emergencyContactNumber">Emergency Contact Number</label>
                <input type="tel" id="emergencyContactNumber" v-model="patient.emergency_contact_number">
              </div>
            </div>
          </div>
          
          <div class="form-section">
            <h3 class="form-section-title">Medical Information</h3>
            <div class="form-grid">
              <div class="form-group">
                <label for="bloodType">Blood Type</label>
                <select id="bloodType" v-model="patient.blood_type">
                  <option value="">Select Blood Type</option>
                  <option v-for="bloodType in bloodTypes" :key="bloodType" :value="bloodType">
                    {{ bloodType }}
                  </option>
                </select>
              </div>
              
              <div class="form-group">
                <label for="allergies">Allergies</label>
                <textarea id="allergies" v-model="patient.allergies" rows="3"></textarea>
              </div>
              
              <div class="form-group">
                <label for="medicalConditions">Medical Conditions</label>
                <textarea id="medicalConditions" v-model="patient.medical_conditions" rows="3"></textarea>
              </div>
            </div>
          </div>
          
          <div class="actions">
            <button type="button" class="btn btn-secondary" @click="cancel">Cancel</button>
            <button type="submit" class="btn" :disabled="isSaving">
              <span class="spinner" v-if="isSaving"></span>
              {{ isSaving ? 'Saving...' : 'Save Changes' }}
            </button>
          </div>
        </form>
      </div>
    </div>
    
    <LoadingSpinner v-if="isLoading" />
  </div>
</template>

<script>
import { ref, reactive, onMounted, computed } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import AppHeader from '@/components/AppHeader.vue'
import LoadingSpinner from '@/components/LoadingSpinner.vue'
import { patientService } from '@/services/api'

export default {
  name: 'PatientEdit',
  components: {
    AppHeader,
    LoadingSpinner
  },
  props: {
    isNew: {
      type: Boolean,
      default: false
    }
  },
  setup(props) {
    const router = useRouter()
    const route = useRoute()
    
    // Get patient ID from route params
    const patientId = computed(() => route.params.id)
    
    // State variables
    const patient = reactive({
      first_name: '',
      last_name: '',
      date_of_birth: '',
      gender: '',
      rank: '',
      service: '',
      fmpc: '',
      contact_number: '',
      email: '',
      address: '',
      emergency_contact: '',
      emergency_contact_number: '',
      blood_type: '',
      allergies: '',
      medical_conditions: ''
    })
    
    const isLoading = ref(false)
    const isSaving = ref(false)
    const statusMessage = ref('')
    const messageType = ref('success')
    const showMessage = ref(false)
    
    // Available options for dropdown menus
    const ranks = [
      'E-1', 'E-2', 'E-3', 'E-4', 'E-5', 'E-6', 'E-7', 'E-8', 'E-9',
      'O-1', 'O-2', 'O-3', 'O-4', 'O-5', 'O-6', 'O-7', 'O-8', 'O-9', 'O-10',
      'W-1', 'W-2', 'W-3', 'W-4', 'W-5', 'CIV'
    ]
    
    const services = [
      'Army', 'Navy', 'Air Force', 'Marine Corps', 'Coast Guard', 'Space Force'
    ]
    
    const bloodTypes = [
      'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'
    ]
    
    // Display status message
    const showStatusMessage = (message, type = 'success') => {
      statusMessage.value = message
      messageType.value = type
      showMessage.value = true
      
      // Auto-hide after 5 seconds
      setTimeout(() => {
        showMessage.value = false
      }, 5000)
    }
    
    // Load patient data from API
    const loadPatient = async () => {
      if (props.isNew) return
      
      isLoading.value = true
      try {
        const response = await patientService.getPatient(patientId.value)
        
        if (response.success) {
          // Format date for date input (YYYY-MM-DD)
          let patientData = response.patient
          
          if (patientData.date_of_birth) {
            const dob = new Date(patientData.date_of_birth)
            patientData.date_of_birth = dob.toISOString().split('T')[0]
          }
          
          // Update patient object with loaded data
          Object.assign(patient, patientData)
        } else {
          showStatusMessage(`Error: ${response.message}`, 'error')
          setTimeout(() => {
            router.push('/dashboard')
          }, 2000)
        }
      } catch (error) {
        console.error('Error loading patient:', error)
        showStatusMessage(`Error loading patient data: ${error.message}`, 'error')
      } finally {
        isLoading.value = false
      }
    }
    
    // Save patient data
    const savePatient = async () => {
      isSaving.value = true
      
      try {
        let response
        
        if (props.isNew) {
          response = await patientService.createPatient(patient)
        } else {
          response = await patientService.updatePatient(patientId.value, patient)
        }
        
        if (response.success) {
          showStatusMessage(props.isNew ? 'Patient created successfully!' : 'Patient updated successfully!')
          
          // Redirect back to dashboard after a delay
          setTimeout(() => {
            router.push('/dashboard')
          }, 2000)
        } else {
          showStatusMessage(`Error: ${response.message}`, 'error')
        }
      } catch (error) {
        console.error('Error saving patient:', error)
        showStatusMessage(`Error saving patient data: ${error.message}`, 'error')
      } finally {
        isSaving.value = false
      }
    }
    
    // Cancel and return to dashboard
    const cancel = () => {
      router.push('/dashboard')
    }
    
    // Load patient data on component mount
    onMounted(() => {
      if (!props.isNew && patientId.value) {
        loadPatient()
      }
    })
    
    return {
      patient,
      isLoading,
      isSaving,
      statusMessage,
      messageType,
      showMessage,
      ranks,
      services,
      bloodTypes,
      savePatient,
      cancel,
      isNew: props.isNew
    }
  }
}
</script>

<style scoped>
.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.form-container {
  background-color: var(--secondary-bg);
  border-radius: 8px;
  padding: 30px;
  margin-bottom: 20px;
}

.form-title {
  color: var(--accent-color);
  margin-top: 0;
  margin-bottom: 20px;
  padding-bottom: 10px;
  border-bottom: 1px solid var(--border-color);
}

.form-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 20px;
}

@media (max-width: 768px) {
  .form-grid {
    grid-template-columns: 1fr;
  }
}

.form-group {
  margin-bottom: 15px;
}

.form-group label {
  display: block;
  margin-bottom: 5px;
  color: #aaa;
}

.form-group input,
.form-group select,
.form-group textarea {
  width: 100%;
  padding: 10px;
  border: 1px solid var(--border-color);
  border-radius: 4px;
  background-color: var(--primary-bg);
  color: var(--text-color);
  font-family: inherit;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
  outline: none;
  border-color: var(--accent-color);
}

.form-section {
  margin-bottom: 30px;
}

.form-section-title {
  color: var(--accent-color);
  margin-top: 0;
  margin-bottom: 15px;
}

.actions {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 20px;
}

.spinner {
  display: inline-block;
  width: 20px;
  height: 20px;
  border: 3px solid rgba(255, 255, 255, 0.3);
  border-radius: 50%;
  border-top-color: white;
  animation: spin 1s linear infinite;
  margin-right: 10px;
  vertical-align: middle;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

.status-message {
  padding: 10px 15px;
  border-radius: 4px;
  margin-bottom: 20px;
}

.success {
  background-color: rgba(76, 175, 80, 0.1);
  color: var(--success-color);
  border: 1px solid rgba(76, 175, 80, 0.2);
}

.error {
  background-color: rgba(244, 67, 54, 0.1);
  color: var(--danger-color);
  border: 1px solid rgba(244, 67, 54, 0.2);
}
</style> 
<template>
  <div>
    <AppHeader />
    
    <div class="container">
      <div class="main-content">
        <SideNavigation />
        
        <div class="content">
          <div class="card">
            <h3 class="card-header">
              Patients List
              <div class="header-actions">
                <button class="btn" @click="navigateTo('/patients/add')">Add Patient</button>
                <button class="btn" @click="loadPatients">Refresh</button>
              </div>
            </h3>
            
            <div class="search-bar">
              <input 
                type="text" 
                v-model="searchQuery" 
                placeholder="Search patients by name, ID, or service..."
                @keyup.enter="searchPatients"
              >
              <button @click="searchPatients">Search</button>
            </div>
            
            <div class="filters">
              <div class="filter">
                <label>Service:</label>
                <select v-model="serviceFilter" @change="applyFilters">
                  <option value="">All Services</option>
                  <option v-for="service in services" :key="service" :value="service">
                    {{ service }}
                  </option>
                </select>
              </div>
              
              <div class="filter">
                <label>Rank:</label>
                <select v-model="rankFilter" @change="applyFilters">
                  <option value="">All Ranks</option>
                  <option v-for="rank in ranks" :key="rank" :value="rank">
                    {{ rank }}
                  </option>
                </select>
              </div>
            </div>
            
            <LoadingSpinner 
              v-if="isLoading" 
              message="Loading patient data..."
            />
            
            <PatientTable 
              v-else
              :patients="patients"
              :is-loading="isLoading"
              @view="viewPatient"
              @edit="editPatient"
            />
            
            <div class="pagination">
              <button 
                v-for="page in totalPages" 
                :key="page" 
                @click="changePage(page)"
                :class="{ active: currentPage === page }"
              >
                {{ page }}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, reactive, onMounted, computed } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import AppHeader from '@/components/AppHeader.vue'
import SideNavigation from '@/components/SideNavigation.vue'
import LoadingSpinner from '@/components/LoadingSpinner.vue'
import PatientTable from '@/components/PatientTable.vue'
import { patientService } from '@/services/api'

export default {
  name: 'PatientList',
  components: {
    AppHeader,
    SideNavigation,
    LoadingSpinner,
    PatientTable
  },
  setup() {
    const router = useRouter()
    const route = useRoute()
    
    // State variables
    const patients = ref([])
    const isLoading = ref(false)
    const searchQuery = ref('')
    const serviceFilter = ref('')
    const rankFilter = ref('')
    const currentPage = ref(1)
    const totalPatients = ref(0)
    const pageSize = ref(10)
    
    // Available options for filters
    const services = [
      'Army', 'Navy', 'Air Force', 'Marine Corps', 'Coast Guard', 'Space Force'
    ]
    
    const ranks = [
      'E-1', 'E-2', 'E-3', 'E-4', 'E-5', 'E-6', 'E-7', 'E-8', 'E-9',
      'O-1', 'O-2', 'O-3', 'O-4', 'O-5', 'O-6', 'O-7', 'O-8', 'O-9', 'O-10',
      'W-1', 'W-2', 'W-3', 'W-4', 'W-5', 'CIV'
    ]
    
    // Computed properties
    const totalPages = computed(() => {
      return Math.ceil(totalPatients.value / pageSize.value) || 1
    })
    
    // Methods
    const loadPatients = async () => {
      isLoading.value = true
      try {
        const params = {
          limit: pageSize.value,
          offset: (currentPage.value - 1) * pageSize.value
        }
        
        if (searchQuery.value) {
          params.search = searchQuery.value
        }
        
        if (serviceFilter.value) {
          params.service = serviceFilter.value
        }
        
        if (rankFilter.value) {
          params.rank = rankFilter.value
        }
        
        const response = await patientService.getPatients(params)
        
        if (response.success) {
          patients.value = response.patients
          totalPatients.value = response.total
        } else {
          console.error('Error loading patients:', response.message)
          patients.value = []
        }
      } catch (error) {
        console.error('API error:', error)
        patients.value = generateSamplePatients()
      } finally {
        isLoading.value = false
      }
    }
    
    const searchPatients = () => {
      currentPage.value = 1 // Reset to first page when searching
      loadPatients()
    }
    
    const applyFilters = () => {
      currentPage.value = 1 // Reset to first page when applying filters
      loadPatients()
    }
    
    const changePage = (page) => {
      currentPage.value = page
      loadPatients()
    }
    
    const viewPatient = (patientId) => {
      router.push(`/patients/view/${patientId}`)
    }
    
    const editPatient = (patientId) => {
      router.push(`/patients/edit/${patientId}`)
    }
    
    const navigateTo = (path) => {
      router.push(path)
    }
    
    const generateSamplePatients = () => {
      // This is only used as a fallback if the API fails
      return [
        { patient_id: 1, first_name: 'Stacey', last_name: 'Calderon', date_of_birth: '1985-07-12', service: 'Army', rank: 'E-5', blood_type: 'A+', contact_number: '555-123-4567' },
        { patient_id: 2, first_name: 'Ian', last_name: 'Williams', date_of_birth: '1992-03-24', service: 'Navy', rank: 'O-3', blood_type: 'O-', contact_number: '555-987-6543' },
        { patient_id: 3, first_name: 'Michael', last_name: 'Castaneda', date_of_birth: '1978-11-05', service: 'Air Force', rank: 'E-7', blood_type: 'B+', contact_number: '555-345-6789' },
        { patient_id: 4, first_name: 'Matthew', last_name: 'Howard', date_of_birth: '1990-09-30', service: 'Marines', rank: 'E-4', blood_type: 'AB+', contact_number: '555-234-5678' },
        { patient_id: 5, first_name: 'Sophia', last_name: 'Torres', date_of_birth: '1982-05-17', service: 'Coast Guard', rank: 'O-2', blood_type: 'A-', contact_number: '555-876-5432' }
      ]
    }
    
    // Initialize component
    onMounted(() => {
      // Check for filter from query param
      const filter = route.query.filter
      if (filter === 'active') {
        // Could set a specific filter for active patients
      }
      
      loadPatients()
    })
    
    return {
      patients,
      isLoading,
      searchQuery,
      serviceFilter,
      rankFilter,
      currentPage,
      totalPages,
      services,
      ranks,
      loadPatients,
      searchPatients,
      applyFilters,
      changePage,
      viewPatient,
      editPatient,
      navigateTo
    }
  }
}
</script>

<style scoped>
.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.main-content {
  display: flex;
  gap: 20px;
}

.content {
  flex-grow: 1;
}

.card {
  background-color: var(--secondary-bg);
  border-radius: 8px;
  padding: 20px;
  margin-bottom: 20px;
}

.card-header {
  margin-top: 0;
  margin-bottom: 15px;
  font-size: 1.1rem;
  color: var(--accent-color);
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-actions {
  display: flex;
  gap: 10px;
}

.search-bar {
  display: flex;
  margin-bottom: 20px;
}

.search-bar input {
  flex-grow: 1;
  padding: 10px 15px;
  border: 1px solid var(--border-color);
  background-color: var(--secondary-bg);
  color: var(--text-color);
  border-radius: 4px 0 0 4px;
}

.search-bar button {
  background-color: var(--accent-color);
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 0 4px 4px 0;
  cursor: pointer;
}

.filters {
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
  margin-bottom: 20px;
}

.filter {
  display: flex;
  align-items: center;
  gap: 8px;
}

.filter label {
  color: #aaa;
}

.filter select {
  padding: 8px;
  border: 1px solid var(--border-color);
  background-color: var(--secondary-bg);
  color: var(--text-color);
  border-radius: 4px;
}

.pagination {
  display: flex;
  justify-content: center;
  margin-top: 20px;
  gap: 5px;
}

.pagination button {
  background-color: var(--secondary-bg);
  color: var(--text-color);
  border: 1px solid var(--border-color);
  padding: 8px 12px;
  border-radius: 4px;
  cursor: pointer;
}

.pagination button.active {
  background-color: var(--accent-color);
  color: white;
  border-color: var(--accent-color);
}
</style> 
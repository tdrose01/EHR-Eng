<template>
  <div>
    <AppHeader />
    
    <div class="container">
      <div class="main-content">
        <SideNavigation />
        
        <div class="content">
          <div class="actions-bar">
            <button class="btn" @click="navigateTo('/patients')">Back to Patients</button>
            <button class="btn btn-primary" @click="editPatient">Edit Patient</button>
          </div>
          
          <LoadingSpinner v-if="isLoading" message="Loading patient details..." />
          
          <div v-else>
            <div class="card patient-header">
              <div class="patient-avatar">
                <div class="avatar-placeholder">
                  {{ patientInitials }}
                </div>
              </div>
              <div class="patient-info">
                <h2>{{ patient.last_name }}, {{ patient.first_name }}</h2>
                <div class="patient-badges">
                  <span class="badge badge-info">ID: {{ patient.patient_id }}</span>
                  <span class="badge badge-primary">{{ patient.service }}</span>
                  <span class="badge badge-secondary">{{ patient.rank }}</span>
                </div>
              </div>
            </div>
            
            <div class="card-grid">
              <div class="card">
                <h3 class="card-header">Personal Information</h3>
                <div class="info-group">
                  <div class="info-row">
                    <div class="info-label">Date of Birth</div>
                    <div class="info-value">{{ formatDate(patient.date_of_birth) }}</div>
                  </div>
                  
                  <div class="info-row">
                    <div class="info-label">Gender</div>
                    <div class="info-value">{{ patient.gender || 'Not specified' }}</div>
                  </div>
                  
                  <div class="info-row">
                    <div class="info-label">Blood Type</div>
                    <div class="info-value">{{ patient.blood_type || 'Unknown' }}</div>
                  </div>
                </div>
              </div>
              
              <div class="card">
                <h3 class="card-header">Military Information</h3>
                <div class="info-group">
                  <div class="info-row">
                    <div class="info-label">Service</div>
                    <div class="info-value">{{ patient.service || 'Not specified' }}</div>
                  </div>
                  
                  <div class="info-row">
                    <div class="info-label">Rank</div>
                    <div class="info-value">{{ patient.rank || 'Not specified' }}</div>
                  </div>
                  
                  <div class="info-row">
                    <div class="info-label">FMPC</div>
                    <div class="info-value">{{ patient.fmpc || 'Not specified' }}</div>
                  </div>
                </div>
              </div>
              
              <div class="card">
                <h3 class="card-header">Contact Information</h3>
                <div class="info-group">
                  <div class="info-row">
                    <div class="info-label">Phone</div>
                    <div class="info-value">{{ patient.contact_number || 'Not provided' }}</div>
                  </div>
                  
                  <div class="info-row">
                    <div class="info-label">Email</div>
                    <div class="info-value">{{ patient.email || 'Not provided' }}</div>
                  </div>
                  
                  <div class="info-row">
                    <div class="info-label">Address</div>
                    <div class="info-value">{{ patient.address || 'Not provided' }}</div>
                  </div>
                </div>
              </div>
              
              <div class="card">
                <h3 class="card-header">Emergency Contact</h3>
                <div class="info-group">
                  <div class="info-row">
                    <div class="info-label">Name</div>
                    <div class="info-value">{{ patient.emergency_contact || 'Not provided' }}</div>
                  </div>
                  
                  <div class="info-row">
                    <div class="info-label">Phone</div>
                    <div class="info-value">{{ patient.emergency_contact_number || 'Not provided' }}</div>
                  </div>
                </div>
              </div>
            </div>
            
            <div class="card">
              <h3 class="card-header">Medical Information</h3>
              <div class="info-group">
                <div class="info-row">
                  <div class="info-label">Allergies</div>
                  <div class="info-value multiline">{{ patient.allergies || 'No known allergies' }}</div>
                </div>
                
                <div class="info-row">
                  <div class="info-label">Medical Conditions</div>
                  <div class="info-value multiline">{{ patient.medical_conditions || 'No known medical conditions' }}</div>
                </div>
              </div>
            </div>
            
            <div class="card">
              <h3 class="card-header">
                Recent Medical Records
                <button class="btn btn-sm" @click="navigateTo(`/records?patient=${patient.patient_id}`)">
                  View All Records
                </button>
              </h3>
              
              <p v-if="!recentRecords.length" class="no-records">No recent medical records found</p>
              
              <table v-else>
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Type</th>
                    <th>Provider</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="record in recentRecords" :key="record.id">
                    <td>{{ formatDate(record.date) }}</td>
                    <td>{{ record.type }}</td>
                    <td>{{ record.provider }}</td>
                    <td>
                      <span class="badge" :class="'badge-' + getStatusClass(record.status)">
                        {{ record.status }}
                      </span>
                    </td>
                    <td>
                      <button class="btn btn-sm" @click="viewRecord(record.id)">View</button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            
            <div class="card">
              <h3 class="card-header">
                Upcoming Appointments
                <button class="btn btn-sm" @click="navigateTo(`/appointments?patient=${patient.patient_id}`)">
                  View All Appointments
                </button>
              </h3>
              
              <p v-if="!upcomingAppointments.length" class="no-records">No upcoming appointments</p>
              
              <table v-else>
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Provider</th>
                    <th>Type</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="appointment in upcomingAppointments" :key="appointment.id">
                    <td>{{ formatDate(appointment.date) }}</td>
                    <td>{{ appointment.time }}</td>
                    <td>{{ appointment.provider }}</td>
                    <td>{{ appointment.type }}</td>
                    <td>
                      <button class="btn btn-sm" @click="viewAppointment(appointment.id)">View</button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, computed, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import AppHeader from '@/components/AppHeader.vue'
import SideNavigation from '@/components/SideNavigation.vue'
import LoadingSpinner from '@/components/LoadingSpinner.vue'
import { patientService } from '@/services/api'

export default {
  name: 'PatientView',
  components: {
    AppHeader,
    SideNavigation,
    LoadingSpinner
  },
  setup() {
    const router = useRouter()
    const route = useRoute()
    
    // Get patient ID from route params
    const patientId = computed(() => route.params.id)
    
    // State variables
    const patient = ref({
      first_name: '',
      last_name: '',
      date_of_birth: '',
      gender: '',
      rank: '',
      service: '',
      fmpc: '',
      contact_number: '',
      email: '',
      address: '',
      emergency_contact: '',
      emergency_contact_number: '',
      blood_type: '',
      allergies: '',
      medical_conditions: ''
    })
    const isLoading = ref(true)
    const recentRecords = ref([])
    const upcomingAppointments = ref([])
    
    // Computed properties
    const patientInitials = computed(() => {
      const first = patient.value.first_name ? patient.value.first_name.charAt(0) : '';
      const last = patient.value.last_name ? patient.value.last_name.charAt(0) : '';
      return (first + last).toUpperCase();
    })
    
    // Methods
    const loadPatient = async () => {
      isLoading.value = true
      try {
        const response = await patientService.getPatient(patientId.value)
        
        if (response.success) {
          patient.value = response.patient
          
          // Also fetch records and appointments
          await loadRelatedData()
        } else {
          console.error('Error loading patient:', response.message)
          router.push('/patients')
        }
      } catch (error) {
        console.error('API error:', error)
        // Use mock data for testing
        patient.value = {
          patient_id: patientId.value,
          first_name: 'John',
          last_name: 'Doe',
          date_of_birth: '1985-07-12',
          gender: 'Male',
          rank: 'E-5',
          service: 'Army',
          fmpc: '12345',
          contact_number: '555-123-4567',
          email: 'john.doe@example.com',
          address: '123 Military Base, Anytown, USA',
          emergency_contact: 'Jane Doe',
          emergency_contact_number: '555-987-6543',
          blood_type: 'O+',
          allergies: 'Penicillin',
          medical_conditions: 'None'
        }
        
        loadMockRelatedData()
      } finally {
        isLoading.value = false
      }
    }
    
    const loadRelatedData = async () => {
      // In a real application, we would fetch actual records and appointments
      // For now, use mock data
      loadMockRelatedData()
    }
    
    const loadMockRelatedData = () => {
      // Mock recent records
      recentRecords.value = [
        { id: 1, date: '2023-03-15', type: 'Annual Physical', provider: 'Capt. Sarah Johnson', status: 'Completed' },
        { id: 2, date: '2023-02-10', type: 'Vaccination', provider: 'Lt. Michael Chen', status: 'Completed' },
        { id: 3, date: '2023-01-20', type: 'Sick Call', provider: 'Maj. David Wilson', status: 'Completed' }
      ]
      
      // Mock upcoming appointments
      upcomingAppointments.value = [
        { id: 1, date: '2023-04-05', time: '09:30 AM', provider: 'Capt. Sarah Johnson', type: 'Follow-up' },
        { id: 2, date: '2023-05-12', time: '13:45 PM', provider: 'Col. Robert Garcia', type: 'Annual Physical' }
      ]
    }
    
    const formatDate = (dateString) => {
      if (!dateString) return 'N/A'
      const date = new Date(dateString)
      return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
    }
    
    const getStatusClass = (status) => {
      switch (status.toLowerCase()) {
        case 'completed': return 'success'
        case 'pending': return 'warning'
        case 'cancelled': return 'danger'
        default: return 'info'
      }
    }
    
    const editPatient = () => {
      router.push(`/patients/edit/${patientId.value}`)
    }
    
    const viewRecord = (recordId) => {
      router.push(`/records/${recordId}`)
    }
    
    const viewAppointment = (appointmentId) => {
      router.push(`/appointments/${appointmentId}`)
    }
    
    const navigateTo = (path) => {
      router.push(path)
    }
    
    // Load patient data on component mount
    onMounted(() => {
      if (patientId.value) {
        loadPatient()
      } else {
        router.push('/patients')
      }
    })
    
    return {
      patient,
      isLoading,
      patientId,
      recentRecords,
      upcomingAppointments,
      patientInitials,
      formatDate,
      getStatusClass,
      editPatient,
      viewRecord,
      viewAppointment,
      navigateTo
    }
  }
}
</script>

<style scoped>
.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.main-content {
  display: flex;
  gap: 20px;
}

.content {
  flex-grow: 1;
}

.actions-bar {
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;
}

.card {
  background-color: var(--secondary-bg);
  border-radius: 8px;
  padding: 20px;
  margin-bottom: 20px;
}

.card-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 20px;
  margin-bottom: 20px;
}

.patient-header {
  display: flex;
  align-items: center;
  gap: 20px;
}

.patient-avatar {
  flex-shrink: 0;
}

.avatar-placeholder {
  width: 80px;
  height: 80px;
  background-color: var(--accent-color);
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 1.8rem;
  font-weight: bold;
  color: white;
}

.patient-info {
  flex-grow: 1;
}

.patient-info h2 {
  margin-top: 0;
  margin-bottom: 10px;
  color: var(--text-color);
}

.patient-badges {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.badge {
  padding: 5px 10px;
  border-radius: 16px;
  font-size: 0.8rem;
  font-weight: 500;
}

.badge-info {
  background-color: rgba(33, 150, 243, 0.1);
  color: #2196f3;
}

.badge-primary {
  background-color: rgba(77, 139, 240, 0.1);
  color: var(--accent-color);
}

.badge-secondary {
  background-color: rgba(156, 39, 176, 0.1);
  color: #9c27b0;
}

.badge-success {
  background-color: rgba(76, 175, 80, 0.1);
  color: var(--success-color);
}

.badge-warning {
  background-color: rgba(255, 152, 0, 0.1);
  color: var(--warning-color);
}

.badge-danger {
  background-color: rgba(244, 67, 54, 0.1);
  color: var(--danger-color);
}

.card-header {
  margin-top: 0;
  margin-bottom: 15px;
  font-size: 1.1rem;
  color: var(--accent-color);
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.info-group {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.info-row {
  display: flex;
  flex-direction: column;
}

.info-label {
  font-size: 0.8rem;
  color: #aaa;
  margin-bottom: 3px;
}

.info-value {
  font-size: 1rem;
}

.info-value.multiline {
  white-space: pre-line;
  margin-top: 5px;
  padding: 10px;
  background-color: rgba(255, 255, 255, 0.05);
  border-radius: 4px;
}

table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 10px;
}

th, td {
  text-align: left;
  padding: 12px 15px;
  border-bottom: 1px solid var(--border-color);
}

th {
  background-color: rgba(77, 139, 240, 0.1);
  color: var(--accent-color);
  font-weight: 500;
}

.btn-sm {
  padding: 5px 10px;
  font-size: 0.8rem;
}

.no-records {
  text-align: center;
  color: #aaa;
  padding: 20px 0;
}
</style> 
<template>
  <div>
    <AppHeader />
    
    <div class="container">
      <div class="main-content">
        <SideNavigation />
        
        <div class="content">
          <div class="card">
            <h3 class="card-header">
              Medical Records
              <div class="header-actions">
                <button class="btn" @click="navigateTo('/records/add')">Add Record</button>
                <button class="btn" @click="loadRecords">Refresh</button>
              </div>
            </h3>
            
            <div class="filter-section">
              <div class="search-bar">
                <input 
                  type="text" 
                  v-model="searchQuery" 
                  placeholder="Search by patient name, ID, or procedure..."
                  @keyup.enter="applyFilters"
                >
                <button @click="applyFilters">Search</button>
              </div>
              
              <div class="filter-container">
                <div class="filter-group">
                  <label for="recordType">Record Type:</label>
                  <select id="recordType" v-model="recordTypeFilter" @change="applyFilters">
                    <option value="">All Types</option>
                    <option v-for="type in recordTypes" :key="type" :value="type">{{ type }}</option>
                  </select>
                </div>
                
                <div class="filter-group">
                  <label for="dateRange">Date Range:</label>
                  <select id="dateRange" v-model="dateRangeFilter" @change="applyFilters">
                    <option value="all">All Time</option>
                    <option value="last-month">Last Month</option>
                    <option value="last-3-months">Last 3 Months</option>
                    <option value="last-6-months">Last 6 Months</option>
                    <option value="last-year">Last Year</option>
                    <option value="custom">Custom Range</option>
                  </select>
                </div>
                
                <div class="date-range" v-if="dateRangeFilter === 'custom'">
                  <div class="filter-group">
                    <label for="startDate">From:</label>
                    <input type="date" id="startDate" v-model="startDate" @change="applyFilters">
                  </div>
                  <div class="filter-group">
                    <label for="endDate">To:</label>
                    <input type="date" id="endDate" v-model="endDate" @change="applyFilters">
                  </div>
                </div>
              </div>
            </div>
            
            <LoadingSpinner v-if="isLoading" message="Loading medical records..." />
            
            <div v-else-if="filteredRecords.length === 0" class="no-data">
              No medical records found matching your criteria.
            </div>
            
            <table v-else>
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Patient</th>
                  <th>Record Type</th>
                  <th>Provider</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="record in filteredRecords" :key="record.id">
                  <td>{{ formatDate(record.date) }}</td>
                  <td>
                    <div class="patient-info">
                      <div>{{ record.patient_name }}</div>
                      <div class="patient-id">ID: {{ record.patient_id }}</div>
                    </div>
                  </td>
                  <td>{{ record.type }}</td>
                  <td>{{ record.provider }}</td>
                  <td>
                    <span 
                      class="badge" 
                      :class="'badge-' + getStatusClass(record.status)"
                    >
                      {{ record.status }}
                    </span>
                  </td>
                  <td>
                    <div class="action-buttons">
                      <button class="btn btn-sm" @click="viewRecord(record.id)">View</button>
                      <button 
                        class="btn btn-sm" 
                        @click="editRecord(record.id)"
                        v-if="canEditRecord(record)"
                      >
                        Edit
                      </button>
                      <button 
                        class="btn btn-sm btn-danger" 
                        @click="deleteRecord(record)"
                        v-if="canDeleteRecord(record)"
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
            
            <div class="pagination">
              <button 
                v-for="page in totalPages" 
                :key="page"
                :class="{ active: currentPage === page }"
                @click="changePage(page)"
              >
                {{ page }}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <!-- Delete Confirmation Modal -->
    <div class="modal" v-if="showDeleteModal">
      <div class="modal-content">
        <div class="modal-header">
          <h4>Delete Medical Record</h4>
          <button class="close-btn" @click="showDeleteModal = false">&times;</button>
        </div>
        <div class="modal-body">
          <p>Are you sure you want to delete this medical record?</p>
          <p v-if="selectedRecord">
            <strong>Date:</strong> {{ formatDate(selectedRecord.date) }}<br>
            <strong>Patient:</strong> {{ selectedRecord.patient_name }}<br>
            <strong>Type:</strong> {{ selectedRecord.type }}
          </p>
          <div class="warning">This action cannot be undone.</div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" @click="showDeleteModal = false">Cancel</button>
          <button class="btn btn-danger" @click="confirmDeleteRecord">Delete</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, computed, onMounted, watch } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import AppHeader from '@/components/AppHeader.vue'
import SideNavigation from '@/components/SideNavigation.vue'
import LoadingSpinner from '@/components/LoadingSpinner.vue'
import { recordsService } from '@/services/api'

export default {
  name: 'Records',
  components: {
    AppHeader,
    SideNavigation,
    LoadingSpinner
  },
  setup() {
    const router = useRouter()
    const route = useRoute()
    
    // State variables
    const records = ref([])
    const isLoading = ref(true)
    const searchQuery = ref('')
    const recordTypeFilter = ref('')
    const dateRangeFilter = ref('all')
    const startDate = ref('')
    const endDate = ref('')
    const currentPage = ref(1)
    const totalRecords = ref(0)
    const pageSize = ref(10)
    const showDeleteModal = ref(false)
    const selectedRecord = ref(null)
    
    // Constants
    const recordTypes = [
      'Annual Physical',
      'Lab Work',
      'Imaging',
      'Vaccination',
      'Consultation',
      'Surgery',
      'Prescription',
      'Mental Health',
      'Dental',
      'Vision',
      'Physical Therapy',
      'Sick Call'
    ]
    
    // Computed properties
    const totalPages = computed(() => {
      return Math.ceil(totalRecords.value / pageSize.value) || 1
    })
    
    const filteredRecords = computed(() => {
      return records.value
    })
    
    // Methods
    const loadRecords = async () => {
      isLoading.value = true
      
      try {
        const params = {
          limit: pageSize.value,
          offset: (currentPage.value - 1) * pageSize.value
        }
        
        // Add record type filter
        if (recordTypeFilter.value) {
          params.type = recordTypeFilter.value
        }
        
        // Add date range filter
        if (dateRangeFilter.value === 'custom' && startDate.value && endDate.value) {
          params.startDate = startDate.value
          params.endDate = endDate.value
        } else if (dateRangeFilter.value !== 'all') {
          params.dateRange = dateRangeFilter.value
        }
        
        // Add search query
        if (searchQuery.value) {
          params.search = searchQuery.value
        }
        
        // Get patient ID from query param if available
        const patientId = route.query.patient
        if (patientId) {
          params.patientId = patientId
        }
        
        // In a real app, we would fetch from API
        // For now, generate mock data
        setTimeout(() => {
          records.value = generateMockRecords()
          totalRecords.value = 50 // Mock total
          isLoading.value = false
        }, 500)
      } catch (error) {
        console.error('Error loading records:', error)
        records.value = generateMockRecords()
        isLoading.value = false
      }
    }
    
    const applyFilters = () => {
      currentPage.value = 1
      loadRecords()
    }
    
    const changePage = (page) => {
      currentPage.value = page
      loadRecords()
    }
    
    const viewRecord = (recordId) => {
      router.push(`/records/${recordId}`)
    }
    
    const editRecord = (recordId) => {
      router.push(`/records/${recordId}/edit`)
    }
    
    const deleteRecord = (record) => {
      selectedRecord.value = record
      showDeleteModal.value = true
    }
    
    const confirmDeleteRecord = async () => {
      if (!selectedRecord.value) return
      
      try {
        // In a real app, call API to delete record
        // recordsService.deleteRecord(selectedRecord.value.id)
        
        // For now, just update locally
        records.value = records.value.filter(r => r.id !== selectedRecord.value.id)
        
        showDeleteModal.value = false
        selectedRecord.value = null
      } catch (error) {
        console.error('Error deleting record:', error)
      }
    }
    
    const canEditRecord = (record) => {
      // In a real app, implement proper permissions check
      // For now, all draft records can be edited
      return record.status === 'Draft'
    }
    
    const canDeleteRecord = (record) => {
      // In a real app, implement proper permissions check
      // For now, only draft records can be deleted
      return record.status === 'Draft'
    }
    
    const formatDate = (dateString) => {
      if (!dateString) return 'N/A'
      const date = new Date(dateString)
      return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
    }
    
    const getStatusClass = (status) => {
      switch (status) {
        case 'Completed': return 'success'
        case 'Draft': return 'warning'
        case 'Pending': return 'info'
        case 'Cancelled': return 'danger'
        default: return 'secondary'
      }
    }
    
    const navigateTo = (path) => {
      router.push(path)
    }
    
    const generateMockRecords = () => {
      const providers = [
        'Capt. Sarah Johnson', 
        'Lt. Col. James Miller', 
        'Maj. Robert Chen', 
        'Lt. Emma Rodriguez', 
        'Col. William Davis'
      ]
      
      const statuses = ['Completed', 'Draft', 'Pending', 'Cancelled']
      
      // Generate dates from past 2 years
      const today = new Date()
      const twoYearsAgo = new Date(today)
      twoYearsAgo.setFullYear(today.getFullYear() - 2)
      
      // Generate random records
      const mockRecords = []
      for (let i = 1; i <= 50; i++) {
        // Generate random date between two years ago and today
        const dateRange = today - twoYearsAgo
        const randomDate = new Date(twoYearsAgo.getTime() + Math.random() * dateRange)
        
        // Format as YYYY-MM-DD
        const dateStr = randomDate.toISOString().split('T')[0]
        
        // Random status with more completed than others
        const randomIndex = Math.floor(Math.random() * (randomDate < today ? 10 : 4))
        const status = randomDate < today 
          ? (randomIndex < 7 ? 'Completed' : statuses[randomIndex % statuses.length])
          : statuses[randomIndex % statuses.length]
        
        mockRecords.push({
          id: i,
          date: dateStr,
          patient_id: Math.floor(Math.random() * 1000) + 1000,
          patient_name: `Patient ${i}`,
          type: recordTypes[Math.floor(Math.random() * recordTypes.length)],
          provider: providers[Math.floor(Math.random() * providers.length)],
          status: status
        })
      }
      
      // Sort by date (newest first)
      return mockRecords.sort((a, b) => new Date(b.date) - new Date(a.date))
    }
    
    // Watch for route query changes
    watch(() => route.query, (newQuery) => {
      if (newQuery.filter === 'pending') {
        // Filter to show only pending records
        recordTypeFilter.value = ''
        dateRangeFilter.value = 'all'
      }
      
      loadRecords()
    }, { immediate: true })
    
    // Initialize component
    onMounted(() => {
      // Set default dates for custom range
      const today = new Date()
      
      // Default start date to 3 months ago
      const startDateObj = new Date(today)
      startDateObj.setMonth(today.getMonth() - 3)
      startDate.value = startDateObj.toISOString().split('T')[0]
      
      // Default end date to today
      endDate.value = today.toISOString().split('T')[0]
      
      // Check for filter from query param
      if (route.query.filter === 'pending') {
        // Set up filter for pending records
      }
      
      loadRecords()
    })
    
    return {
      records,
      filteredRecords,
      isLoading,
      searchQuery,
      recordTypeFilter,
      dateRangeFilter,
      startDate,
      endDate,
      currentPage,
      totalPages,
      recordTypes,
      showDeleteModal,
      selectedRecord,
      applyFilters,
      changePage,
      viewRecord,
      editRecord,
      deleteRecord,
      confirmDeleteRecord,
      canEditRecord,
      canDeleteRecord,
      formatDate,
      getStatusClass,
      navigateTo
    }
  }
}
</script>

<style scoped>
.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.main-content {
  display: flex;
  gap: 20px;
}

.content {
  flex-grow: 1;
}

.card {
  background-color: var(--secondary-bg);
  border-radius: 8px;
  padding: 20px;
  margin-bottom: 20px;
}

.card-header {
  margin-top: 0;
  margin-bottom: 15px;
  font-size: 1.1rem;
  color: var(--accent-color);
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-actions {
  display: flex;
  gap: 10px;
}

.filter-section {
  margin-bottom: 20px;
}

.search-bar {
  display: flex;
  margin-bottom: 15px;
}

.search-bar input {
  flex-grow: 1;
  padding: 10px 15px;
  border: 1px solid var(--border-color);
  background-color: var(--secondary-bg);
  color: var(--text-color);
  border-radius: 4px 0 0 4px;
}

.search-bar button {
  background-color: var(--accent-color);
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 0 4px 4px 0;
  cursor: pointer;
}

.filter-container {
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
}

.filter-group {
  display: flex;
  flex-direction: column;
  gap: 5px;
  min-width: 200px;
}

.filter-group label {
  font-size: 0.9rem;
  color: #aaa;
}

.filter-group select,
.filter-group input {
  padding: 8px 10px;
  border: 1px solid var(--border-color);
  border-radius: 4px;
  background-color: var(--primary-bg);
  color: var(--text-color);
}

.date-range {
  display: flex;
  gap: 10px;
  margin-top: 10px;
}

table {
  width: 100%;
  border-collapse: collapse;
}

th, td {
  text-align: left;
  padding: 12px 15px;
  border-bottom: 1px solid var(--border-color);
}

th {
  background-color: rgba(77, 139, 240, 0.1);
  color: var(--accent-color);
  font-weight: 500;
}

.patient-info {
  display: flex;
  flex-direction: column;
}

.patient-id {
  font-size: 0.8rem;
  color: #aaa;
}

.badge {
  display: inline-block;
  padding: 4px 8px;
  border-radius: 12px;
  font-size: 0.8rem;
  font-weight: 500;
}

.badge-info {
  background-color: rgba(33, 150, 243, 0.1);
  color: #2196f3;
}

.badge-success {
  background-color: rgba(76, 175, 80, 0.1);
  color: var(--success-color);
}

.badge-warning {
  background-color: rgba(255, 152, 0, 0.1);
  color: var(--warning-color);
}

.badge-danger {
  background-color: rgba(244, 67, 54, 0.1);
  color: var(--danger-color);
}

.badge-secondary {
  background-color: rgba(158, 158, 158, 0.1);
  color: #9e9e9e;
}

.action-buttons {
  display: flex;
  gap: 5px;
}

.btn-sm {
  padding: 4px 8px;
  font-size: 0.8rem;
}

.btn-danger {
  background-color: var(--danger-color);
}

.btn-danger:hover {
  background-color: #d32f2f;
}

.pagination {
  display: flex;
  justify-content: center;
  margin-top: 20px;
  gap: 5px;
}

.pagination button {
  background-color: var(--secondary-bg);
  color: var(--text-color);
  border: 1px solid var(--border-color);
  padding: 8px 12px;
  border-radius: 4px;
  cursor: pointer;
}

.pagination button.active {
  background-color: var(--accent-color);
  color: white;
  border-color: var(--accent-color);
}

.no-data {
  text-align: center;
  padding: 30px;
  color: #aaa;
}

/* Modal styles */
.modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background-color: var(--secondary-bg);
  border-radius: 8px;
  width: 90%;
  max-width: 500px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
}

.modal-header {
  padding: 15px 20px;
  border-bottom: 1px solid var(--border-color);
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.modal-header h4 {
  margin: 0;
  color: var(--accent-color);
}

.close-btn {
  background: none;
  border: none;
  font-size: 1.5rem;
  color: var(--text-color);
  cursor: pointer;
}

.modal-body {
  padding: 20px;
}

.modal-body .warning {
  margin-top: 15px;
  padding: 10px;
  background-color: rgba(244, 67, 54, 0.1);
  color: var(--danger-color);
  border-radius: 4px;
  text-align: center;
  font-weight: 500;
}

.modal-footer {
  padding: 15px 20px;
  border-top: 1px solid var(--border-color);
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}

.btn-secondary {
  background-color: var(--border-color);
}

.btn-secondary:hover {
  background-color: #444;
}

@media (max-width: 768px) {
  .filter-container {
    flex-direction: column;
  }
  
  .date-range {
    flex-direction: column;
  }
}
</style> 